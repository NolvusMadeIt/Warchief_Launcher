@echo off
title Warchief Launcher
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js isn't installed yet, and the launcher needs it to run.
  echo  Opening the download page now. Install the LTS version,
  echo  then double-click "Start Launcher.bat" again.
  echo.
  start "" "https://nodejs.org/en/download"
  pause
  exit /b
)

set NEEDINSTALL=
if not exist "node_modules\electron\dist\electron.exe" set NEEDINSTALL=1
if not exist "node_modules\adm-zip" set NEEDINSTALL=1
if not exist "node_modules\marked" set NEEDINSTALL=1
if not exist "node_modules\dompurify" set NEEDINSTALL=1
if defined NEEDINSTALL (
  echo.
  echo  Getting what the launcher needs. This only happens the first time
  echo  or after an update, and takes a minute or two...
  echo.
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo  Something went wrong while downloading. Check your internet and try again.
    pause
    exit /b
  )
)

rem Start the launcher on its own, then close this window.
start "" "%~dp0node_modules\electron\dist\electron.exe" "%~dp0."
exit /b

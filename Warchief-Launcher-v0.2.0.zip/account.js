// Discord login for downloads (the launcher's side). Talks to the access service on Vercel.
// The login pass is kept encrypted by Windows (safeStorage) in the launcher's own folder and never goes to the screens.
'use strict';
const { app, ipcMain, shell, safeStorage } = require('electron');
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const GRACE_MS = 3 * 86400000;      // offline: keep trusting the last membership check for 3 days
const LOGIN_WAIT_MS = 5 * 60000;    // how long the launcher waits for the browser login
const FILE = () => path.join(app.getPath('userData'), 'account.dat');

let acc = null;      // { service, token, me, checkedAt }
let pending = null;  // a login waiting for the browser

// ---------- Saved login ----------
function load() {
  if (acc) return acc;
  acc = {};
  try {
    const box = JSON.parse(fs.readFileSync(FILE(), 'utf8'));
    const raw = Buffer.from(box.data, 'base64');
    acc = JSON.parse(box.enc ? safeStorage.decryptString(raw) : raw.toString('utf8')) || {};
  } catch { acc = {}; }
  return acc;
}
function save() {
  try {
    const text = JSON.stringify(acc);
    const enc = safeStorage.isEncryptionAvailable();
    const box = { enc, data: (enc ? safeStorage.encryptString(text) : Buffer.from(text, 'utf8')).toString('base64') };
    fs.mkdirSync(path.dirname(FILE()), { recursive: true });
    fs.writeFileSync(FILE() + '.tmp', JSON.stringify(box));
    fs.renameSync(FILE() + '.tmp', FILE());
  } catch { /* the login just won't be remembered */ }
}
// The service address comes from the published addon list. A test address on this PC only works when run from the folder.
function okService(u) {
  if (typeof u !== 'string') return false;
  if (/^https:\/\/[\w.-]+(:\d+)?$/i.test(u)) return true;
  return !app.isPackaged && /^http:\/\/127\.0\.0\.1:\d+$/.test(u);
}
// Called with the addon list's "access" settings every time it loads. Discord login is always on; this is
// the service it uses when the list doesn't name one.
const DEFAULT_SERVICE = 'https://warchief-access.vercel.app';
function setAccess(a) {
  load();
  const named = a && typeof a.service === 'string' ? a.service.replace(/\/+$/, '') : '';
  const service = okService(named) ? named : DEFAULT_SERVICE;
  if (service === (acc.service || '')) return;
  if (acc.service && service) { delete acc.me; delete acc.checkedAt; } // a different service: check again
  acc.service = service;
  save();
}

// ---------- Calls to the service ----------
async function call(pathAndQuery, init = {}) {
  load();
  if (!acc.service) return { status: 0, data: { error: 'Discord login is not set up.' } };
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 15000);
  try {
    const headers = { ...(init.headers || {}) };
    if (acc.token) headers.Authorization = 'Bearer ' + acc.token;
    const r = await fetch(acc.service + pathAndQuery, { ...init, headers, signal: ctl.signal });
    let data = {};
    try { data = await r.json(); } catch { data = {}; }
    return { status: r.status, data };
  } catch {
    return { status: 0, data: { error: "Couldn't reach the login service. Check your internet connection." } };
  } finally { clearTimeout(timer); }
}
const publicMe = me => (me ? { user: me.user, inServer: !!me.inServer, member: !!me.member, tester: !!me.tester, joinedAt: me.joinedAt || null, roles: Array.isArray(me.roles) ? me.roles : [], invite: me.invite || '', plan: me.plan || null } : null);

async function status(fresh) {
  load();
  if (!acc.service) return { service: false, loggedIn: false };
  if (!acc.token) return { service: true, loggedIn: false };
  const r = await call('/api/me' + (fresh ? '?fresh=1' : ''));
  if (r.status === 200 && r.data.user) {
    if (r.data.token) acc.token = r.data.token;
    acc.me = publicMe(r.data); acc.checkedAt = Date.now();
    save();
    return { service: true, loggedIn: true, me: acc.me, checkedAt: acc.checkedAt, offline: false };
  }
  if (r.status === 401) { delete acc.token; delete acc.me; delete acc.checkedAt; save(); return { service: true, loggedIn: false, expired: true }; }
  // Offline or the service is having a moment: the last check counts for a few days.
  const recent = acc.me && acc.checkedAt && Date.now() - acc.checkedAt < GRACE_MS;
  return { service: true, loggedIn: true, me: recent ? acc.me : null, checkedAt: acc.checkedAt || null, offline: true, error: r.data.error || `The login service said ${r.status}.` };
}

// ---------- Logging in: the browser goes to Discord, then back to a tiny page this launcher serves on 127.0.0.1 ----------
function donePage(title, text) {
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0d0b19;color:#ece8fb;font:16px/1.5 system-ui,sans-serif;padding:0 16px}
.b{max-width:440px;padding:28px 32px;background:#161230;border:1px solid #2c2650;border-top:2px solid #f2c75c;text-align:center}
h1{font-size:21px;margin:0 0 8px;color:#fff}p{margin:0;color:#b9b2dc}</style></head>
<body><div class="b"><h1>${esc(title)}</h1><p>${esc(text)}</p></div></body></html>`;
}
function login(focusWindow) {
  load();
  if (!acc.service) return Promise.resolve({ error: 'not-set-up' });
  if (pending) { shell.openExternal(pending.url); return pending.promise; } // pressed again: show the page again
  const nonce = crypto.randomBytes(24).toString('base64url');
  const server = http.createServer();
  let finish;
  const promise = new Promise(resolve => {
    const timer = setTimeout(() => finish({ error: 'timeout' }), LOGIN_WAIT_MS);
    finish = result => {
      if (!pending || pending.promise !== promise) return;
      clearTimeout(timer); pending = null;
      setTimeout(() => server.close(), 1500);
      resolve(result);
    };
  });
  server.on('request', (req, res) => {
    const u = new URL(req.url, 'http://127.0.0.1');
    if (u.pathname !== '/auth') { res.writeHead(404); return res.end(); }
    res.writeHead(u.searchParams.get('nonce') === nonce ? 200 : 400, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    if (u.searchParams.get('nonce') !== nonce) return res.end(donePage('That login link is old', 'Go back to Warchief Launcher and press "Log in with Discord" again.'));
    const token = u.searchParams.get('token');
    const err = u.searchParams.get('error');
    if (token && /^[\w-]+\.[\w-]+$/.test(token)) {
      res.end(donePage("You're logged in", 'You can close this tab and go back to Warchief Launcher.'));
      acc.token = token; delete acc.me; delete acc.checkedAt; save();
      if (focusWindow) focusWindow();
      return finish({ ok: true });
    }
    res.end(err === 'cancelled' ? donePage('Login cancelled', 'Nothing was changed. You can close this tab.') : donePage("Login didn't work", 'Go back to Warchief Launcher and try again in a minute.'));
    if (focusWindow) focusWindow();
    finish({ error: err === 'cancelled' ? 'cancelled' : 'discord' });
  });
  pending = { url: '', promise, cancel: () => finish({ error: 'cancelled' }) };
  server.listen(0, '127.0.0.1', () => {
    if (!pending || pending.promise !== promise) return server.close();
    pending.url = `${acc.service}/api/login?port=${server.address().port}&nonce=${nonce}`;
    shell.openExternal(pending.url);
  });
  server.on('error', () => finish({ error: 'discord' }));
  return promise;
}

// A short-lived download link for one addon from the service (only for people allowed to have it).
async function fetchLink(product, channel) {
  if (typeof product !== 'string' || !/^[\w-]{1,60}$/.test(product)) return { ok: false, error: 'Unknown addon.' };
  const ch = channel === 'beta' ? 'beta' : 'stable';
  const r = await call(`/api/download?product=${encodeURIComponent(product)}&channel=${ch}`);
  const url = String((r.data && r.data.url) || '');
  const okUrl = /^https:\/\//.test(url) || (!app.isPackaged && /^http:\/\/127\.0\.0\.1:\d+\//.test(url));
  if (r.status === 200 && okUrl) {
    return { ok: true, url: r.data.url, version: r.data.version, name: r.data.name, size: r.data.size };
  }
  if (r.status === 401) { load(); if (acc.token) { delete acc.token; delete acc.me; save(); } }
  return { ok: false, status: r.status, need: r.data.need || '', invite: r.data.invite || '', error: r.data.error || "Couldn't get the download right now." };
}
const accessOn = () => !!load().service;

function setup({ focusWindow }) {
  ipcMain.handle('acct:get', (_e, fresh) => status(!!fresh));
  ipcMain.handle('acct:login', () => login(focusWindow));
  ipcMain.handle('acct:cancel', () => { if (pending) pending.cancel(); });
  ipcMain.handle('acct:logout', () => { load(); delete acc.token; delete acc.me; delete acc.checkedAt; save(); return { service: !!acc.service, loggedIn: false }; });
  // Asks the service for a download link. The screens only get the answer; the link never leaves this side.
  ipcMain.handle('acct:download', async (_e, product, channel) => {
    const r = await fetchLink(product, channel);
    if (r.ok) return { ok: true, version: r.version, name: r.name, size: r.size };
    return r;
  });
  // To-do votes, the Discord posts for the bell, and finding people in the server (api/community on the service)
  ipcMain.handle('acct:community', async (_e, act, b) => {
    if (!['votes', 'feed', 'vote', 'search'].includes(act)) return { ok: false, status: 400 };
    let r;
    if (act === 'vote') {
      const body = b && typeof b === 'object' ? { card: String(b.card || '').slice(0, 40), vote: Number(b.vote) || 0 } : {};
      r = await call('/api/community?do=vote', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    } else {
      const q = act === 'search' && b && typeof b.q === 'string' ? '&q=' + encodeURIComponent(b.q.slice(0, 32)) : '';
      r = await call('/api/community?do=' + act + q);
    }
    if (r.status === 401) { load(); if (acc.token) { delete acc.token; delete acc.me; save(); } }
    return { ok: r.status === 200, status: r.status, data: r.data || {} };
  });
  ipcMain.handle('acct:report', async (_e, b) => {
    const body = b && typeof b === 'object' ? {
      product: String(b.product || '').slice(0, 60), text: String(b.text || '').slice(0, 4000), info: String(b.info || '').slice(0, 20000),
      steps: String(b.steps || '').slice(0, 1500), expected: String(b.expected || '').slice(0, 500), often: String(b.often || '').slice(0, 20),
      launcher: app.getVersion(), installed: String(b.installed || '').slice(0, 40)
    } : {};
    const r = await call('/api/report', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const url = r.data && /^https:\/\/discord\.com\/channels\/\d+\/\d+(\/\d+)?$/.test(r.data.url || '') ? r.data.url : '';
    return r.status === 200 ? { ok: true, url } : { ok: false, need: r.data.need || '', error: r.data.error || "Couldn't send the report right now." };
  });
}

// The Discord panel asks the service too (finding people); same login, same rules.
async function community(act, q) {
  const r = await call('/api/community?do=' + act + (q ? '&q=' + encodeURIComponent(String(q).slice(0, 32)) : ''));
  return { ok: r.status === 200, status: r.status, data: r.data || {} };
}
const myId = () => { load(); return acc.me && acc.me.user ? String(acc.me.user.id || '') : ''; };

module.exports = { setup, setAccess, fetchLink, accessOn, community, myId };

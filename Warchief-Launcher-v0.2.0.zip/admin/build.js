// Builds the launcher's Setup.exe and sends launcher updates to players as GitHub releases.
// Uses electron-builder (settings in package.json "build"). server.js adds these routes with one line.
// Your GitHub token is only passed to the build as GH_TOKEN and is never written to the log.
'use strict';
const fs = require('fs');
const path = require('path');
const { spawn, exec } = require('child_process');

module.exports = function buildRoutes({ ROOT, readJSON, cfg, PORT }) {
  const PKG = path.join(ROOT, 'package.json');
  const DIST = path.join(ROOT, 'dist');
  const SETUP = 'Warchief-Launcher-Setup.exe'; // same as "artifactName" in package.json
  const MAX_LOG = 400;
  const STEP_NAMES = {
    tools: 'Getting the build tools',
    pack: 'Packing the launcher',
    setup: `Making ${SETUP}`,
    upload: 'Sending it to GitHub',
    notes: 'Adding what\'s new to the release'
  };

  const bad = (msg, status = 400) => Object.assign(new Error(msg), { status });
  const B = { running: false, kind: '', version: '', from: '', steps: [], log: [], started: 0, ended: 0, ok: null, error: '', releaseUrl: '', setupUrl: '', fixedSymlink: false, notes: '' };

  const pkgVersion = () => (readJSON(PKG, {}) || {}).version || '0.0.0';
  const parseV = v => String(v || '').replace(/^v/i, '').split('.').slice(0, 3).map(x => parseInt(x, 10) || 0);
  const cmpV = (a, b) => { const x = parseV(a), y = parseV(b); for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1; return 0; };
  function bumpV(v, kind) {
    const [a, b, c] = parseV(v);
    return kind === 'major' ? `${a + 1}.0.0` : kind === 'minor' ? `${a}.${b + 1}.0` : `${a}.${b}.${c + 1}`;
  }
  function setPkgVersion(v) {
    const text = fs.readFileSync(PKG, 'utf8');
    if (!/"version"\s*:\s*"[^"]*"/.test(text)) throw new Error('package.json has no version');
    fs.writeFileSync(PKG, text.replace(/("version"\s*:\s*")[^"]*(")/, `$1${v}$2`));
  }

  // ---------- GitHub ----------
  async function gh(method, url, body) {
    const token = cfg().token;
    const headers = { Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'Warchief-Admin' };
    if (token) headers.Authorization = 'Bearer ' + token;
    if (body) headers['Content-Type'] = 'application/json';
    const res = await fetch('https://api.github.com' + url, { method, headers, body: body ? JSON.stringify(body) : undefined });
    const text = await res.text();
    let data; try { data = JSON.parse(text); } catch { data = text; }
    if (!res.ok) throw Object.assign(new Error((data && data.message) || `GitHub said ${res.status}`), { status: res.status });
    return data;
  }
  async function latestRelease(repo) {
    try {
      const r = await gh('GET', `/repos/${repo}/releases/latest`);
      const setup = (r.assets || []).find(a => a.name === SETUP);
      return { tag: r.tag_name, version: String(r.tag_name || '').replace(/^v/i, ''), publishedAt: r.published_at, url: r.html_url, downloads: setup ? setup.download_count : 0, hasSetup: !!setup };
    } catch (e) {
      if (e.status === 404) return null; // no launcher released yet
      throw e;
    }
  }

  // ---------- Running the tools ----------
  const clean = s => {
    let t = String(s).replace(/\x1b\[[0-9;?]*[A-Za-z]/g, '').replace(/\r/g, '');
    const token = cfg().token;
    if (token) t = t.split(token).join('***');
    return t;
  };
  function addLog(text) {
    for (const line of clean(text).split('\n')) {
      if (!line.trim()) continue;
      B.log.push(line.slice(0, 500));
      noticeStep(line);
    }
    if (B.log.length > MAX_LOG) B.log.splice(0, B.log.length - MAX_LOG);
  }
  function step(id, state, note) {
    const s = B.steps.find(x => x.id === id); if (!s) return;
    if (state === 'active') B.steps.forEach(x => { if (x.state === 'active' && x.id !== id) x.state = 'done'; });
    s.state = state;
    if (note !== undefined) s.note = note;
  }
  // Follows electron-builder's output to show which step it's on.
  function noticeStep(line) {
    if (/•\s*downloading/i.test(line) && /electron-v\d/i.test(line)) return step('pack', 'active', 'Downloading Electron (first build only)');
    if (/•\s*packaging/i.test(line)) return step('pack', 'active', '');
    if (/•\s*building/i.test(line) && /nsis/i.test(line)) return step('setup', 'active');
    if (/•\s*(publishing|uploading)/i.test(line)) return step('upload', 'active');
  }
  let child = null;
  function run(cmd, args, opts) {
    return new Promise(resolve => {
      addLog(`> ${[path.basename(cmd), ...args].join(' ')}`);
      child = spawn(cmd, args, { cwd: ROOT, windowsHide: true, ...opts });
      child.stdout.on('data', d => addLog(d));
      child.stderr.on('data', d => addLog(d));
      child.on('error', e => { addLog(String(e.message || e)); resolve(-1); });
      child.on('close', code => { child = null; resolve(code); });
    });
  }
  // Known Windows problem in electron-builder: unpacking its signing tools fails with "Cannot create symbolic link"
  // (two macOS files the Windows build never uses). Everything else was unpacked, so the folder is put where
  // electron-builder looks for it, and the build runs again. Same fix people use by hand.
  function fixSymlinkProblem() {
    const text = B.log.join('\n');
    if (!/Cannot create symbolic link/i.test(text)) return false;
    const m = text.match(/((?:[A-Za-z]:)?[\\/][^\n:]*?[\\/]winCodeSign)[\\/](\d+)[\\/]/);
    const v = text.match(/winCodeSign-(\d+\.\d+\.\d+)/);
    if (!m || !v) return false;
    const from = path.join(m[1], m[2]), to = path.join(m[1], `winCodeSign-${v[1]}`);
    try {
      if (fs.existsSync(to)) return true;
      if (!fs.existsSync(from)) return false;
      fs.renameSync(from, to);
      addLog(`Fixed the known "symbolic link" problem: moved the signing tools to ${to}. Trying again.`);
      return true;
    } catch (e) { addLog(`Couldn't fix the "symbolic link" problem by itself: ${e.message}`); return false; }
  }
  function lastError() {
    const lines = B.log.filter(l => /⨯|error|failed|cannot|denied|not found/i.test(l) && !/^>/.test(l));
    return (lines[lines.length - 1] || '').trim().slice(0, 300);
  }

  async function build({ kind, bump, notes }) {
    const c = cfg();
    const publish = kind === 'publish';
    const repo = c.catalogRepo || '';
    Object.assign(B, { running: true, kind, version: '', from: pkgVersion(), log: [], started: Date.now(), ended: 0, ok: null, error: '', releaseUrl: '', setupUrl: '', fixedSymlink: false, notes: notes || '' });
    B.steps = ['tools', 'pack', 'setup', ...(publish ? ['upload'] : []), ...(publish && notes ? ['notes'] : [])].map(id => ({ id, name: STEP_NAMES[id], state: 'waiting', note: '' }));
    // Keeps the Admin running while this works, even if its tab gets closed.
    const keepAlive = setInterval(() => {
      fetch(`http://127.0.0.1:${PORT}/api/heartbeat`, { method: 'POST', headers: { 'X-Admin': '1' } }).catch(() => {});
    }, 20000);
    let changedVersion = false;
    try {
      if (publish) {
        const latest = await latestRelease(repo);
        const base = latest && cmpV(latest.version, B.from) > 0 ? latest.version : B.from;
        B.version = bumpV(base, bump);
        setPkgVersion(B.version);
        changedVersion = true;
        addLog(`Launcher version ${B.from} → ${B.version}`);
      } else B.version = B.from;

      step('tools', 'active', 'The first time downloads about 200 MB and takes a few minutes');
      const npm = await run('npm', ['install', '--no-audit', '--no-fund'], { shell: true });
      if (npm !== 0) throw new Error("Couldn't get the build tools. Check your internet and try again.");
      step('tools', 'done', '');

      const cli = path.join(ROOT, 'node_modules', 'electron-builder', 'cli.js');
      if (!fs.existsSync(cli)) throw new Error('The build tool is missing after installing. Try again.');
      const args = [cli, '--win', 'nsis', '--publish', publish ? 'always' : 'never'];
      if (publish) {
        const [owner, name] = repo.split('/');
        args.push(`-c.publish.provider=github`, `-c.publish.owner=${owner}`, `-c.publish.repo=${name}`, '-c.publish.releaseType=release');
      }
      // Only your Admin's token, and only when sending (never one left in Windows' settings).
      const env = { ...process.env };
      delete env.GH_TOKEN; delete env.GITHUB_TOKEN;
      if (publish) env.GH_TOKEN = c.token;
      step('pack', 'active');
      let code = await run(process.execPath, args, { env });
      if (code !== 0 && fixSymlinkProblem()) { B.fixedSymlink = true; code = await run(process.execPath, args, { env }); }
      if (code !== 0) throw new Error(`The build stopped${lastError() ? ': ' + lastError() : '.'}`);
      B.steps.forEach(s => { if (s.id !== 'notes') s.state = 'done'; });

      if (publish) {
        B.setupUrl = `https://github.com/${repo}/releases/latest/download/${SETUP}`;
        try {
          const r = await gh('GET', `/repos/${repo}/releases/tags/v${B.version}`);
          B.releaseUrl = r.html_url;
          if (notes) {
            step('notes', 'active');
            await gh('PATCH', `/repos/${repo}/releases/${r.id}`, { body: notes });
            step('notes', 'done');
          }
        } catch (e) {
          addLog(`The update went out, but GitHub didn't take the "what's new" text: ${e.message}`);
          step('notes', 'failed');
        }
      }
      B.ok = true;
    } catch (e) {
      B.ok = false;
      B.error = e.message;
      B.steps.forEach(s => { if (s.state === 'active') s.state = 'failed'; });
      if (changedVersion) { try { setPkgVersion(B.from); addLog(`Launcher version put back to ${B.from}`); } catch { /* leave it */ } }
    } finally {
      clearInterval(keepAlive);
      B.running = false;
      B.ended = Date.now();
    }
  }

  const view = () => ({ ...B, log: B.log.slice(-200) });

  return {
    'GET /api/build/state': async () => {
      const c = cfg();
      return { version: pkgVersion(), repo: c.catalogRepo || '', connected: !!c.token, setupName: SETUP, hasSetup: fs.existsSync(path.join(DIST, SETUP)), build: view() };
    },

    'GET /api/build/latest': async () => {
      const repo = cfg().catalogRepo;
      if (!repo) return { latest: null };
      return { latest: await latestRelease(repo), shareUrl: `https://github.com/${repo}/releases/latest/download/${SETUP}` };
    },

    'POST /api/build/start': async b => {
      if (B.running) throw bad('A build is already running');
      const kind = b.kind === 'publish' ? 'publish' : 'test';
      const bump = ['patch', 'minor', 'major'].includes(b.bump) ? b.bump : 'patch';
      const c = cfg();
      if (kind === 'publish') {
        if (!c.token) throw bad('Connect GitHub first, in GitHub settings');
        if (!/^[\w.-]+\/[\w.-]+$/.test(c.catalogRepo || '')) throw bad('Choose where to publish first, in GitHub settings');
      }
      build({ kind, bump, notes: String(b.notes || '').trim().slice(0, 20000) }); // runs in the background; the page asks for progress
      return { build: view() };
    },

    'POST /api/build/open-folder': async () => {
      fs.mkdirSync(DIST, { recursive: true });
      const cmd = process.platform === 'win32' ? `explorer "${DIST}"` : process.platform === 'darwin' ? `open "${DIST}"` : `xdg-open "${DIST}"`;
      exec(cmd, () => {});
      return { ok: true };
    }
  };
};

// Warchief Admin: a small local server for the Admin page.
// It only listens on this PC (127.0.0.1). Your GitHub token stays in admin/data/config.json on this PC.
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
let AdmZip = null;
try { AdmZip = require('adm-zip'); } catch { /* installed by Open Admin.bat */ }

const ROOT = path.resolve(__dirname, '..');
const PUB = path.join(__dirname, 'public');
const DATA = path.join(__dirname, 'data');
const PORT = Number(process.env.ADMIN_PORT) || 5179;
const HOST = '127.0.0.1';
const ALLOWED_HOSTS = new Set([`127.0.0.1:${PORT}`, `localhost:${PORT}`]);
const F = {
  config: path.join(DATA, 'config.json'),
  draft: path.join(DATA, 'draft.json'),
  published: path.join(DATA, 'published.json'),
  inspect: path.join(DATA, 'inspect-cache.json'),
  preview: path.join(DATA, 'preview-catalog.json'),
  launcherConfig: path.join(ROOT, 'launcher.config.json')
};
const MAX_RELEASES = 5;           // newest releases shown per addon
const MAX_ZIP_BYTES = 150 * 1024 * 1024;

fs.mkdirSync(DATA, { recursive: true });
const readJSON = (f, fallback) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return fallback; } };
function writeJSON(f, v) {
  const tmp = f + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(v, null, 2));
  fs.renameSync(tmp, f);
}
const pkg = readJSON(path.join(ROOT, 'package.json'), { version: '0.0.0' });

// ---------- Starting data ----------
function seedProduct(id, name, short, type, requires, repo, icon, changelogUrl) {
  return { id, name, short, icon, type, requires, game: 'retail', repo, enabled: true, changelogUrl, release: null, beta: null };
}
function seedDraft() {
  return {
    schema: 1,
    games: [
      { id: 'retail', name: 'Retail', short: 'Retail', title: 'World of Warcraft Retail', folder: '_retail_', badge: 'R' },
      { id: 'forever', name: 'WoW: Forever', short: 'Forever', title: 'World of Warcraft: Forever', folder: '_classic_beta_', badge: 'F' }
    ],
    links: { news: '', discord: '', support: '', curseforge: 'https://www.curseforge.com/wow/addons/warchiefs-war-diary', github: 'https://github.com/NolvusMadeIt' },
    news: [{ id: 'n1', title: 'Testers wanted', body: 'Help shape the next guides.', linkLabel: 'Join the Discord', link: 'discord', date: new Date().toISOString() }],
    products: [
      seedProduct('wwd', 'Warchiefs War Diary', 'WD', 'main', null, 'NolvusMadeIt/Warchiefs_Diary_WoW_AddOn', 'logo', 'https://www.curseforge.com/wow/addons/warchiefs-war-diary'),
      seedProduct('compass', 'War Diary - Compass', 'CP', 'plugin', 'wwd', 'NolvusMadeIt/Warchiefs_Diary_Compass', 'badge', ''),
      seedProduct('journal', 'War Diary - Journal', 'JN', 'plugin', 'wwd', 'NolvusMadeIt/Warchiefs_Diary_Journal', 'badge', ''),
      seedProduct('todo', 'War Diary - ToDo', 'TD', 'plugin', 'wwd', 'NolvusMadeIt/Warchiefs_Diary_ToDo', 'badge', '')
    ]
  };
}

const STAFF = require('./staff');
const cfg = () => readJSON(F.config, {});
const saveCfg = c => writeJSON(F.config, c);
function getDraft() {
  let d = readJSON(F.draft, null);
  if (!d) { d = seedDraft(); writeJSON(F.draft, d); }
  // Discord login for downloads is always on (Members & access page, admin/access.js)
  const acc = require('./access').normalize(d.access);
  // Tickets settings and the to-do list (admin/staff.js)
  // The To-do board replaces the old list of to-do items (they become cards on it)
  const tks = STAFF.normalizeTickets(d.tickets), board = STAFF.normalizeRoadmap(d.roadmap, d.todo);
  if (JSON.stringify(acc) !== JSON.stringify(d.access) || JSON.stringify(tks) !== JSON.stringify(d.tickets) || JSON.stringify(board) !== JSON.stringify(d.roadmap) || d.todo) {
    d.access = acc; d.tickets = tks; d.roadmap = board; delete d.todo; writeJSON(F.draft, d);
  }
  return d;
}

function catalogUrl(c) {
  if (!c.catalogRepo) return '';
  return `https://raw.githubusercontent.com/${c.catalogRepo}/${c.branch || 'main'}/${c.catalogPath || 'catalog.json'}`;
}
// Tells the launcher on this PC where to read the addon list from.
function writeLauncherConfig() {
  const c = cfg();
  const out = { catalogUrl: catalogUrl(c), usePreview: !!c.usePreview, previewFile: 'admin/data/preview-catalog.json' };
  writeJSON(F.launcherConfig, out);
  if (c.usePreview) writeJSON(F.preview, buildCatalog(getDraft(), new Date().toISOString()));
}

function buildCatalog(draft, publishedAt) {
  return {
    schema: 1,
    publishedAt,
    launcher: { version: pkg.version },
    games: draft.games || [],
    links: draft.links || {},
    news: draft.news || [],
    products: draft.products || [],
    // Members & access page: Discord login for downloads, always on (admin/access.js)
    access: require('./access').normalize(draft.access),
    // Tickets page (the access service reads it) and To-do page (the launcher's To-do tab)
    tickets: STAFF.publishTickets(draft.tickets),
    roadmap: STAFF.publishRoadmap(draft.roadmap)
  };
}

// ---------- GitHub ----------
async function gh(method, url, body, { auth = true } = {}) {
  const token = cfg().token;
  const headers = { Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'Warchief-Admin' };
  if (auth && token) headers.Authorization = 'Bearer ' + token;
  if (body) headers['Content-Type'] = 'application/json';
  const res = await fetch('https://api.github.com' + url, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  if (!res.ok) {
    let msg = (data && data.message) || `GitHub said ${res.status}`;
    if (res.status === 401) msg = 'GitHub rejected the token. Connect again in GitHub settings.';
    if (res.status === 403 && /rate limit/i.test(msg)) msg = 'GitHub is limiting requests right now. Connect your token or wait a few minutes.';
    const err = new Error(msg); err.status = res.status; throw err;
  }
  return data;
}

const versionFromTag = tag => String(tag || '').trim().replace(/^v(?=\d)/i, '');

async function listReleases(repo) {
  if (!/^[\w.-]+\/[\w.-]+$/.test(repo || '')) throw Object.assign(new Error('Pick a repo first'), { status: 400 });
  const list = await gh('GET', `/repos/${repo}/releases?per_page=${MAX_RELEASES + 5}`);
  return list.filter(r => !r.draft).slice(0, MAX_RELEASES).map(r => ({
    tag: r.tag_name,
    version: versionFromTag(r.tag_name),
    name: r.name || r.tag_name,
    prerelease: !!r.prerelease,
    publishedAt: r.published_at,
    notes: String(r.body || '').slice(0, 8000),
    htmlUrl: r.html_url,
    assets: (r.assets || []).map(a => ({ name: a.name, size: a.size, url: a.browser_download_url }))
  }));
}

// Release files of a private repo can only be downloaded through GitHub's API with your token.
async function downloadRelease(url) {
  const token = cfg().token;
  const m = url.match(/^https:\/\/github\.com\/([\w.-]+\/[\w.-]+)\/releases\/download\/([^/]+)\/([^/?#]+)$/);
  if (token && m) {
    try {
      const rel = await gh('GET', `/repos/${m[1]}/releases/tags/${encodeURIComponent(decodeURIComponent(m[2]))}`);
      const asset = (rel.assets || []).find(a => a.name === decodeURIComponent(m[3]));
      if (asset) {
        const r = await fetch(`https://api.github.com/repos/${m[1]}/releases/assets/${asset.id}`, {
          headers: { Authorization: 'Bearer ' + token, Accept: 'application/octet-stream', 'User-Agent': 'Warchief-Admin' }, redirect: 'manual'
        });
        const loc = r.headers.get('location');
        if (loc && r.status >= 300 && r.status < 400) return fetch(loc, { headers: { 'User-Agent': 'Warchief-Admin' } });
        if (r.ok) return r;
      }
    } catch { /* fall back to the public link */ }
  }
  return fetch(url, { headers: { 'User-Agent': 'Warchief-Admin' } });
}

// Downloads a release zip and reads which addon folders and .toc versions are inside.
async function inspectZip(url) {
  if (!AdmZip) throw new Error('The zip reader is missing. Close the Admin and open it again with Open Admin.bat.');
  if (!/^https:\/\/github\.com\/[\w.-]+\/[\w.-]+\/releases\/download\//.test(url)) throw Object.assign(new Error('That download link is not a GitHub release file'), { status: 400 });
  const cache = readJSON(F.inspect, {});
  if (cache[url]) return cache[url];
  const res = await downloadRelease(url);
  if (!res.ok) throw new Error(`Couldn't download the zip (${res.status})${res.status === 404 ? '. If the repo is private, connect GitHub again with a token that can read private repos.' : ''}`);
  const len = Number(res.headers.get('content-length') || 0);
  if (len > MAX_ZIP_BYTES) throw new Error('That zip is too big to be an addon');
  const buf = Buffer.from(await res.arrayBuffer());
  const zip = new AdmZip(buf);
  const entries = zip.getEntries();
  const folders = [];
  for (const e of entries) {
    const name = e.entryName.replace(/\\/g, '/');
    if (!name.includes('/')) continue;
    const top = name.split('/')[0];
    if (!top || top.startsWith('.') || top === '__MACOSX') continue;
    if (!folders.includes(top)) folders.push(top);
  }
  const tocs = [];
  for (const e of entries) {
    const name = e.entryName.replace(/\\/g, '/');
    const m = name.match(/^([^/]+)\/([^/]+\.toc)$/i);
    if (!m || !folders.includes(m[1])) continue;
    const text = e.getData().toString('utf8');
    const get = key => { const r = text.match(new RegExp('^##\\s*' + key + '\\s*:\\s*(.+)$', 'im')); return r ? r[1].trim() : ''; };
    tocs.push({ folder: m[1], file: m[2], version: get('Version'), interface: get('Interface'), title: get('Title').replace(/\|c[0-9a-f]{8}|\|r/gi, '') });
  }
  const result = { folders, tocs, size: buf.length };
  cache[url] = result;
  writeJSON(F.inspect, cache);
  return result;
}

// ---------- HTTP plumbing ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.ico': 'image/x-icon', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf' };

function send(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function serveFile(res, base, rel) {
  const file = path.resolve(base, '.' + path.sep + rel);
  if (!file.startsWith(base + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > 5 * 1024 * 1024) { reject(new Error('Too much data')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { reject(new Error('Bad data')); } });
    req.on('error', reject);
  });
}

function stateFor() {
  const c = cfg();
  return {
    connected: !!c.token, login: c.login || '', catalogRepo: c.catalogRepo || '', branch: c.branch || 'main',
    catalogPath: c.catalogPath || 'catalog.json', catalogUrl: catalogUrl(c), usePreview: !!c.usePreview,
    launcherVersion: pkg.version, draft: getDraft(), published: readJSON(F.published, null), maxReleases: MAX_RELEASES
  };
}

// ---------- Auto close when the page has been closed for a while ----------
let lastBeat = Date.now();
const STARTUP_GRACE = 5 * 60 * 1000, IDLE_LIMIT = 3 * 60 * 1000;
const bootAt = Date.now();
let sawPage = false;
setInterval(() => {
  const idle = Date.now() - lastBeat;
  if ((sawPage && idle > IDLE_LIMIT) || (!sawPage && Date.now() - bootAt > STARTUP_GRACE)) process.exit(0);
}, 15000).unref();

// ---------- Routes ----------
const routes = {
  'GET /api/state': async () => stateFor(),

  'POST /api/heartbeat': async () => { lastBeat = Date.now(); sawPage = true; return { ok: true }; },

  'POST /api/shutdown': async (_b, res) => { send(res, 200, { ok: true }); setTimeout(() => process.exit(0), 200); return null; },

  'POST /api/connect': async b => {
    const token = String(b.token || '').trim();
    if (!/^[\w-]{20,255}$/.test(token)) throw Object.assign(new Error("That doesn't look like a GitHub token"), { status: 400 });
    const c = cfg();
    const user = await (async () => {
      const res = await fetch('https://api.github.com/user', { headers: { Authorization: 'Bearer ' + token, Accept: 'application/vnd.github+json', 'User-Agent': 'Warchief-Admin' } });
      if (!res.ok) throw Object.assign(new Error('GitHub rejected that token. Check you copied all of it.'), { status: 400 });
      return res.json();
    })();
    c.token = token; c.login = user.login;
    saveCfg(c);
    return stateFor();
  },

  'POST /api/disconnect': async () => { const c = cfg(); delete c.token; delete c.login; saveCfg(c); return stateFor(); },

  'GET /api/repos': async () => {
    if (!cfg().token) throw Object.assign(new Error('Connect GitHub first'), { status: 400 });
    const out = [];
    for (let page = 1; page <= 5; page++) {
      const list = await gh('GET', `/user/repos?per_page=100&sort=pushed&page=${page}`);
      out.push(...list.map(r => ({ fullName: r.full_name, description: r.description || '', private: !!r.private, archived: !!r.archived, fork: !!r.fork, defaultBranch: r.default_branch })));
      if (list.length < 100) break;
    }
    return out;
  },

  'GET /api/branches': async (_b, _res, q) => {
    const repo = q.get('repo') || '';
    if (!/^[\w.-]+\/[\w.-]+$/.test(repo)) throw Object.assign(new Error('Pick a repo first'), { status: 400 });
    const list = await gh('GET', `/repos/${repo}/branches?per_page=100`);
    return list.map(b => b.name);
  },

  'GET /api/releases': async (_b, _res, q) => listReleases(q.get('repo')),

  'POST /api/inspect': async b => inspectZip(String(b.url || '')),

  'PUT /api/draft': async b => {
    const d = b.draft;
    if (!d || !Array.isArray(d.products) || !Array.isArray(d.games)) throw Object.assign(new Error('Draft looks broken, not saved'), { status: 400 });
    d.access = require('./access').normalize(d.access); // Discord login is always on
    d.tickets = STAFF.normalizeTickets(d.tickets);
    d.roadmap = STAFF.normalizeRoadmap(d.roadmap, d.todo);
    delete d.todo;
    writeJSON(F.draft, d);
    if (cfg().usePreview) writeJSON(F.preview, buildCatalog(d, new Date().toISOString()));
    return { ok: true };
  },

  'POST /api/settings': async b => {
    const c = cfg();
    if (b.catalogRepo !== undefined) {
      if (b.catalogRepo && !/^[\w.-]+\/[\w.-]+$/.test(b.catalogRepo)) throw Object.assign(new Error('Pick a repo from the list'), { status: 400 });
      c.catalogRepo = b.catalogRepo || '';
      if (b.branch === undefined) {
        c.branch = 'main';
        if (c.catalogRepo) { try { c.branch = (await gh('GET', `/repos/${c.catalogRepo}`)).default_branch || 'main'; } catch { /* keep main */ } }
      }
    }
    if (b.branch !== undefined) {
      if (b.branch && !/^[\w./-]+$/.test(b.branch)) throw Object.assign(new Error('That branch name looks wrong'), { status: 400 });
      c.branch = b.branch || 'main';
    }
    if (b.usePreview !== undefined) c.usePreview = !!b.usePreview;
    saveCfg(c);
    writeLauncherConfig();
    return stateFor();
  },

  'POST /api/create-repo': async b => {
    const name = String(b.name || '').trim();
    if (!/^[\w.-]{1,100}$/.test(name)) throw Object.assign(new Error('Use letters, numbers, - or _ for the repo name'), { status: 400 });
    const r = await gh('POST', '/user/repos', { name, description: 'Addon list for Warchief Launcher', private: false, auto_init: true });
    const c = cfg(); c.catalogRepo = r.full_name; c.branch = r.default_branch || 'main'; saveCfg(c);
    writeLauncherConfig();
    return stateFor();
  },

  'POST /api/discard': async () => {
    const pub = readJSON(F.published, null);
    const d = pub && pub.catalog ? { schema: 1, games: pub.catalog.games, links: pub.catalog.links, news: pub.catalog.news, products: pub.catalog.products, ...(pub.catalog.access ? { access: pub.catalog.access } : {}), ...(pub.catalog.tickets ? { tickets: pub.catalog.tickets } : {}), ...(pub.catalog.roadmap ? { roadmap: pub.catalog.roadmap } : {}) } : seedDraft();
    writeJSON(F.draft, d);
    if (cfg().usePreview) writeJSON(F.preview, buildCatalog(d, new Date().toISOString()));
    return stateFor();
  },

  'POST /api/publish': async () => {
    const c = cfg();
    if (!c.token) throw Object.assign(new Error('Connect GitHub first'), { status: 400 });
    if (!c.catalogRepo) throw Object.assign(new Error('Choose where to publish in GitHub settings first'), { status: 400 });
    const draft = getDraft();
    const missing = draft.products.filter(p => p.enabled !== false && !(p.release && p.release.version)).map(p => p.name);
    if (missing.length) throw Object.assign(new Error(`Pick a version for ${missing.join(', ')}, or hide ${missing.length > 1 ? 'them' : 'it'} first`), { status: 400 });
    const unfinished = STAFF.problems(draft);
    if (unfinished.length) throw Object.assign(new Error(unfinished[0] + (unfinished.length > 1 ? ` (and ${unfinished.length - 1} more)` : '')), { status: 400 });
    const before = (readJSON(F.published, null) || {}).catalog || null;
    const now = new Date().toISOString();
    const catalog = buildCatalog(draft, now);
    const filePath = c.catalogPath || 'catalog.json';
    const branch = c.branch || 'main';
    let sha;
    try { sha = (await gh('GET', `/repos/${c.catalogRepo}/contents/${filePath}?ref=${encodeURIComponent(branch)}`)).sha; }
    catch (e) { if (e.status !== 404) throw e; }
    const versions = draft.products.filter(p => p.enabled !== false).map(p => `${p.name} ${p.release.version}`).join(', ');
    const put = await gh('PUT', `/repos/${c.catalogRepo}/contents/${filePath}`, {
      message: `Publish addon list: ${versions}`.slice(0, 200),
      content: Buffer.from(JSON.stringify(catalog, null, 2) + '\n').toString('base64'),
      branch, ...(sha ? { sha } : {})
    });
    const published = { at: now, commitUrl: put.commit && put.commit.html_url, catalog };
    writeJSON(F.published, published);
    writeLauncherConfig();
    // Updates the to-do list and ticket panel the bot posted in Discord (when logged in on the Tickets page)
    let discord = [];
    try { discord = await staff.afterPublish(catalog, before); } catch { discord = []; }
    return { ...stateFor(), discord };
  }
};
// Discord posts page (admin/discord.js)
Object.assign(routes, require('./discord')({ DATA, readJSON, writeJSON }));
// Build the launcher page (admin/build.js)
Object.assign(routes, require('./build')({ ROOT, readJSON, cfg, PORT }));
// Members & access page (admin/access.js)
Object.assign(routes, require('./access')());
// Tickets and To-do pages (admin/staff.js)
const staff = STAFF({ DATA, readJSON, writeJSON, getDraft, PORT });
Object.assign(routes, staff.routes);

const server = http.createServer(async (req, res) => {
  if (!ALLOWED_HOSTS.has(String(req.headers.host || '').toLowerCase())) { res.writeHead(403); return res.end(); }
  const url = new URL(req.url, `http://${req.headers.host}`);
  const p = decodeURIComponent(url.pathname);

  if (p.startsWith('/api/')) {
    if (req.method !== 'GET' && req.headers['x-admin'] !== '1') return send(res, 403, { error: 'Blocked' });
    const fn = routes[`${req.method} ${p}`];
    if (!fn) return send(res, 404, { error: 'Unknown action' });
    try {
      const body = req.method === 'GET' ? {} : await readBody(req);
      const out = await fn(body, res, url.searchParams);
      if (out !== null) send(res, 200, out);
    } catch (e) {
      send(res, e.status && e.status < 500 ? e.status : 500, { error: e.message || 'Something went wrong', ...(e.extra || {}) });
    }
    return;
  }
  if (req.method !== 'GET') { res.writeHead(405); return res.end(); }
  if (p === '/auth') return staff.auth(req, res, url); // back from the Discord login (Tickets page)
  if (p === '/' || p === '/index.html') return serveFile(res, PUB, 'index.html');
  if (p.startsWith('/assets/')) return serveFile(res, path.join(ROOT, 'assets'), p.slice(8));
  if (['/node_modules/@fontsource/', '/node_modules/@tabler/icons-webfont/', '/node_modules/marked/lib/', '/node_modules/dompurify/dist/'].some(x => p.startsWith(x))) return serveFile(res, path.join(ROOT, 'node_modules'), p.slice(14));
  if (p === '/lib/markdown.js') return serveFile(res, path.join(ROOT, 'src', 'js'), 'markdown.js');
  return serveFile(res, PUB, p.slice(1));
});

function openBrowser() {
  if (process.env.NO_OPEN) return;
  const url = `http://127.0.0.1:${PORT}/`;
  const cmd = process.platform === 'win32' ? `start "" "${url}"` : process.platform === 'darwin' ? `open "${url}"` : `xdg-open "${url}"`;
  exec(cmd, () => {});
}

server.on('error', e => {
  if (e.code === 'EADDRINUSE') { openBrowser(); setTimeout(() => process.exit(0), 500); }
  else { console.error(e); process.exit(1); }
});
server.listen(PORT, HOST, () => {
  console.log(`Warchief Admin is running at http://127.0.0.1:${PORT}/`);
  getDraft();
  try { writeLauncherConfig(); } catch { /* not fatal */ }
  openBrowser();
});

// Tickets and To-do pages (server side).
// Staff log in with Discord through the access service, the same login the launcher uses. The login pass is kept
// in admin/data/staff.json on this PC only. The Tickets settings and the to-do list live in the draft and go out
// with Publish; which Discord messages the bot posted (the ticket panel, the to-do list) is kept in staff-posts.json.
'use strict';
const crypto = require('crypto');
const path = require('path');

const ID = /^\d{5,25}$/;
const STAFF_DEFAULT = ['1564352290221985902', '1564353338105929810']; // Admins, Mods
const STYLES = ['primary', 'secondary', 'success', 'danger'];
// Emoji Discord accepts on buttons (older, widely supported ones, so a post never fails on a new emoji)
const EMOJI = ['', '❓', '🐛', '💬', '🛠️', '💡', '📝', '📦', '🎮', '🧭', '📖', '⭐', '🤝', '⚠️', '✅', '🔒', '🎫', '📣'];
const STATUSES = ['planned', 'doing', 'done'];

const str = (v, n) => String(v == null ? '' : v).slice(0, n);
const obj = v => (v && typeof v === 'object' && !Array.isArray(v) ? v : {});
const newId = p => p + crypto.randomBytes(4).toString('hex');

function defaultTypes() {
  return [
    { id: 'help', label: 'Get help', emoji: '❓', style: 'primary', welcome: 'Thanks for reaching out! A member of the Warchief team will be with you soon. Add anything else that helps, like screenshots, while you wait.',
      questions: [{ label: 'What do you need help with?', style: 'paragraph', required: true, placeholder: '' }] },
    { id: 'bug', label: 'Report a bug', emoji: '🐛', style: 'danger', welcome: 'Thanks for the report! A member of the Warchief team will look at it soon. Screenshots or your support info (launcher: Options → Support) help a lot.',
      questions: [
        { label: 'Which addon or plugin?', style: 'short', required: true, placeholder: 'War Diary, Compass, Journal, ToDo…' },
        { label: 'What happened?', style: 'paragraph', required: true, placeholder: '' },
        { label: 'How can we make it happen again?', style: 'paragraph', required: false, placeholder: '' }] },
    { id: 'other', label: 'Something else', emoji: '💬', style: 'secondary', welcome: 'Thanks for reaching out! A member of the Warchief team will be with you soon.',
      questions: [{ label: "What's it about?", style: 'paragraph', required: true, placeholder: '' }] }
  ];
}

// Fixes the shape only. Half-written buttons stay while you edit them; Publish asks you to finish them.
function normalizeTickets(t) {
  const x = obj(t);
  const ids = v => (Array.isArray(v) ? [...new Set(v.map(String).filter(s => ID.test(s)))] : null);
  const seen = new Set();
  const types = (Array.isArray(x.types) ? x.types : defaultTypes()).slice(0, 10).map(y => {
    const o = obj(y);
    let id = /^[\w-]{1,30}$/.test(o.id || '') ? o.id : newId('t');
    while (seen.has(id)) id = newId('t');
    seen.add(id);
    return {
      id, label: str(o.label, 80), emoji: EMOJI.includes(o.emoji) ? o.emoji : '', style: STYLES.includes(o.style) ? o.style : 'secondary',
      welcome: str(o.welcome, 2000),
      questions: (Array.isArray(o.questions) ? o.questions : []).slice(0, 5).map(q => {
        const z = obj(q);
        return { label: str(z.label, 45), style: z.style === 'short' ? 'short' : 'paragraph', required: z.required !== false, placeholder: str(z.placeholder, 100) };
      })
    };
  });
  const panel = obj(x.panel);
  return {
    categoryId: ID.test(x.categoryId || '') ? String(x.categoryId) : '',
    logChannelId: ID.test(x.logChannelId || '') ? String(x.logChannelId) : '',
    staffRoles: ids(x.staffRoles) && ids(x.staffRoles).length ? ids(x.staffRoles) : STAFF_DEFAULT.slice(),
    pingStaff: x.pingStaff !== false,
    types,
    panel: {
      title: typeof panel.title === 'string' ? str(panel.title, 256) : 'Need help?',
      description: typeof panel.description === 'string' ? str(panel.description, 2000) : 'Press a button below to open a private ticket with the Warchief team.'
    }
  };
}
function normalizeTodo(list) {
  const seen = new Set();
  return (Array.isArray(list) ? list : []).slice(0, 200).map(y => {
    const o = obj(y);
    let id = /^[\w-]{1,40}$/.test(o.id || '') ? o.id : newId('td');
    while (seen.has(id)) id = newId('td');
    seen.add(id);
    return { id, title: str(o.title, 150), notes: str(o.notes, 2000), status: STATUSES.includes(o.status) ? o.status : 'planned', addon: /^[\w-]{0,40}$/.test(o.addon || '') ? (o.addon || '') : '', at: typeof o.at === 'string' ? o.at : '' };
  });
}
// ---------- To-do board (columns of cards, like a GitHub Projects board) ----------
const COLORS = ['gray', 'blue', 'green', 'yellow', 'orange', 'red', 'pink', 'purple'];
const STATUS_COLUMN = { doing: ['In Progress', '🚧', 'orange'], planned: ['Planned', '📋', 'blue'], done: ['Done', '✅', 'green'] };
function newBoard() {
  return { title: 'Development Roadmap', columns: [
    { id: 'c-testing', name: 'In Testing', emoji: '🔧', color: 'yellow', cards: [] },
    { id: 'c-progress', name: 'In Progress', emoji: '🚧', color: 'orange', cards: [] },
    { id: 'c-planned', name: 'Planned', emoji: '📋', color: 'blue', cards: [] },
    { id: 'c-release', name: 'Release', emoji: '🚀', color: 'green', cards: [] }
  ] };
}
// Fixes the shape only. Half-written cards stay while you edit them; Publish asks you to finish them.
function normalizeRoadmap(r, oldTodo) {
  let x = r && typeof r === 'object' && Array.isArray(r.columns) ? r : null;
  if (!x) {
    x = newBoard();
    // The old To-do items (Planned / In progress / Done) become cards on the board
    for (const t of normalizeTodo(oldTodo)) {
      const [name, emoji, color] = STATUS_COLUMN[t.status];
      let col = x.columns.find(c => c.name === name);
      if (!col) { col = { id: 'c-' + t.status, name, emoji, color, cards: [] }; x.columns.push(col); }
      col.cards.push({ id: t.id, title: t.title, text: t.notes, addon: t.addon, at: t.at });
    }
  }
  const seen = new Set();
  const uid = (v, p) => { let id = /^[\w-]{1,40}$/.test(v || '') ? v : newId(p); while (seen.has(id)) id = newId(p); seen.add(id); return id; };
  return {
    title: str(x.title, 120),
    columns: x.columns.slice(0, 12).map(c => {
      const o = obj(c);
      return {
        id: uid(o.id, 'c'), name: str(o.name, 40), emoji: str(o.emoji, 8), color: COLORS.includes(o.color) ? o.color : 'gray',
        cards: (Array.isArray(o.cards) ? o.cards : []).slice(0, 100).map(k => {
          const z = obj(k);
          return { id: uid(z.id, 'k'), title: str(z.title, 120), text: str(z.text, 1000), addon: /^[\w-]{0,40}$/.test(z.addon || '') ? (z.addon || '') : '', at: typeof z.at === 'string' ? z.at : '' };
        })
      };
    })
  };
}
// What the launchers read: finished columns and cards only.
function publishRoadmap(r) {
  const n = normalizeRoadmap(r);
  return { title: n.title.trim(), columns: n.columns.filter(c => c.name.trim()).map(c => ({ ...c, name: c.name.trim(), cards: c.cards.filter(k => k.title.trim()).map(k => ({ ...k, title: k.title.trim(), text: k.text.trim() })) })) };
}

// What the launchers and the access service read (only finished items and buttons).
function publishTickets(t) {
  const n = normalizeTickets(t);
  return { ...n, types: n.types.filter(y => y.label.trim()).map(y => ({ ...y, label: y.label.trim(), questions: y.questions.filter(q => q.label.trim()) })) };
}
const publishTodo = list => normalizeTodo(list).filter(t => t.title.trim()).map(t => ({ ...t, title: t.title.trim() }));
// Problems that should stop a Publish
function problems(draft) {
  const out = [];
  const t = normalizeTickets(draft.tickets);
  t.types.forEach((y, i) => {
    if (!y.label.trim()) out.push(`Ticket button ${i + 1} has no name (Tickets page)`);
    y.questions.forEach((q, j) => { if (!q.label.trim()) out.push(`"${y.label || 'Ticket button ' + (i + 1)}" question ${j + 1} has no text (Tickets page)`); });
  });
  const b = normalizeRoadmap(draft.roadmap);
  b.columns.forEach((c, i) => {
    if (!c.name.trim()) out.push(`To-do column ${i + 1} has no name (To-do page)`);
    if (c.cards.some(k => !k.title.trim())) out.push(`A card in "${c.name || 'column ' + (i + 1)}" has no title (To-do page)`);
  });
  return out;
}

module.exports = function ({ DATA, readJSON, writeJSON, getDraft, PORT }) {
  const FILE = path.join(DATA, 'staff.json');
  const POSTS = path.join(DATA, 'staff-posts.json');
  const ACTS = new Set(['me', 'guild', 'status', 'tickets', 'ticket', 'reply', 'claim', 'close', 'panel', 'todo', 'setup', 'connect', 'refresh']);
  const POST_ACTS = new Set(['reply', 'claim', 'close', 'panel', 'todo', 'setup', 'connect', 'refresh']);
  let pending = null; // the login waiting for the browser
  const fail = (status, msg, extra) => Object.assign(new Error(msg), { status, extra });
  const service = () => require('./access').normalize(getDraft().access).service;
  const okBase = u => /^https:\/\/[\w.-]+(:\d+)?$/i.test(u) || /^http:\/\/127\.0\.0\.1:\d+$/.test(u);
  const posts = () => Object.assign({ panel: null, todo: null }, readJSON(POSTS, {}));
  const savePost = (k, v) => { const p = posts(); p[k] = v; writeJSON(POSTS, p); };

  async function call(act, { id, body } = {}) {
    const st = readJSON(FILE, {});
    if (!st.token) throw fail(401, 'Log in with Discord first.', { need: 'login' });
    const base = service();
    if (!okBase(base)) throw fail(400, 'Set the access service address on the Members & access page first.');
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 45000);
    try {
      const post = POST_ACTS.has(act);
      const r = await fetch(`${base}/api/staff?do=${act}${id ? '&id=' + encodeURIComponent(id) : ''}`, {
        method: post ? 'POST' : 'GET', signal: ctl.signal,
        headers: { Authorization: 'Bearer ' + st.token, 'User-Agent': 'Warchief-Admin', 'Cache-Control': 'no-cache', ...(post ? { 'Content-Type': 'application/json' } : {}) },
        body: post ? JSON.stringify(body || {}) : undefined
      });
      let data = null; try { data = await r.json(); } catch { data = null; }
      if (r.status === 401) { writeJSON(FILE, {}); throw fail(401, 'Your Discord login ran out. Log in again.', { need: 'login' }); }
      if (!data) throw fail(502, r.status === 404 ? "The access service doesn't have tickets yet. It needs the new version deployed." : `The access service answered ${r.status}.`);
      if (!r.ok) throw fail(r.status === 403 ? 403 : r.status === 400 ? 400 : 502, data.error || `The access service said ${r.status}`, data.need ? { need: data.need } : undefined);
      return data;
    } catch (e) {
      if (e.name === 'AbortError') throw fail(504, 'The access service took too long to answer. Try again.');
      if (e.status) throw e;
      throw fail(502, "Couldn't reach the access service: " + (e.cause && e.cause.code ? e.cause.code : e.message));
    } finally { clearTimeout(timer); }
  }

  async function postPanel(channelId, tickets) {
    const p = posts();
    const same = p.panel && p.panel.channelId === channelId;
    // Moving it to another channel: the old panel is taken away
    const old = p.panel && !same ? { removeChannelId: p.panel.channelId, removeMessageId: p.panel.messageId } : {};
    const r = await call('panel', { body: { channelId, messageId: same ? p.panel.messageId : '', tickets: publishTickets(tickets), ...old } });
    savePost('panel', { channelId: r.channelId, messageId: r.messageId, at: new Date().toISOString() });
    return r;
  }
  // The To-do page draws the board as a picture and sends it here with the board it shows (sent).
  async function postTodo(b) {
    const channelId = String(b.channelId || '');
    const p = posts();
    const same = p.todo && p.todo.channelId === channelId;
    const old = p.todo && !same ? { removeChannelId: p.todo.channelId, removeMessageId: p.todo.messageId } : {};
    const r = await call('todo', { body: { channelId, messageId: same ? p.todo.messageId : '', image: String(b.image || ''), alt: String(b.alt || '').slice(0, 1024), title: String(b.title || '').slice(0, 200), ...old } });
    savePost('todo', { channelId: r.channelId, messageId: r.messageId, at: new Date().toISOString(), sent: String(b.sent || '') });
    return r;
  }

  const routes = {
    'GET /api/staff/state': async () => {
      const st = readJSON(FILE, {});
      return { loggedIn: !!st.token, user: st.user || null, service: service(), posts: posts(), emoji: EMOJI };
    },
    'POST /api/staff/login': async () => {
      const base = service();
      if (!okBase(base)) throw fail(400, 'Set the access service address on the Members & access page first.');
      pending = { nonce: crypto.randomBytes(24).toString('base64url'), until: Date.now() + 10 * 60000 };
      return { url: `${base}/api/login?port=${PORT}&nonce=${pending.nonce}` };
    },
    'POST /api/staff/logout': async () => { writeJSON(FILE, {}); return { loggedIn: false }; },
    // Everything the Tickets and To-do pages ask the access service
    'POST /api/staff/call': async b => {
      const act = String(b.do || '');
      if (!ACTS.has(act)) throw fail(400, 'Unknown action');
      if (act === 'panel') return postPanel(String(b.channelId || ''), getDraft().tickets);
      if (act === 'todo') return postTodo(b);
      const out = await call(act, { id: b.id ? String(b.id) : '', body: b.body });
      if (act === 'me' && out && out.user) { const st = readJSON(FILE, {}); if (st.token) writeJSON(FILE, { ...st, user: out.user }); }
      return out;
    },
    'POST /api/staff/forget-post': async b => { if (['panel', 'todo'].includes(b.kind)) savePost(b.kind, null); return posts(); }
  };

  // Discord sends the browser back here after the login (http://127.0.0.1:5179/auth).
  function auth(req, res, url) {
    const q = url.searchParams;
    const page = (title, text, go) => {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(`<!doctype html><meta charset="utf-8"><title>${title}</title>${go ? `<meta http-equiv="refresh" content="1;url=${go}">` : ''}
<body style="margin:0;min-height:100vh;display:grid;place-items:center;background:#0d0b19;color:#ece8fb;font:16px/1.5 system-ui,sans-serif">
<div style="max-width:460px;padding:28px 32px;background:#161230;border:1px solid #2c2650;border-top:2px solid #f2c75c;text-align:center"><h1 style="font-size:21px;margin:0 0 8px">${title}</h1><p style="margin:0;color:#b9b2dc">${text}</p>
<p><a style="color:#f2c75c" href="/?page=tickets">Back to the Admin</a></p></div></body>`);
    };
    const nonce = q.get('nonce') || '';
    const ok = pending && pending.until > Date.now() && nonce.length === pending.nonce.length && crypto.timingSafeEqual(Buffer.from(nonce), Buffer.from(pending.nonce));
    if (!ok) return page('That login link expired', 'Go back to the Admin and press Log in with Discord again.');
    pending = null;
    if (q.get('error')) return page(q.get('error') === 'cancelled' ? 'Login cancelled' : "Discord login didn't work", 'Go back to the Admin and try again.');
    const token = q.get('token') || '';
    if (!/^[\w-]+\.[\w-]+$/.test(token)) return page("Discord login didn't work", 'Go back to the Admin and try again.');
    writeJSON(FILE, { token, at: new Date().toISOString() });
    return page('Logged in', 'Taking you back to the Admin…', '/?page=tickets');
  }

  // After Publish: keep the Discord to-do message and ticket panel in step with what was published.
  async function afterPublish(catalog, before) {
    const out = [];
    if (!readJSON(FILE, {}).token) return out;
    const p = posts();
    const prev = before || {};
    // The bot reads the new ticket settings right away (it would otherwise take up to a few minutes)
    if (JSON.stringify(publishTickets(prev.tickets)) !== JSON.stringify(catalog.tickets) || !prev.tickets) {
      try {
        const r = await call('refresh', { body: {} });
        out.push(r.ready ? { ok: true, text: 'The ticket bot has the new settings' } : { ok: true, text: 'The ticket bot has the new settings, but no ticket category is chosen yet' });
      } catch (e) {
        out.push({ ok: true, text: e.status === 404 || /Unknown action|new version/.test(e.message) ? 'The ticket bot picks up the new settings within about 5 minutes' : 'The ticket bot picks up the new settings within a minute' });
      }
    }
    if (p.panel && p.panel.channelId && JSON.stringify(publishTickets(prev.tickets)) !== JSON.stringify(catalog.tickets)) {
      try { await postPanel(p.panel.channelId, catalog.tickets); out.push({ ok: true, text: 'Ticket panel updated in Discord' }); }
      catch (e) { out.push({ ok: false, text: 'Ticket panel in Discord: ' + e.message }); }
    }
    return out;
  }

  return { routes, auth, afterPublish };
};
Object.assign(module.exports, { normalizeTickets, normalizeTodo, normalizeRoadmap, publishRoadmap, publishTickets, publishTodo, problems, EMOJI, COLORS });

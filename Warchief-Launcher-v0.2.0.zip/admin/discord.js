// Discord posts for the Admin page: post, edit and delete messages in your Discord server through webhooks.
// Webhook links and posts stay on this PC in admin/data/discord.json, pictures in admin/data/discord-media/
// (the whole admin/data folder is in .gitignore). server.js adds these routes with one line.
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

module.exports = function discordRoutes({ DATA, readJSON, writeJSON }) {
  const FILE = path.join(DATA, 'discord.json');
  const MEDIA = path.join(DATA, 'discord-media');
  const UA = 'DiscordBot (https://github.com/NolvusMadeIt, 0.1.0)';
  const MAX_IMAGE = Math.floor(3.5 * 1024 * 1024);
  const MIME = { png: 'image/png', jpg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp' };
  const HOOK_RE = /^https:\/\/(?:(?:canary|ptb)\.)?discord(?:app)?\.com\/api(?:\/v\d+)?\/webhooks\/(\d{15,25})\/([\w-]{20,200})\/?$/;
  const MEDIA_RE = /^m[0-9a-f]{12}\.(png|jpg|gif|webp)$/;
  const POST_RE = /^p[0-9a-f]{12}$/;
  const HOOKID_RE = /^w[0-9a-f]{12}$/;
  const COLOR_RE = /^#[0-9a-f]{6}$/i;
  // What decides "changed since posted". The page compares the same list the same way.
  const SNAP_KEYS = ['title', 'body', 'style', 'color', 'image', 'icon', 'ping'];

  fs.mkdirSync(MEDIA, { recursive: true });

  const bad = (msg, status = 400) => Object.assign(new Error(msg), { status });
  const newId = prefix => prefix + crypto.randomBytes(6).toString('hex');
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const snapOf = p => JSON.stringify(SNAP_KEYS.map(k => (p[k] === undefined ? null : p[k])));

  // ---------- Long posts become several messages ----------
  // Same rules, word for word, as admin/public/discord.js, so the boxes on the page match what gets sent.
  // Cuts after a line, else after a sentence, else after a space; only mid-word if there's no space at all.
  // Joined back together, the pieces are exactly the original text.
  function splitText(text, firstMax, max) {
    const parts = [];
    if (firstMax < 1 || max < 1) return [text];
    for (let pos = 0; ;) {
      const lim = parts.length ? max : firstMax;
      const rest = text.slice(pos);
      const lead = parts.length ? rest.length - rest.trimStart().length : 0;
      if (rest.trimEnd().length - lead <= lim) { parts.push(rest); return parts; }
      const win = rest.slice(0, lead + lim), min = lead + Math.floor(lim / 2);
      let cut = win.lastIndexOf('\n') + 1;
      if (cut <= min) {
        cut = 0;
        const re = /[.!?]['")\]]*\s+/g;
        for (let m; (m = re.exec(win));) if (m.index + m[0].length > min) cut = m.index + m[0].length;
      }
      if (cut <= min) cut = Math.max(win.lastIndexOf(' '), win.lastIndexOf('\t')) + 1;
      if (cut <= min) { cut = win.length; const c = win.charCodeAt(cut - 1); if (c >= 0xd800 && c <= 0xdbff) cut--; }
      parts.push(rest.slice(0, cut));
      pos += cut;
    }
  }
  // A simple message holds 2000 characters (the first one also holds @everyone and the title, the last one the
  // picture link). A card holds 4096 characters of text.
  // A whole line like ![picture](https://…) is a picture in the text. Discord can't show a picture in the middle
  // of a message, so the text is also cut after every picture line: the picture shows under its own message.
  const PIC_LINE = /^[ \t]*!\[([^\]\n]*)\]\((https?:\/\/[^\s)]+)\)[ \t]*$/;
  function picChunks(body) {
    const out = [], re = /^[ \t]*!\[[^\]\n]*\]\(https?:\/\/[^\s)]+\)[ \t]*(?:\n|$)/gm;
    let pos = 0;
    for (let m; (m = re.exec(body));) { pos = m.index + m[0].length; out.push(pos); if (!m[0].length) re.lastIndex++; }
    const chunks = [];
    let from = 0;
    for (const end of out) { chunks.push(body.slice(from, end)); from = end; }
    const rest = body.slice(from);
    if (chunks.length && !rest.trim()) chunks[chunks.length - 1] += rest; else chunks.push(rest);
    return chunks;
  }
  function partsOf(p) {
    const body = String(p.body || '');
    let first = 4096, max = 4096;
    if (p.style === 'simple') {
      const title = String(p.title || '').trim();
      const head = (p.ping ? 10 : 0) + (title ? title.length + 4 : 0);
      const tail = p.image && p.image.kind === 'url' ? p.image.url.length + 1 : 0;
      first = 2000 - head - tail; max = 2000 - tail;
    }
    const parts = [];
    picChunks(body).forEach((c, k) => parts.push(...splitText(c, k ? max : first, max)));
    return parts;
  }
  const partText = (t, i) => (i ? t.trim() : t.replace(/\s+$/, ''));
  // Message i's text, and the picture line at its end (if there is one), taken out of the text.
  function partBody(parts, i) {
    const lines = String(parts[i] || '').replace(/\s+$/, '').split('\n');
    const m = lines[lines.length - 1].match(PIC_LINE);
    return m ? { text: partText(lines.slice(0, -1).join('\n'), i), pic: m[2] } : { text: partText(parts[i] || '', i), pic: '' };
  }

  function load() {
    const d = readJSON(FILE, null) || {};
    return { webhooks: Array.isArray(d.webhooks) ? d.webhooks : [], posts: Array.isArray(d.posts) ? d.posts : [] };
  }
  const save = d => writeJSON(FILE, d);

  // The page never gets the webhook link itself, only what it needs to show.
  const publicHook = h => ({
    id: h.id, label: h.label, name: h.name || '', addedAt: h.addedAt,
    avatar: h.avatar ? `https://cdn.discordapp.com/avatars/${h.hookId}/${h.avatar}.png?size=128` : ''
  });
  const publicPost = p => ({
    ...p,
    link: p.sent && p.sent.guildId && p.sent.channelId && p.sent.messageId
      ? `https://discord.com/channels/${p.sent.guildId}/${p.sent.channelId}/${p.sent.messageId}` : ''
  });
  // version: which page this server code belongs to. The page asks for an Admin restart when they don't
  // match (the server only loads this file when it starts). Raise it together with SERVER_VERSION in the page.
  const state = d => ({ version: 3, webhooks: d.webhooks.map(publicHook), posts: d.posts.map(publicPost) });

  // ---------- Talking to Discord ----------
  function firstError(e) {
    if (!e || typeof e !== 'object') return '';
    if (Array.isArray(e._errors) && e._errors[0] && e._errors[0].message) return e._errors[0].message;
    for (const k of Object.keys(e)) { const m = firstError(e[k]); if (m) return m; }
    return '';
  }
  function discordError(status, data) {
    const code = data && data.code;
    if (code === 10015 || status === 401 || code === 50027) return "Discord says this channel's webhook doesn't work any more. It may have been deleted in Discord. Remove the channel here and add it again.";
    if (code === 10008) return 'That message is gone from Discord.';
    if (status === 403) return "Discord didn't allow that. Check the webhook still has permission to post in its channel.";
    if (status === 413) return 'That picture is too big for Discord.';
    if (status >= 500) return 'Discord is having trouble right now. Try again in a minute.';
    const detail = firstError(data && data.errors);
    return `Discord didn't accept the post${detail ? ': ' + detail : (data && data.message ? ': ' + data.message : '')}`;
  }
  async function discord(method, url, payload, files) {
    for (let attempt = 0; attempt < 4; attempt++) {
      const headers = { 'User-Agent': UA };
      let body;
      if (files && files.length) {
        body = new FormData();
        body.append('payload_json', JSON.stringify(payload));
        files.forEach((f, i) => body.append(`files[${i}]`, new Blob([f.buf], { type: f.type }), f.filename));
      } else if (payload !== undefined) {
        body = JSON.stringify(payload);
        headers['Content-Type'] = 'application/json';
      }
      let res;
      try { res = await fetch(url, { method, headers, body }); }
      catch { throw bad("Couldn't reach Discord. Check your internet and try again.", 502); }
      if (res.status === 429) {
        let wait = Number(res.headers.get('retry-after')) || 1;
        try { const j = await res.json(); if (j && j.retry_after) wait = Number(j.retry_after); } catch { /* keep the header value */ }
        if (wait > 15) throw bad('Discord says slow down. Wait a minute and try again.', 429);
        await sleep(wait * 1000 + 250);
        continue;
      }
      if (res.status === 204) return null;
      const text = await res.text();
      let data = null;
      try { data = JSON.parse(text); } catch { data = text; }
      if (!res.ok) {
        const err = bad(discordError(res.status, data), res.status === 404 ? 404 : res.status >= 500 ? 502 : 400);
        err.code = data && data.code;
        err.discordStatus = res.status;
        throw err;
      }
      return data;
    }
    throw bad('Discord is busy. Try again in a minute.', 429);
  }

  // ---------- Pictures ----------
  function sniff(buf) {
    if (buf.length > 8 && buf[0] === 0x89 && buf.toString('ascii', 1, 4) === 'PNG') return 'png';
    if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
    if (buf.length > 6 && buf.toString('ascii', 0, 4) === 'GIF8') return 'gif';
    if (buf.length > 12 && buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'webp';
    return null;
  }
  // Removes picture files no post uses any more (only ones older than an hour, so a fresh upload is never caught).
  function cleanMedia(d) {
    try {
      const used = new Set();
      d.posts.forEach(p => ['image', 'icon'].forEach(k => { if (p[k] && p[k].kind === 'upload') used.add(p[k].media); }));
      const hourAgo = Date.now() - 3600 * 1000;
      for (const f of fs.readdirSync(MEDIA)) {
        if (!MEDIA_RE.test(f) || used.has(f)) continue;
        const full = path.join(MEDIA, f);
        if (fs.statSync(full).mtimeMs < hourAgo) fs.unlinkSync(full);
      }
    } catch { /* not important */ }
  }

  // ---------- Posts ----------
  function cleanPic(v) {
    if (!v || typeof v !== 'object') return null;
    if (v.kind === 'upload' && MEDIA_RE.test(String(v.media || ''))) return { kind: 'upload', media: v.media, name: String(v.name || '').slice(0, 120) };
    if (v.kind === 'url' && /^https:\/\/\S+$/i.test(String(v.url || '')) && String(v.url).length <= 2000) return { kind: 'url', url: String(v.url) };
    return null;
  }
  function cleanPost(b, old) {
    const now = new Date().toISOString();
    const hook = String(b.webhookId || '');
    return {
      id: b.id,
      title: String(b.title || '').slice(0, 300),
      body: String(b.body || '').slice(0, 500000),
      style: b.style === 'simple' ? 'simple' : 'card',
      color: COLOR_RE.test(String(b.color || '')) ? String(b.color).toLowerCase() : '#f2c75c',
      image: cleanPic(b.image),
      icon: cleanPic(b.icon),
      ping: !!b.ping,
      // A posted message stays in its channel.
      webhookId: old && old.sent ? old.webhookId : (HOOKID_RE.test(hook) ? hook : ''),
      createdAt: old ? old.createdAt : now,
      updatedAt: now,
      sent: old ? old.sent : null
    };
  }

  function fileFor(pic, base) {
    const ext = pic.media.split('.').pop();
    let buf;
    try { buf = fs.readFileSync(path.join(MEDIA, pic.media)); }
    catch { throw bad(`The ${base === 'icon' ? 'icon' : 'picture'} file is missing on this PC. Pick it again.`); }
    return { buf, type: MIME[ext], filename: `${base}.${ext}` };
  }
  // Message i of a simple post: @everyone and the title go on the first one, the picture link on the last.
  function simpleContent(p, i = 0, parts = partsOf(p)) {
    const title = p.title.trim();
    const imageUrl = p.image && p.image.kind === 'url' && i === parts.length - 1 ? p.image.url : '';
    return [i === 0 && p.ping ? '@everyone' : '', i === 0 && title ? `## ${title}` : '', partBody(parts, i).text, imageUrl].filter(Boolean).join('\n');
  }
  // Builds what Discord gets for message i of the post. On an edit, the files list is always sent in full,
  // because Discord keeps only the files it's told to. The picture goes on the last message, the icon on the first.
  function buildMessage(p, isEdit, i = 0, parts = partsOf(p)) {
    const files = [];
    const first = i === 0, last = i === parts.length - 1;
    const payload = { allowed_mentions: { parse: first && p.ping ? ['everyone'] : [] } };
    const which = parts.length > 1 ? `Message ${i + 1} of ${parts.length}` : '';
    if (p.style === 'simple') {
      if (last && p.image && p.image.kind === 'upload') files.push(fileFor(p.image, 'image'));
      const content = simpleContent(p, i, parts), inPic = partBody(parts, i).pic;
      if (!content && !files.length && !inPic) throw bad(which ? `${which} is empty` : 'Write something first');
      if (content.length > 2000) throw bad(`A simple message can be up to 2000 characters. ${which || 'This one'} is ${content.length}.`);
      payload.content = content || null;
      payload.embeds = inPic ? [{ image: { url: inPic } }] : []; // a picture from the text, under this message
    } else {
      const pic = (v, base) => {
        if (!v) return null;
        if (v.kind === 'url') return v.url;
        const f = fileFor(v, base); files.push(f);
        return `attachment://${f.filename}`;
      };
      const pb = partBody(parts, i), color = parseInt(p.color.slice(1), 16);
      const title = first ? p.title.trim() : '', body = pb.text;
      const embed = { color };
      if (title) embed.title = title;
      if (body) embed.description = body;
      // The card's big picture: a picture from the text, and the post's Picture on the last card.
      const pics = [pb.pic, last ? pic(p.image, 'image') : null].filter(Boolean);
      const image = pics[0] || null; if (image) embed.image = { url: image };
      const icon = first ? pic(p.icon, 'icon') : null; if (icon) embed.thumbnail = { url: icon };
      if (!title && !body && !image) throw bad(which ? `${which} is empty` : 'Write a title or some text first');
      if (title.length > 256) throw bad(`A card title can be up to 256 characters. This one is ${title.length}.`);
      if (body.length > 4096) throw bad(`Card text can be up to 4096 characters. ${which || 'This one'} is ${body.length}.`);
      payload.content = first && p.ping ? '@everyone' : null;
      payload.embeds = [embed, ...pics.slice(1).map(url => ({ color, image: { url } }))];
    }
    if (isEdit || files.length) payload.attachments = files.map((f, n) => ({ id: n, filename: f.filename }));
    if (!isEdit && payload.content === null) delete payload.content;
    return { payload, files };
  }
  const sentIds = s => (s && s.messageId ? [s.messageId, ...(Array.isArray(s.more) ? s.more : [])] : []);

  // ---------- Routes ----------
  return {
    'GET /api/discord/state': async () => state(load()),

    'POST /api/discord/channel-add': async b => {
      const m = String(b.url || '').trim().match(HOOK_RE);
      if (!m) throw bad("That doesn't look like a Discord webhook link. It starts with https://discord.com/api/webhooks/");
      const url = `https://discord.com/api/webhooks/${m[1]}/${m[2]}`;
      if (load().webhooks.some(h => h.hookId === m[1])) throw bad('That channel is already added');
      let info;
      try { info = await discord('GET', url); }
      catch (e) { throw bad(e.discordStatus === 401 || e.discordStatus === 404 ? "Discord says that webhook link doesn't work. Copy it again from Discord." : e.message, e.status); }
      const d = load();
      const h = {
        id: newId('w'), hookId: m[1], url,
        label: String(b.label || '').trim().slice(0, 60) || info.name || 'Discord channel',
        name: info.name || '', avatar: info.avatar || '', channelId: info.channel_id || '', guildId: info.guild_id || '',
        addedAt: new Date().toISOString()
      };
      d.webhooks.push(h);
      // Posts made with this webhook before it was removed work again.
      d.posts.forEach(p => {
        if (p.sent && p.sent.hookId === h.hookId && !d.webhooks.some(x => x.id === p.webhookId)) { p.webhookId = h.id; p.sent.webhookId = h.id; }
      });
      save(d);
      return { ...state(d), added: h.id };
    },

    'POST /api/discord/channel-update': async b => {
      const d = load();
      const h = d.webhooks.find(x => x.id === b.id);
      if (!h) throw bad('That channel is gone', 404);
      h.label = String(b.label || '').trim().slice(0, 60) || h.name || 'Discord channel';
      save(d);
      return state(d);
    },

    'POST /api/discord/channel-remove': async b => {
      const d = load();
      d.webhooks = d.webhooks.filter(x => x.id !== b.id);
      save(d);
      return state(d);
    },

    'PUT /api/discord/post': async b => {
      const src = b.post || {};
      if (!POST_RE.test(String(src.id || ''))) throw bad('That post looks broken, not saved');
      const d = load();
      const i = d.posts.findIndex(x => x.id === src.id);
      const p = cleanPost(src, i >= 0 ? d.posts[i] : null);
      if (i >= 0) d.posts[i] = p; else d.posts.unshift(p);
      save(d);
      cleanMedia(d);
      return { post: publicPost(p) };
    },

    'POST /api/discord/media': async b => {
      const raw = String(b.data || '').replace(/^data:[^,]*,/, '');
      const buf = Buffer.from(raw, 'base64');
      if (!buf.length) throw bad("That picture couldn't be read");
      if (buf.length > MAX_IMAGE) throw bad('That picture is too big. Pick one up to 3.5 MB.');
      const ext = sniff(buf);
      if (!ext) throw bad('Pick a PNG, JPG, GIF or WEBP picture');
      const media = `${newId('m')}.${ext}`;
      fs.writeFileSync(path.join(MEDIA, media), buf);
      return { media, name: String(b.name || 'picture').replace(/[\\/:*?"<>|]+/g, '').slice(0, 120), size: buf.length };
    },

    'GET /api/discord/media': async (_b, res, q) => {
      const id = q.get('id') || '';
      if (!MEDIA_RE.test(id)) throw bad('Unknown picture', 404);
      fs.readFile(path.join(MEDIA, id), (err, data) => {
        if (err) { res.writeHead(404); return res.end(); }
        res.writeHead(200, { 'Content-Type': MIME[id.split('.').pop()], 'Cache-Control': 'private, max-age=86400' });
        res.end(data);
      });
      return null;
    },

    'POST /api/discord/send': async b => {
      const d = load();
      const p = d.posts.find(x => x.id === b.id);
      if (!p) throw bad('That post is gone. Go back to All posts.', 404);
      const h = d.webhooks.find(x => x.id === p.webhookId);
      if (!h) throw bad(p.sent ? "This post's channel was removed here. Add the channel again to update it." : 'Pick a channel first');
      const snap = snapOf(p);
      const now = new Date().toISOString();
      const editing = !!(p.sent && p.sent.messageId);
      const parts = partsOf(p);
      parts.forEach((_, i) => buildMessage(p, true, i, parts)); // check every message before sending any
      let olds = sentIds(p.sent), firstGone = false, channelId = editing ? p.sent.channelId : '';
      const ids = [];
      let failed = null;
      // Message by message, in order. Old messages are changed in place; extra ones are added at the bottom.
      for (let i = 0; i < parts.length; i++) {
        try {
          let done = false;
          while (olds.length && !done) {
            const { payload, files } = buildMessage(p, true, i, parts);
            try { await discord('PATCH', `${h.url}/messages/${olds[0]}`, payload, files); ids.push(olds.shift()); done = true; }
            catch (e) {
              if (e.code !== 10008) throw e;
              if (!ids.length && olds[0] === p.sent.messageId) { firstGone = true; break; }
              olds.shift(); // this one was deleted in Discord; its text moves on
            }
          }
          if (firstGone) break;
          if (!done) {
            const { payload, files } = buildMessage(p, false, i, parts);
            const msg = await discord('POST', `${h.url}?wait=true`, payload, files);
            ids.push(msg.id);
            if (!channelId) channelId = msg.channel_id || h.channelId;
          }
        } catch (e) { failed = e; break; }
        if (i < parts.length - 1) await sleep(350); // keeps them in order and under Discord's speed limit
      }
      if (firstGone) {
        // The first message is gone, so the rest of this post is removed too and it can be posted again.
        for (const id of olds.slice(1)) { try { await discord('DELETE', `${h.url}/messages/${id}`); } catch { /* best effort */ } }
        const d2 = load(); const p2 = d2.posts.find(x => x.id === p.id);
        if (p2) { p2.sent = null; save(d2); }
        throw bad(`That message was deleted in Discord, so it could not be updated.${olds.length > 1 ? ' The rest of this post was removed from Discord too.' : ''} Press Post to Discord to post it again.`, 404);
      }
      // A shorter post than before: the leftover messages at the end are deleted.
      const keep = [];
      if (!failed) {
        for (const id of olds) {
          try { await discord('DELETE', `${h.url}/messages/${id}`); }
          catch (e) { if (e.code !== 10008) { keep.push(id); failed = failed || e; } }
        }
      } else keep.push(...olds);
      if (failed && !ids.length) throw failed; // nothing changed in Discord
      const all = ids.concat(keep);
      // Read the file again: the page may have saved newer typing while Discord was answering.
      const d2 = load();
      const p2 = d2.posts.find(x => x.id === p.id);
      if (p2 && all.length) {
        const ok = !failed;
        p2.sent = editing
          ? { ...p.sent, editedAt: now, messageId: all[0], more: all.slice(1), snap: ok ? snap : 'unfinished' }
          : { at: now, editedAt: null, messageId: all[0], more: all.slice(1), channelId, guildId: h.guildId, webhookId: h.id, hookId: h.hookId, snap: ok ? snap : 'unfinished' };
        save(d2);
      }
      if (failed) {
        const verb = editing ? 'Updated' : 'Posted';
        throw bad(`${verb} ${ids.length} of ${parts.length} messages, then Discord stopped: ${failed.message} Press Update on Discord to finish.`, failed.status || 502);
      }
      return { ...state(d2), result: editing ? 'updated' : 'posted' };
    },

    'POST /api/discord/delete': async b => {
      const d = load();
      const p = d.posts.find(x => x.id === b.id);
      if (!p) return state(d);
      if (b.fromDiscord && p.sent && p.sent.messageId) {
        const h = d.webhooks.find(x => x.id === p.webhookId);
        if (!h) throw bad("This post's channel was removed here, so it can't be deleted from Discord. Add the channel again, or untick the box to only remove it from this list.");
        const left = [];
        let err = null;
        for (const id of sentIds(p.sent)) {
          try { await discord('DELETE', `${h.url}/messages/${id}`); }
          catch (e) { if (e.code !== 10008) { left.push(id); err = err || e; } } // 10008: already gone from Discord
        }
        if (err) {
          const d1 = load(); const p1 = d1.posts.find(x => x.id === b.id);
          if (p1 && p1.sent) { p1.sent.messageId = left[0]; p1.sent.more = left.slice(1); save(d1); }
          throw err;
        }
      }
      const d2 = load();
      d2.posts = d2.posts.filter(x => x.id !== b.id);
      save(d2);
      cleanMedia(d2);
      return state(d2);
    }
  };
};

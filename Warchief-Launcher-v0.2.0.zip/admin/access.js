// Members & access page (server side): asks the access service on Vercel how its setup looks, and for the
// Discord server's roles. The settings themselves live in the draft (draft.access) and go out with Publish.
'use strict';

// Discord login for downloads is always on. These are the starting settings; the Members & access page changes them.
const ROLE = { member: '1564354159191400639', tester: '1564362388260782150', guide: '1564363328686653481', mods: '1564353338105929810', admins: '1564352290221985902' };
function normalize(a) {
  const x = a && typeof a === 'object' ? a : {};
  const ids = v => (Array.isArray(v) ? v.map(String).filter(id => /^\d{5,25}$/.test(id)) : null);
  return {
    enabled: true,
    service: typeof x.service === 'string' && x.service ? x.service.replace(/\/+$/, '') : 'https://warchief-access.vercel.app',
    memberRoles: ids(x.memberRoles) && ids(x.memberRoles).length ? ids(x.memberRoles) : [ROLE.member, ROLE.tester, ROLE.guide, ROLE.mods, ROLE.admins],
    testerRoles: ids(x.testerRoles) || [ROLE.tester, ROLE.mods, ROLE.admins],
    invite: typeof x.invite === 'string' && x.invite ? x.invite : 'https://discord.gg/pCjPx2c5s6',
    bugReports: x.bugReports !== false
  };
}

module.exports = function () {
  const okBase = u => /^https:\/\/[\w.-]+(:\d+)?$/i.test(u) || /^http:\/\/127\.0\.0\.1:\d+$/.test(u);
  async function call(service, path) {
    const base = String(service || '').trim().replace(/\/+$/, '');
    if (!okBase(base)) throw Object.assign(new Error('Put the service address in first, like https://warchief-access.vercel.app'), { status: 400 });
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 25000);
    try {
      const r = await fetch(base + path, { signal: ctl.signal, headers: { 'Cache-Control': 'no-cache', 'User-Agent': 'Warchief-Admin' } });
      const text = await r.text();
      let data = null; try { data = JSON.parse(text); } catch { data = null; }
      if (!data) {
        throw Object.assign(new Error(r.status === 404 ? "Nothing answers at that address yet. Check the spelling, and that the service is deployed."
          : r.status === 401 || r.status === 403 ? 'Vercel is asking for a login on that address. Use the main address (the one ending in .vercel.app without extra letters).'
            : `The service answered ${r.status}, not what the Admin expected.`), { status: 502 });
      }
      if (!r.ok) throw Object.assign(new Error(data.error || `The service said ${r.status}`), { status: 502 });
      return data;
    } catch (e) {
      if (e.name === 'AbortError') throw Object.assign(new Error('The service took too long to answer. Try again.'), { status: 504 });
      if (e.status) throw e;
      throw Object.assign(new Error("Couldn't reach the service: " + (e.cause && e.cause.code ? e.cause.code : e.message)), { status: 502 });
    } finally { clearTimeout(timer); }
  }
  return {
    'POST /api/access/test': async b => call(b.service, '/api/health?deep=1'),
    'POST /api/access/roles': async b => call(b.service, '/api/roles')
  };
};
module.exports.normalize = normalize;

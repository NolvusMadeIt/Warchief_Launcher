// To-do page for the Admin: the development board, like a GitHub Projects board. Columns (In Testing, In Progress,
// Planned, Release… you name them) with cards you drag between them. Players see it read-only in the launcher's
// To-do tab after you Publish. The Warchief bot posts a picture of the board in Discord and swaps it on every Publish.
(function () {
  'use strict';

  const W = () => window.WLAdmin;
  const K = () => window.WLStaff;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ti = n => `<i class="ti ti-${n}" aria-hidden="true"></i>`;
  const GUILD_ID = '1564085762755002508';
  const COLORS = [['gray', 'Gray'], ['blue', 'Blue'], ['green', 'Green'], ['yellow', 'Yellow'], ['orange', 'Orange'], ['red', 'Red'], ['pink', 'Pink'], ['purple', 'Purple']];
  const HEX = { gray: '#8b949e', blue: '#4493f8', green: '#3fb950', yellow: '#d29922', orange: '#db6d28', red: '#f85149', pink: '#db61a2', purple: '#a371f7' };
  const EMOJI = ['', '🔧', '🚧', '📋', '🚀', '✅', '🧪', '🐛', '💡', '🎯', '⏳', '🔥', '⭐', '🛠️', '🗺️', '📦', '🛡️', '📣', '❄️', '🧭'];
  const S = { drag: null, edit: null, channel: '', busy: false, auto: false };
  const B = () => W().draft().roadmap;
  const newId = p => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const addonName = id => ((W().draft().products || []).find(p => p.id === id) || {}).name || '';

  // The board the way Publish sends it (finished columns and cards only)
  function pubBoard(b) {
    const x = b || { title: '', columns: [] };
    return { title: (x.title || '').trim(), columns: (x.columns || []).filter(c => (c.name || '').trim()).map(c => ({ ...c, name: c.name.trim(), cards: (c.cards || []).filter(k => (k.title || '').trim()).map(k => ({ ...k, title: k.title.trim(), text: (k.text || '').trim() })) })) };
  }
  // A text copy of the board (the picture's description in Discord, for screen readers and search)
  function altText(b) {
    const lines = [b.title || 'Development Roadmap'];
    for (const c of b.columns) { lines.push(`${c.emoji ? c.emoji + ' ' : ''}${c.name}:`); for (const k of c.cards) lines.push(`- ${k.title}${k.text ? ': ' + k.text : ''}`); }
    const t = lines.join('\n');
    return t.length > 1000 ? t.slice(0, 997) + '…' : t;
  }

  // ---------- Page ----------
  function page() {
    // The Admin's server was started before the board arrived: it needs one restart to set the board up
    if (!B() || !Array.isArray(B().columns)) {
      return `<h1>To-do</h1><div class="card"><h2>Restart the Admin once</h2>
        <p>The To-do board is new, and this Admin was opened before it arrived. Close the Admin, then open it again with <b>Open Admin.bat</b>. Your other changes are saved.</p>
        <div class="row-actions"><button class="pbtn" data-action="shutdown">${ti('power')} Close Admin</button></div></div>`;
    }
    const b = B();
    const total = b.columns.reduce((a, c) => a + c.cards.length, 0);
    return `<h1>To-do</h1>
      <p class="lead">Your development board, like a GitHub Projects board. Players see it read-only in the launcher's To-do tab after you Publish, and the Warchief bot posts a picture of it in Discord.</p>
      <div class="card bd-top">
        <div class="field bd-title"><label for="bd-title">Board title</label><input id="bd-title" type="text" class="wide big-input" maxlength="120" value="${esc(b.title)}" placeholder="🛡️ Warchief's War Diary — Development Roadmap"></div>
        <div class="row-actions">
          <button class="sbtn" data-action="bd-col-add" ${b.columns.length >= 12 ? 'disabled' : ''}>${ti('layout-columns')} Add column</button>
          <button class="sbtn" data-action="bd-import">${ti('clipboard-text')} Paste a roadmap</button>
          <span class="muted small">${total} item${total === 1 ? '' : 's'} in ${b.columns.length} column${b.columns.length === 1 ? '' : 's'} · drag cards to move them</span>
        </div>
      </div>
      <div class="board" id="board">${b.columns.map(column).join('')}${b.columns.length ? '' : `<div class="empty">No columns yet. Press Add column, or Paste a roadmap.</div>`}</div>
      ${discordCard()}`;
  }
  function column(c, i) {
    return `<section class="bcol" data-c="${i}">
      <header class="bcol-head">
        <span class="bdot" style="background:${HEX[c.color] || HEX.gray}"></span>
        <span class="bname">${c.emoji ? esc(c.emoji) + ' ' : ''}${esc(c.name) || '<span class="warn-text">No name</span>'}</span>
        <span class="bcount">${c.cards.length}</span>
        <button class="tbtn" data-action="bd-col-edit" data-c="${i}" title="Edit column" aria-label="Edit column ${esc(c.name)}">${ti('dots')}</button>
      </header>
      <div class="bcards" data-drop="${i}">${c.cards.map((k, j) => card(k, i, j)).join('')}</div>
      <button class="badd" data-action="bd-card-add" data-c="${i}">${ti('plus')} Add item</button>
    </section>`;
  }
  function card(k, i, j) {
    const label = k.addon ? addonName(k.addon) : '';
    return `<div class="bcard" draggable="true" data-c="${i}" data-k="${j}" data-action="bd-card-edit" tabindex="0" title="Click to edit, drag to move">
      <div class="btitle">${esc(k.title) || '<span class="warn-text">No title</span>'}</div>
      ${k.text ? `<div class="btext">${esc(k.text)}</div>` : ''}
      ${label ? `<div class="bmeta"><span class="tag">${esc(label)}</span></div>` : ''}
    </div>`;
  }

  // ---------- Discord ----------
  function discordCard() {
    const intro = '<h2>In Discord</h2><p class="hint">The Warchief bot posts a picture of the board (read-only) and swaps in a fresh one on every Publish. Same message, no spam.</p>';
    const g = K().gate('Posting the board in Discord needs your Discord login.');
    if (g) return `<div class="card">${intro}</div>${g}`;
    K().ensureGuild();
    const st = K().state();
    const posted = st.posts && st.posts.todo;
    const ch = S.channel || (posted && posted.channelId) || '';
    const same = posted && posted.channelId === ch;
    return `<div class="card">${intro}${K().whoBar()}
      <div class="field"><label for="td-ch">Channel</label>${K().channelSelect('td-ch', ch, 'Choose a channel')}
        <p class="hint">Pick a channel members can read but not write in, like #announcements or a #roadmap channel.</p></div>
      <div class="row-actions"><button class="pbtn" data-action="td-post" ${S.busy ? 'disabled' : ''}>${S.busy ? `<span class="spin">${ti('loader-2')}</span>` : ti('send')} ${same ? 'Update in Discord' : posted ? 'Move it here' : 'Post in Discord'}</button>
        ${posted ? `<a class="sbtn" href="https://discord.com/channels/${GUILD_ID}/${esc(posted.channelId)}/${esc(posted.messageId)}" target="_blank" rel="noopener">${ti('external-link')} See it in Discord</a>` : ''}</div>
      ${posted ? `<p class="hint">Last sent ${esc(new Date(posted.at).toLocaleString())}. It shows the board as it is on this page.</p>` : '<p class="hint">It posts the board as it is on this page.</p>'}</div>`;
  }
  async function postBoard(ch, board, quiet) {
    S.busy = true; if (!quiet) K().refresh();
    try {
      const img = await window.WLBoardImage.draw(board, addonName);
      const r = await K().req('POST', '/api/staff/call', { do: 'todo', channelId: ch, image: img, alt: altText(board), title: board.title || 'Development Roadmap', sent: JSON.stringify(board) });
      K().setState(await K().req('GET', '/api/staff/state'));
      W().toast(r.updated ? 'Board updated in Discord' : r.removedOld ? 'Board moved in Discord. The old post is gone.' : 'Board posted in Discord');
    } catch (e) {
      if (e.need === 'login') { const st = K().state(); if (st) st.loggedIn = false; }
      W().toast((quiet ? 'Board in Discord: ' : '') + e.message, true);
    }
    S.busy = false; K().refresh();
  }
  // After Publish: the Discord picture follows the published board
  document.addEventListener('wl:published', async () => {
    let st = K() && K().state();
    if (!st) { try { st = await K().req('GET', '/api/staff/state'); K().setState(st); } catch { return; } }
    const posted = st && st.loggedIn && st.posts && st.posts.todo;
    const pub = W().published();
    if (!posted || !pub || !pub.roadmap) return;
    const board = pubBoard(pub.roadmap);
    if (JSON.stringify(board) === posted.sent) return;
    await postBoard(posted.channelId, board, true);
  });

  // ---------- Boxes ----------
  function cardBox() {
    const e = S.edit, k = e.k, b = B(), products = W().draft().products || [];
    return `<h2>${e.j < 0 ? 'Add an item' : 'Edit item'}</h2>
      <div class="field"><label for="bk-title">Title</label><input id="bk-title" type="text" class="wide" maxlength="120" value="${esc(k.title)}" placeholder="War Diary Gear 1.2.13"></div>
      <div class="field"><label for="bk-text">Description <span class="muted small">(optional)</span></label><textarea id="bk-text" class="wide" rows="4" maxlength="1000" placeholder="Character Sheet, Reputation tab, Gear Finder…">${esc(k.text)}</textarea></div>
      <div class="grid2">
        <div class="field"><label for="bk-col">Column</label><select id="bk-col" class="wide">${b.columns.map((c, i) => `<option value="${i}" ${i === e.c ? 'selected' : ''}>${esc((c.emoji ? c.emoji + ' ' : '') + (c.name || 'Column ' + (i + 1)))}</option>`).join('')}</select></div>
        <div class="field"><label for="bk-addon">Addon label <span class="muted small">(optional)</span></label><select id="bk-addon" class="wide"><option value="">None</option>${products.map(p => `<option value="${esc(p.id)}" ${p.id === k.addon ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select></div>
      </div>
      <div class="actions">${e.j >= 0 ? `<button class="dbtn" data-action="bd-card-del">${ti('trash')} Delete</button><span class="grow"></span>` : ''}
        <button class="sbtn" data-action="bd-close">Cancel</button><button class="pbtn" data-action="bd-card-save">${ti('check')} ${e.j < 0 ? 'Add' : 'Save'}</button></div>`;
  }
  function colBox() {
    const e = S.edit, c = e.col, n = B().columns.length;
    const emojis = EMOJI.includes(c.emoji) ? EMOJI : [...EMOJI, c.emoji];
    return `<h2>${e.i < 0 ? 'Add a column' : 'Edit column'}</h2>
      <div class="grid2">
        <div class="field"><label for="bc-name">Name</label><input id="bc-name" type="text" class="wide" maxlength="40" value="${esc(c.name)}" placeholder="In Testing"></div>
        <div class="field"><label for="bc-emoji">Emoji</label><select id="bc-emoji" class="wide">${emojis.map(x => `<option value="${esc(x)}" ${x === c.emoji ? 'selected' : ''}>${x || 'None'}</option>`).join('')}</select></div>
      </div>
      <div class="field"><span class="field-label">Color</span><div class="bswatches" role="radiogroup" aria-label="Color">${COLORS.map(([v, l]) => `<label class="bswatch" title="${l}"><input type="radio" name="bc-color" value="${v}" ${v === c.color ? 'checked' : ''}><span style="background:${HEX[v]}"></span>${l}</label>`).join('')}</div></div>
      ${e.i >= 0 ? `<div class="row-actions"><button class="sbtn" data-action="bd-col-move" data-dir="-1" ${e.i === 0 ? 'disabled' : ''}>${ti('arrow-left')} Move left</button><button class="sbtn" data-action="bd-col-move" data-dir="1" ${e.i === n - 1 ? 'disabled' : ''}>Move right ${ti('arrow-right')}</button></div>` : ''}
      <div class="actions">${e.i >= 0 ? `<button class="dbtn" data-action="bd-col-del">${ti('trash')} Delete column</button><span class="grow"></span>` : ''}
        <button class="sbtn" data-action="bd-close">Cancel</button><button class="pbtn" data-action="bd-col-save">${ti('check')} ${e.i < 0 ? 'Add' : 'Save'}</button></div>`;
  }
  function importBox() {
    return `<h2>Paste a roadmap</h2>
      <p class="hint">Paste your roadmap the way you'd post it on Discord. <b># Title</b> becomes the board title, each <b>## Section</b> a column, and each <b>- **Name**: description</b> line a card.</p>
      <textarea id="bd-paste" class="wide bd-paste" rows="14" placeholder="# 🛡️ Warchief's War Diary — Development Roadmap&#10;&#10;## 🔧 In Testing&#10;- **War Diary Gear 1.2.13**: Character Sheet, Reputation tab…"></textarea>
      <p class="hint" id="bd-paste-note"></p>
      <div class="actions"><button class="sbtn" data-action="bd-close">Cancel</button><button class="pbtn" data-action="bd-import-go">${ti('check')} Replace the board</button></div>`;
  }

  // Reads a pasted roadmap: # title, ## columns (emoji first), - **Name**: description cards
  const EMO = /^((?:\p{Extended_Pictographic}|\p{Regional_Indicator})(?:️|‍(?:\p{Extended_Pictographic})|\p{Emoji_Modifier})*️?)\s*/u;
  function colorFor(name) {
    const n = name.toLowerCase();
    if (/test|qa|review/.test(n)) return 'yellow';
    if (/progress|doing|working|active/.test(n)) return 'orange';
    if (/plan|todo|to do|backlog|idea|next|later/.test(n)) return 'blue';
    if (/release|done|shipped|live|complete/.test(n)) return 'green';
    if (/bug|fix|broken|issue/.test(n)) return 'red';
    return 'gray';
  }
  function parse(text) {
    const out = { title: '', columns: [] };
    let col = null, last = null;
    for (const raw of String(text || '').replace(/\r/g, '').split('\n')) {
      const line = raw.trim();
      if (!line) { last = null; continue; }
      let m;
      if ((m = /^#\s+(.+)$/.exec(line)) && !out.title && !out.columns.length) { out.title = m[1].trim(); continue; }
      if ((m = /^#{2,3}\s+(.+)$/.exec(line))) {
        let name = m[1].replace(/\*\*/g, '').trim(), emoji = '';
        const e = EMO.exec(name); if (e) { emoji = e[1]; name = name.slice(e[0].length).trim(); }
        col = { id: newId('c'), name: name.slice(0, 40), emoji: emoji.slice(0, 8), color: colorFor(name), cards: [] };
        out.columns.push(col); last = null; continue;
      }
      if ((m = /^[-*+•]\s+(.+)$/.exec(line)) || (m = /^\d+[.)]\s+(.+)$/.exec(line))) {
        if (!col) { col = { id: newId('c'), name: 'To-do', emoji: '📋', color: 'blue', cards: [] }; out.columns.push(col); }
        const body = m[1].trim();
        const b2 = /^\*\*(.+?)\*\*\s*(?:[:\-–—]\s*)?(.*)$/.exec(body);
        const k = b2 ? { title: b2[1].trim(), text: b2[2].trim() } : (() => { const p = /^(.+?):\s+(.+)$/.exec(body); return p && p[1].length <= 60 ? { title: p[1].replace(/\*\*/g, '').trim(), text: p[2].trim() } : { title: body.replace(/\*\*/g, '').trim(), text: '' }; })();
        last = { id: newId('k'), title: k.title.slice(0, 120), text: k.text.replace(/\*\*/g, '').slice(0, 1000), addon: '', at: new Date().toISOString() };
        col.cards.push(last); continue;
      }
      if (last) { last.text = ((last.text ? last.text + ' ' : '') + line.replace(/\*\*/g, '')).slice(0, 1000); continue; }
      if (!out.title && !out.columns.length) out.title = line.replace(/^#+\s*/, '');
    }
    return out;
  }

  // ---------- Changing the board ----------
  function changed(redraw) { W().changed(); if (redraw !== false) W().render(); }
  function openCard(i, j) {
    const c = B().columns[i];
    S.edit = { kind: 'card', c: i, j, k: j >= 0 ? { ...c.cards[j] } : { id: newId('k'), title: '', text: '', addon: '', at: '' } };
    W().showModal(cardBox());
    const t = document.getElementById(j >= 0 ? 'bk-text' : 'bk-title'); if (t) t.focus();
  }
  function saveCard() {
    const v = id => (document.getElementById(id) || {}).value || '';
    const title = v('bk-title').trim();
    if (!title) return W().toast('Give it a title', true);
    const e = S.edit, b = B();
    const to = Number(v('bk-col')) || 0;
    const k = { id: e.k.id, title, text: v('bk-text').trim(), addon: v('bk-addon'), at: e.k.at };
    const before = e.j >= 0 ? b.columns[e.c].cards[e.j] : null;
    if (!before || before.title !== k.title || before.text !== k.text || before.addon !== k.addon || to !== e.c) k.at = new Date().toISOString();
    if (e.j >= 0) b.columns[e.c].cards.splice(e.j, 1);
    if (e.j >= 0 && to === e.c) b.columns[to].cards.splice(e.j, 0, k); else b.columns[to].cards.push(k);
    S.edit = null; W().closeModal(); changed();
    W().toast(before ? 'Saved. Publish to show it in the launcher.' : 'Added. Publish to show it in the launcher.');
  }
  function openCol(i) {
    const c = i >= 0 ? B().columns[i] : null;
    S.edit = { kind: 'col', i, col: c ? { ...c } : { id: newId('c'), name: '', emoji: '', color: 'gray', cards: [] } };
    W().showModal(colBox());
    const t = document.getElementById('bc-name'); if (t) t.focus();
  }
  function saveCol() {
    const name = ((document.getElementById('bc-name') || {}).value || '').trim();
    if (!name) return W().toast('Give the column a name', true);
    const e = S.edit, b = B();
    const col = { ...e.col, name, emoji: (document.getElementById('bc-emoji') || {}).value || '', color: (document.querySelector('input[name="bc-color"]:checked') || {}).value || 'gray' };
    if (e.i >= 0) b.columns[e.i] = { ...b.columns[e.i], name: col.name, emoji: col.emoji, color: col.color }; else b.columns.push(col);
    S.edit = null; W().closeModal(); changed();
  }

  // ---------- Events ----------
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-action]');
    if (!el || !window.WLAdmin) return;
    const a = el.dataset.action;
    if (!a.startsWith('bd-') && !a.startsWith('td-')) return;
    const i = Number(el.dataset.c);
    switch (a) {
      case 'bd-card-add': return openCard(i, -1);
      case 'bd-card-edit': return openCard(i, Number(el.dataset.k));
      case 'bd-card-save': return saveCard();
      case 'bd-card-del': {
        const ed = S.edit;
        return W().confirmBox('Delete this item?', `<p>${esc(ed.k.title)}</p>`, 'Delete', () => { B().columns[ed.c].cards.splice(ed.j, 1); S.edit = null; changed(); }, true);
      }
      case 'bd-col-add': return openCol(-1);
      case 'bd-col-edit': return openCol(i);
      case 'bd-col-save': return saveCol();
      case 'bd-col-move': {
        const ed = S.edit, b = B(), k = ed.i + Number(el.dataset.dir);
        if (k < 0 || k >= b.columns.length) return;
        [b.columns[ed.i], b.columns[k]] = [b.columns[k], b.columns[ed.i]];
        ed.i = k; changed(); return W().showModal(colBox());
      }
      case 'bd-col-del': {
        const ed = S.edit, c = B().columns[ed.i];
        return W().confirmBox(`Delete "${c.name}"?`, c.cards.length ? `<p class="warn-text">Its ${c.cards.length} item${c.cards.length === 1 ? ' is' : 's are'} deleted too.</p>` : '<p>The column is empty.</p>', 'Delete column', () => { B().columns.splice(ed.i, 1); S.edit = null; changed(); }, true);
      }
      case 'bd-close': S.edit = null; return W().closeModal();
      case 'bd-import': S.edit = { kind: 'import' }; W().showModal(importBox()); { const t = document.getElementById('bd-paste'); if (t) t.focus(); } return;
      case 'bd-import-go': {
        const got = parse((document.getElementById('bd-paste') || {}).value || '');
        const n = got.columns.reduce((x, c) => x + c.cards.length, 0);
        if (!got.columns.length) return W().toast('No ## sections found. Each ## line becomes a column.', true);
        const d = W().draft();
        d.roadmap = { title: got.title || B().title, columns: got.columns };
        S.edit = null; W().closeModal(); changed();
        return W().toast(`Board filled in: ${got.columns.length} columns, ${n} items. Publish to show it in the launcher.`);
      }
      case 'td-post': {
        const ch = (document.getElementById('td-ch') || {}).value || '';
        if (!ch) return W().toast('Choose a channel first', true);
        S.channel = ch;
        return postBoard(ch, pubBoard(B()));
      }
    }
  });
  document.addEventListener('keydown', e => {
    const c = e.target.closest && e.target.closest('.bcard');
    if (c && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); openCard(Number(c.dataset.c), Number(c.dataset.k)); }
    if (e.key === 'Enter' && e.target.id === 'bk-title') saveCard();
    if (e.key === 'Enter' && e.target.id === 'bc-name') saveCol();
  });
  document.addEventListener('input', e => {
    if (!window.WLAdmin || W().page() !== 'todo') return;
    if (e.target.id === 'bd-title') { B().title = e.target.value; changed(false); }
    if (e.target.id === 'bd-paste') {
      const got = parse(e.target.value), n = got.columns.reduce((x, c) => x + c.cards.length, 0), note = document.getElementById('bd-paste-note');
      if (note) note.textContent = got.columns.length ? `Found: ${got.title ? `"${got.title}", ` : ''}${got.columns.map(c => `${c.emoji ? c.emoji + ' ' : ''}${c.name} (${c.cards.length})`).join(', ')}. ${n} items in all.` : '';
    }
  });
  document.addEventListener('change', e => {
    if (!window.WLAdmin || W().page() !== 'todo') return;
    if (e.target.id === 'td-ch') { S.channel = e.target.value; K().refresh(); }
  });

  // Drag a card to another place or column
  const clearMarks = () => document.querySelectorAll('.bdrop-before, .bdrop-end').forEach(x => x.classList.remove('bdrop-before', 'bdrop-end'));
  function dropSpot(list, y) {
    const cards = [...list.querySelectorAll('.bcard')].filter(x => !x.classList.contains('dragging'));
    const at = cards.findIndex(x => { const r = x.getBoundingClientRect(); return y < r.top + r.height / 2; });
    return { index: at < 0 ? cards.length : at, cards };
  }
  document.addEventListener('dragstart', e => {
    const c = e.target.closest && e.target.closest('.bcard');
    if (!c) return;
    S.drag = { c: Number(c.dataset.c), k: Number(c.dataset.k) };
    c.classList.add('dragging');
    try { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'card'); } catch { /* fine */ }
  });
  document.addEventListener('dragover', e => {
    const list = S.drag && e.target.closest && (e.target.closest('.bcards') || (e.target.closest('.bcol') || { querySelector: () => null }).querySelector('.bcards'));
    if (!list) return;
    e.preventDefault();
    clearMarks();
    const { index, cards } = dropSpot(list, e.clientY);
    if (cards[index]) cards[index].classList.add('bdrop-before'); else list.classList.add('bdrop-end');
  });
  document.addEventListener('drop', e => {
    const list = S.drag && e.target.closest && (e.target.closest('.bcards') || (e.target.closest('.bcol') || { querySelector: () => null }).querySelector('.bcards'));
    if (!list) return;
    e.preventDefault();
    const to = Number(list.dataset.drop), { index } = dropSpot(list, e.clientY), from = S.drag, b = B();
    const [moved] = b.columns[from.c].cards.splice(from.k, 1);
    if (from.c !== to) moved.at = new Date().toISOString();
    // the dragged card wasn't counted in the drop spot, so the index is already right
    b.columns[to].cards.splice(Math.min(index, b.columns[to].cards.length), 0, moved);
    S.drag = null; clearMarks(); changed();
  });
  document.addEventListener('dragend', () => { S.drag = null; clearMarks(); document.querySelectorAll('.bcard.dragging').forEach(x => x.classList.remove('dragging')); });

  window.WLTodo = { page, parse, pubBoard };
})();

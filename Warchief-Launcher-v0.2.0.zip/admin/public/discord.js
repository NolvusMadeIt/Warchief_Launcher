// Discord posts page for the Admin: write news, updates or simple messages, post them to your Discord
// server, then edit or delete them later. Lives on its own; admin.js only gives it a menu entry and a page slot.
(function () {
  'use strict';

  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ti = n => `<i class="ti ti-${n}" aria-hidden="true"></i>`;
  const $id = id => document.getElementById(id);
  const fmt = t => t ? new Date(t).toLocaleString([], { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }) : '';
  const mb = n => (n / 1024 / 1024).toFixed(1) + ' MB';

  const MAX_IMAGE = Math.floor(3.5 * 1024 * 1024);
  const COLORS = [['#f2c75c', 'War Diary gold'], ['#8f74ff', 'Purple'], ['#e0402e', 'Red'], ['#ff7a1f', 'Orange'], ['#57f287', 'Green'],
    ['#3cc2a6', 'Teal'], ['#5865f2', 'Discord blue'], ['#99aab5', 'Grey']];
  const VIEWS = [['split', 'Side by side', 'layout-columns'], ['write', 'Write', 'pencil'], ['preview', 'Preview', 'eye']];
  const TOOLS = [
    ['bold', 'bold', 'Bold (Ctrl+B)'], ['italic', 'italic', 'Italic (Ctrl+I)'], ['underline', 'underline', 'Underline (Ctrl+U)'],
    ['strike', 'strikethrough', 'Crossed out'], ['spoiler', 'eye-off', 'Spoiler: hidden until someone clicks it'], '|',
    ['h1', 'h-1', 'Big heading'], ['h2', 'h-2', 'Heading'], ['h3', 'h-3', 'Small heading'], ['sub', 'text-decrease', 'Small grey text'], '|',
    ['ul', 'list', 'Bulleted list'], ['ol', 'list-numbers', 'Numbered list'], ['quote', 'quote', 'Quote'], '|',
    ['link', 'link', 'Link (Ctrl+K)'], ['code', 'code', 'Code'], ['codeblock', 'source-code', 'Code block']
  ];
  // Same list and order as admin/discord.js, so "changed since posted" matches.
  const SNAP_KEYS = ['title', 'body', 'style', 'color', 'image', 'icon', 'ping'];
  const snapOf = p => JSON.stringify(SNAP_KEYS.map(k => (p[k] === undefined ? null : p[k])));

  // ---------- Long posts become several messages ----------
  // Same rules, word for word, as admin/discord.js, so the boxes on the page match what gets sent.
  // Cuts after a line, else after a sentence, else after a space; only mid-word if there's no space at all.
  // Joined back together, the pieces are exactly the original text.
  function splitText(text, firstMax, max) {
    const parts = [];
    if (firstMax < 1 || max < 1) return [text];
    for (let pos = 0; ;) {
      const lim = parts.length ? max : firstMax;
      const rest = text.slice(pos);
      const lead = parts.length ? rest.length - rest.trimStart().length : 0;
      if (rest.trimEnd().length - lead <= lim) { parts.push(rest); return parts; }
      const win = rest.slice(0, lead + lim), min = lead + Math.floor(lim / 2);
      let cut = win.lastIndexOf('\n') + 1;
      if (cut <= min) {
        cut = 0;
        const re = /[.!?]['")\]]*\s+/g;
        for (let m; (m = re.exec(win));) if (m.index + m[0].length > min) cut = m.index + m[0].length;
      }
      if (cut <= min) cut = Math.max(win.lastIndexOf(' '), win.lastIndexOf('\t')) + 1;
      if (cut <= min) { cut = win.length; const c = win.charCodeAt(cut - 1); if (c >= 0xd800 && c <= 0xdbff) cut--; }
      parts.push(rest.slice(0, cut));
      pos += cut;
    }
  }
  // A simple message holds 2000 characters (the first one also holds @everyone and the title, the last one the
  // picture link). A card holds 4096 characters of text.
  // A whole line like ![picture](https://…) is a picture in the text. Discord can't show a picture in the middle
  // of a message, so the text is also cut after every picture line: the picture shows under its own message.
  const PIC_LINE = /^[ \t]*!\[([^\]\n]*)\]\((https?:\/\/[^\s)]+)\)[ \t]*$/;
  function picChunks(body) {
    const out = [], re = /^[ \t]*!\[[^\]\n]*\]\(https?:\/\/[^\s)]+\)[ \t]*(?:\n|$)/gm;
    let pos = 0;
    for (let m; (m = re.exec(body));) { pos = m.index + m[0].length; out.push(pos); if (!m[0].length) re.lastIndex++; }
    const chunks = [];
    let from = 0;
    for (const end of out) { chunks.push(body.slice(from, end)); from = end; }
    const rest = body.slice(from);
    if (chunks.length && !rest.trim()) chunks[chunks.length - 1] += rest; else chunks.push(rest);
    return chunks;
  }
  function partsOf(p) {
    const body = String(p.body || '');
    let first = 4096, max = 4096;
    if (p.style === 'simple') {
      const title = String(p.title || '').trim();
      const head = (p.ping ? 10 : 0) + (title ? title.length + 4 : 0);
      const tail = p.image && p.image.kind === 'url' ? p.image.url.length + 1 : 0;
      first = 2000 - head - tail; max = 2000 - tail;
    }
    const parts = [];
    picChunks(body).forEach((c, k) => parts.push(...splitText(c, k ? max : first, max)));
    return parts;
  }
  const partText = (t, i) => (i ? t.trim() : t.replace(/\s+$/, ''));
  // Message i's text, and the picture line at its end (if there is one), taken out of the text.
  function partBody(parts, i) {
    const lines = String(parts[i] || '').replace(/\s+$/, '').split('\n');
    const m = lines[lines.length - 1].match(PIC_LINE);
    return m ? { text: partText(lines.slice(0, -1).join('\n'), i), pic: m[2] } : { text: partText(parts[i] || '', i), pic: '' };
  }
  const LIMIT = p => (p.style === 'simple' ? 2000 : 4096);
  // How long message i is in Discord's count.
  const partLen = (p, i, parts) => (p.style === 'simple' ? simpleContent(p, i, parts).length : partBody(parts, i).text.length);

  // The server code this page needs (admin/discord.js, "version" in its state). Raise both together.
  const SERVER_VERSION = 3;
  const S = { st: null, loading: false, err: '', view: 'list', filter: 'all', post: null, saveState: 'saved', busy: '', customColor: false, mdView: 'split', problem: '', ver: 0 };
  try { S.mdView = localStorage.getItem('wl.admin.dcView') || 'split'; } catch { /* storage off */ }

  // ---------- Server calls, toast, modal ----------
  async function api(method, url, body) {
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json', 'X-Admin': '1' }, body: body ? JSON.stringify(body) : undefined });
    let data = {};
    try { data = await res.json(); } catch { /* empty */ }
    if (!res.ok) throw new Error(data.error || 'Something went wrong');
    return data;
  }
  let toastTimer = null;
  function toast(msg, bad) {
    const el = $id('toast'); if (!el) return;
    el.textContent = msg; el.classList.toggle('bad', !!bad); el.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.hidden = true; }, bad ? 7000 : 3800);
  }
  let modalFn = null;
  function showModal(html) {
    const m = $id('modal'); m.innerHTML = html; $id('overlay').hidden = false;
    const f = m.querySelector('input[type=text], input[type=url], .pbtn, .dbtn'); if (f) f.focus();
  }
  function closeModal() { $id('overlay').hidden = true; $id('modal').innerHTML = ''; modalFn = null; }
  function confirmBox(title, bodyHtml, okLabel, fn, danger) {
    modalFn = fn;
    showModal(`<h2>${esc(title)}</h2>${bodyHtml}<div class="actions"><button class="sbtn" data-dc="modal-cancel">Cancel</button><button class="${danger ? 'dbtn' : 'pbtn'}" data-dc="modal-ok">${esc(okLabel)}</button></div>`);
  }

  // ---------- Page entry (called by admin.js) ----------
  function page() {
    if (!S.st && !S.loading) load();
    return `<div id="dc-root">${inner()}</div>`;
  }
  async function load() {
    S.loading = true;
    try { S.st = await api('GET', '/api/discord/state'); S.err = ''; S.ver = S.st.version || 1; }
    catch (e) { S.err = e.message; }
    S.loading = false;
    draw();
  }
  function draw() {
    const root = $id('dc-root'); if (!root) return;
    const fid = document.activeElement && root.contains(document.activeElement) ? document.activeElement.id : '';
    root.innerHTML = inner();
    if (fid) { const el = $id(fid); if (el) el.focus(); }
  }
  function inner() {
    if (!S.st) return S.err
      ? `<h1>Discord posts</h1><p class="bad-text">${esc(S.err)}</p><button class="sbtn" data-dc="reload">Try again</button>`
      : '<h1>Discord posts</h1><p class="muted">Loading…</p>';
    return staleHtml() + (S.view === 'edit' && S.post ? editor() : list());
  }

  // ---------- Problems that must not be missed ----------
  const stale = () => !!(S.ver && S.ver !== SERVER_VERSION);
  const STALE_TEXT = "The Discord posts page was updated while the Admin was running, and the Admin only loads the new version when it starts. Until then, posting won't work right.";
  const STALE_FIX = 'Press <b>Close Admin</b> at the top right, then open it again with <b>Open Admin.bat</b>. Your posts are saved.';
  function staleHtml() {
    return stale() ? `<div class="dc-alert bad dc-stale" role="alert">${ti('alert-triangle')}<div><b>The Admin needs a restart.</b> ${esc(STALE_TEXT)} ${STALE_FIX}</div></div>` : '';
  }
  // Right above the Post button: what went wrong last time (stays until closed), or what's stopping the post now.
  function warnHtml(p) {
    if (S.problem) return `<div class="dc-alert bad" role="alert">${ti('alert-triangle')}<div><b>That didn't work.</b> ${esc(S.problem)}</div><button class="tbtn" data-dc="problem-close" aria-label="Close" title="Close">${ti('x')}</button></div>`;
    const over = overLimit(p);
    return over ? `<div class="dc-alert warn">${ti('alert-triangle')}<div>${esc(over)}</div></div>` : '';
  }
  // A box with an OK button, for things that need reading.
  function notice(title, html) {
    showModal(`<h2>${esc(title)}</h2>${html}<div class="actions"><button class="pbtn" data-dc="modal-cancel">OK</button></div>`);
  }

  // ---------- Helpers ----------
  const hooks = () => S.st.webhooks;
  const hookOf = id => hooks().find(h => h.id === id) || null;
  const isDirty = p => !!(p.sent && p.sent.snap !== snapOf(p));
  function statusOf(p) {
    if (!p.sent) return ['Draft', 'off'];
    if (isDirty(p)) return ['Changed, not updated in Discord yet', 'warn'];
    return ['Posted', 'ok'];
  }
  const picSrc = v => v.kind === 'upload' ? `/api/discord/media?id=${encodeURIComponent(v.media)}` : v.url;
  function plain(s) {
    return String(s || '').replace(/!\[[^\]\n]*\]\([^)\s]*\)/g, ' ').replace(/```[\s\S]*?```/g, ' ').replace(/^(#{1,3}|-#|>{1,3}|\s*[-*]|\s*\d+\.)\s+/gm, '')
      .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1').replace(/(\*\*|__|~~|\|\||`|\*)/g, '').replace(/\s+/g, ' ').trim();
  }
  const excerpt = (s, n) => { const t = plain(s); return t.length > n ? t.slice(0, n).replace(/\s+\S*$/, '') + '…' : t; };
  // Message i of a simple post: @everyone and the title go on the first one, the picture link on the last.
  function simpleContent(p, i = 0, parts = partsOf(p)) {
    const title = p.title.trim();
    const url = p.image && p.image.kind === 'url' && i === parts.length - 1 ? p.image.url : '';
    return [i === 0 && p.ping ? '@everyone' : '', i === 0 && title ? `## ${title}` : '', partBody(parts, i).text, url].filter(Boolean).join('\n');
  }
  function overLimit(p) {
    const parts = partsOf(p);
    if (p.style !== 'simple') {
      const t = p.title.trim().length;
      if (t > 256) return `A card title can be up to 256 characters. This one is ${t}.`;
    }
    for (let i = 0; i < parts.length; i++) {
      const n = partLen(p, i, parts), which = parts.length > 1 ? `Message ${i + 1}` : 'This one';
      if (n > LIMIT(p)) return p.style === 'simple' ? `A simple message can be up to 2000 characters. ${which} is ${n}.` : `Card text can be up to 4096 characters. ${which} is ${n}.`;
      if (i > 0 && !partText(parts[i], i)) return `Message ${i + 1} is empty. Remove the extra blank lines before it.`;
    }
    return '';
  }
  function rand12() {
    const a = new Uint8Array(6); crypto.getRandomValues(a);
    return [...a].map(x => x.toString(16).padStart(2, '0')).join('');
  }

  // ---------- Discord look for the preview ----------
  function inline(s) {
    const codes = [];
    let t = String(s).replace(/`([^`\n]+)`/g, (m, c) => { codes.push(`<code class="dc-code">${esc(c)}</code>`); return `\u0001${codes.length - 1}\u0001`; });
    t = esc(t)
      .replace(/\[([^\]\n]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a class="dc-a" href="$2" target="_blank" rel="noopener">$1</a>')
      .replace(/(^|[\s(])(https?:\/\/[^\s<]+)/g, '$1<a class="dc-a" href="$2" target="_blank" rel="noopener">$2</a>')
      .replace(/\*\*\*([^*\n]+?)\*\*\*/g, '<strong><em>$1</em></strong>')
      .replace(/\*\*([^\n]+?)\*\*/g, '<strong>$1</strong>')
      .replace(/__([^\n]+?)__/g, '<u>$1</u>')
      .replace(/(^|[^*\w])\*([^*\s][^*\n]*?)\*(?!\*)/g, '$1<em>$2</em>')
      .replace(/(^|[^_\w])_([^_\s][^_\n]*?)_(?!_)/g, '$1<em>$2</em>')
      .replace(/~~([^\n]+?)~~/g, '<s>$1</s>')
      .replace(/\|\|([^\n]+?)\|\|/g, '<span class="dc-spoiler" title="Spoiler: hidden until someone clicks it">$1</span>')
      .replace(/@(everyone|here)\b/g, '<span class="dc-mention">@$1</span>');
    return t.replace(/\u0001(\d+)\u0001/g, (m, n) => codes[n]);
  }
  function render(src) {
    const text = String(src || '').replace(/\r\n/g, '\n');
    if (!text.trim()) return '';
    const blocks = [];
    const t = text.replace(/```(?:([\w+-]{1,20})\n)?([\s\S]*?)```/g, (m, lang, code) => {
      blocks.push(`<pre class="dc-pre"><code>${esc(code.replace(/^\n+|\n+$/g, ''))}</code></pre>`);
      return `\u0000${blocks.length - 1}\u0000`;
    });
    const lines = t.split('\n'), out = [];
    let list = null;
    const closeList = () => { if (list) { out.push(`</${list}>`); list = null; } };
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      let m;
      if ((m = line.match(/^>>> ?([\s\S]*)$/))) {
        closeList();
        out.push(`<blockquote class="dc-quote">${render([m[1], ...lines.slice(i + 1)].join('\n'))}</blockquote>`);
        break;
      }
      if (/^> /.test(line) || line === '>') {
        closeList();
        const q = [];
        while (i < lines.length && (/^> /.test(lines[i]) || lines[i] === '>')) { q.push(lines[i].replace(/^> ?/, '')); i++; }
        i--;
        out.push(`<blockquote class="dc-quote">${q.map(x => x.trim() ? `<div>${inline(x)}</div>` : '<div><br></div>').join('')}</blockquote>`);
        continue;
      }
      if ((m = line.match(/^(#{1,3}) (.+)$/))) { closeList(); out.push(`<div class="dc-h${m[1].length}">${inline(m[2])}</div>`); continue; }
      if ((m = line.match(/^-# (.+)$/))) { closeList(); out.push(`<div class="dc-sub">${inline(m[1])}</div>`); continue; }
      if ((m = line.match(/^\s*[-*] (.+)$/))) {
        if (list !== 'ul') { closeList(); out.push('<ul class="dc-list">'); list = 'ul'; }
        out.push(`<li>${inline(m[1])}</li>`); continue;
      }
      if ((m = line.match(/^\s*(\d{1,9})\. (.+)$/))) {
        if (list !== 'ol') { closeList(); out.push(`<ol class="dc-list" start="${Number(m[1])}">`); list = 'ol'; }
        out.push(`<li>${inline(m[2])}</li>`); continue;
      }
      closeList();
      out.push(line.trim() ? `<div>${inline(line)}</div>` : '<div><br></div>');
    }
    closeList();
    return out.join('').replace(/\u0000(\d+)\u0000/g, (m, n) => blocks[n]);
  }
  function previewHtml(p) {
    const h = hookOf(p.webhookId) || hooks()[0] || null;
    const name = h ? (h.name || h.label) : 'Your webhook';
    const avatar = h && h.avatar ? `<img src="${esc(h.avatar)}" alt="">` : `<span>${esc(name.charAt(0).toUpperCase() || 'W')}</span>`;
    const when = p.sent ? new Date(p.sent.at) : new Date();
    const time = (when.toDateString() === new Date().toDateString() ? 'Today at ' : when.toLocaleDateString() + ' ')
      + when.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    const ping = p.ping ? '<span class="dc-mention">@everyone</span>' : '';
    const parts = partsOf(p);
    const msgs = parts.map((part, i) => {
      const first = i === 0, last = i === parts.length - 1;
      const pb = partBody(parts, i);
      let content = '', extra = '';
      if (p.style === 'simple') {
        const src = [first && p.title.trim() ? '## ' + p.title.trim() : '', pb.text].filter(Boolean).join('\n');
        content = [first ? ping : '', render(src)].filter(Boolean).join('');
        if (pb.pic) extra += `<div class="dc-embed dc-picbox"><img class="dc-pic" src="${esc(pb.pic)}" alt=""></div>`;
        if (last && p.image) extra += `<img class="dc-attach" src="${esc(picSrc(p.image))}" alt="">`;
      } else {
        content = first ? ping : '';
        const title = first && p.title.trim() ? `<div class="dc-etitle">${esc(p.title.trim())}</div>` : '';
        const desc = pb.text.trim() ? `<div class="dc-edesc">${render(pb.text)}</div>` : '';
        const thumb = first && p.icon ? `<img class="dc-ethumb" src="${esc(picSrc(p.icon))}" alt="">` : '';
        const pics = [pb.pic, last && p.image ? picSrc(p.image) : ''].filter(Boolean);
        const img = pics[0] ? `<img class="dc-eimage" src="${esc(pics[0])}" alt="">` : '';
        if (title || desc || img || thumb) {
          extra = `<div class="dc-embed" style="border-left-color:${esc(p.color)}"><div class="dc-egrid"><div class="dc-etext">${title}${desc}</div>${thumb}</div>${img}</div>`;
        }
        if (pics[1]) extra += `<div class="dc-embed" style="border-left-color:${esc(p.color)}"><img class="dc-eimage" src="${esc(pics[1])}" alt=""></div>`;
      }
      if (first && parts.length === 1 && !content && !extra) content = '<span class="dc-empty">Your post shows up here as you type.</span>';
      const body = `${content ? `<div class="dc-content">${content}</div>` : ''}${extra}`;
      // Discord shows the name and picture once, then the next messages right under it.
      return first
        ? `<div class="dc-msg"><div class="dc-avatar">${avatar}</div><div class="dc-mbody">
            <div class="dc-head"><span class="dc-name">${esc(name)}</span><span class="dc-time">${esc(time)}</span></div>${body}</div></div>`
        : `<div class="dc-msg dc-more" title="Message ${i + 1}"><div class="dc-avatar dc-gap"></div><div class="dc-mbody">${body}</div></div>`;
    });
    return `${msgs.join('')}
      <p class="dc-note">This is close to how Discord shows it. Discord's own look can differ a little.</p>`;
  }

  // ---------- Post list (like WordPress's Posts screen) ----------
  function list() {
    const all = S.st.posts;
    const counts = { all: all.length, drafts: all.filter(p => !p.sent).length, posted: all.filter(p => p.sent).length };
    const posts = all.filter(p => S.filter === 'all' || (S.filter === 'drafts' ? !p.sent : !!p.sent));
    const setup = hooks().length ? '' : `<div class="card"><h2>First, connect a Discord channel</h2>
        <p class="hint">The Admin posts through a webhook, a special link Discord makes for one channel. It takes a minute to set up.</p>
        <div class="row-actions"><button class="pbtn" data-dc="add-channel">${ti('plus')} Add a channel</button></div></div>`;
    const rows = posts.map(p => {
      const [label, cls] = statusOf(p);
      const h = hookOf(p.webhookId);
      const when = p.sent ? (p.sent.editedAt ? `Edited ${fmt(p.sent.editedAt)}` : `Posted ${fmt(p.sent.at)}`) : `Saved ${fmt(p.updatedAt)}`;
      return `<tr>
        <td><div class="pname">${p.title.trim() ? esc(p.title) : '<span class="muted">(no title)</span>'}</div><div class="psub dc-excerpt">${esc(excerpt(p.body, 140))}</div></td>
        <td>${h ? esc(h.label) : p.webhookId ? '<span class="warn-text small">Channel removed</span>' : '<span class="muted">Not picked</span>'}</td>
        <td class="psub">${p.style === 'simple' ? 'Simple message' : 'Announcement card'}</td>
        <td><span class="tag ${cls}">${esc(label)}</span></td>
        <td class="psub">${esc(when)}</td>
        <td class="acts">
          <button class="tbtn" data-dc="edit" data-id="${esc(p.id)}">${ti('pencil')} Edit</button>
          ${p.link ? `<a class="tbtn" href="${esc(p.link)}" target="_blank" rel="noopener" title="Open it in Discord">${ti('external-link')} View</a>` : ''}
          <button class="tbtn danger" data-dc="delete" data-id="${esc(p.id)}" aria-label="Delete" title="Delete">${ti('trash')}</button>
        </td></tr>`;
    }).join('');
    const filters = [['all', 'All'], ['drafts', 'Drafts'], ['posted', 'Posted']];
    const postsCard = `<div class="card"><div class="card-head"><h2>${all.length} post${all.length === 1 ? '' : 's'}</h2><button class="pbtn" data-dc="new">${ti('plus')} New post</button></div>
      ${all.length ? `<div class="seg dc-filter" role="group" aria-label="Show">${filters.map(([k, l]) => `<button class="${S.filter === k ? 'on' : ''}" data-dc="filter" data-f="${k}" aria-pressed="${S.filter === k}">${l} (${counts[k]})</button>`).join('')}</div>` : ''}
      ${posts.length ? `<table class="table"><thead><tr><th>Post</th><th>Channel</th><th>Style</th><th>Status</th><th>Date</th><th></th></tr></thead><tbody>${rows}</tbody></table>`
        : `<div class="empty">${all.length ? 'Nothing here.' : 'No posts yet. Press New post to write your first one.'}</div>`}</div>`;
    const chRows = hooks().map(h => `<tr>
        <td><div class="pname">${esc(h.label)}</div></td>
        <td><span class="dc-chan">${h.avatar ? `<img src="${esc(h.avatar)}" alt="">` : `<span class="dc-avsm">${esc((h.name || h.label).charAt(0).toUpperCase())}</span>`}${esc(h.name || '—')}</span></td>
        <td class="psub">${esc(fmt(h.addedAt))}</td>
        <td class="acts"><button class="tbtn" data-dc="rename-channel" data-id="${esc(h.id)}">${ti('pencil')} Rename</button>
          <button class="tbtn danger" data-dc="remove-channel" data-id="${esc(h.id)}" aria-label="Remove" title="Remove">${ti('trash')}</button></td></tr>`).join('');
    const channels = `<div class="card"><div class="card-head"><div><h2>Channels</h2><p class="hint">Each channel is a webhook from your Discord server. Posts show up with the webhook's name and picture.</p></div>
        <button class="sbtn" data-dc="add-channel">${ti('plus')} Add a channel</button></div>
      ${hooks().length ? `<table class="table"><thead><tr><th>Name here</th><th>Posts as</th><th>Added</th><th></th></tr></thead><tbody>${chRows}</tbody></table>` : '<div class="empty">No channels yet.</div>'}</div>`;
    return `<h1>Discord posts</h1><p class="lead">Write news, updates or a simple message and post it to your Discord server. You can edit or delete it later, and Discord changes too.</p>${setup}${postsCard}${channels}`;
  }

  // ---------- Editor (like WordPress's Edit Post screen) ----------
  function saveText() {
    return { saved: S.post && S.post._isNew ? 'Not saved yet' : 'Saved on this PC', dirty: 'Saving…', saving: 'Saving…', error: "Couldn't save. Your text is still here." }[S.saveState] || '';
  }
  function countText(p) {
    const parts = partsOf(p), many = parts.length > 1;
    const total = parts.reduce((n, _, i) => n + partLen(p, i, parts), 0);
    if (p.style === 'simple') {
      return many ? `${total} characters, sent as ${parts.length} messages (up to 2000 each)`
        : `<span class="${total > 2000 ? 'dc-over' : ''}">${total} / 2000 characters</span>`;
    }
    const t = p.title.trim().length;
    return `<span class="${t > 256 ? 'dc-over' : ''}">Title ${t} / 256</span> · ${many ? `Text ${total} characters, sent as ${parts.length} cards (up to 4096 each)`
      : `<span class="${total > 4096 ? 'dc-over' : ''}">Text ${total} / 4096 characters</span>`}`;
  }
  // The owner's own reminder, with the number of messages kept up to date.
  function remindText(p) {
    const n = partsOf(p).length;
    return `Messages hold up to 2,000 characters (4,000 with Nitro), so this post takes ${n} message${n === 1 ? '' : 's'}.`;
  }
  // The text box, or one box per message once the text is too long for one.
  function partsHtml(p, parts = partsOf(p)) {
    const ph = 'Write your post here. Select some text and use the buttons above to make it bold, add headings, lists, links and more.';
    if (parts.length === 1) return `<textarea id="dc-body" data-dcf="body" data-part="0" spellcheck="true" aria-label="Post text" placeholder="${ph}">\n${esc(parts[0])}</textarea>`;
    return parts.map((t, i) => {
      const n = partLen(p, i, parts);
      return `<div class="dc-part"><div class="dc-part-head"><span>Message ${i + 1} of ${parts.length}</span><span id="dc-pc-${i}" class="${n > LIMIT(p) ? 'dc-over' : ''}">${n} / ${LIMIT(p)}</span></div>
        <textarea id="${i ? 'dc-body-' + i : 'dc-body'}" data-dcf="body" data-part="${i}" spellcheck="true" aria-label="Post text, message ${i + 1} of ${parts.length}">\n${esc(t)}</textarea></div>`;
    }).join('');
  }
  function picBox(slot) {
    const p = S.post, v = p[slot];
    const title = slot === 'icon' ? 'Icon' : 'Picture';
    const hint = slot === 'icon' ? 'Shows small in the top right corner of the card.'
      : p.style === 'simple' ? 'Shows under the message.' : 'Shows big at the bottom of the card.';
    const busy = S.busy === slot;
    const shown = v ? `<img class="dc-thumb" src="${esc(picSrc(v))}" alt=""><p class="dc-picname">${esc(v.kind === 'upload' ? v.name || 'Picture from your PC' : v.url)}</p>` : '';
    return `<div class="card dc-box"><h2>${title}</h2><p class="hint">${hint}</p>${shown}
      <div class="dc-btns">${busy ? `<span class="muted"><span class="spin">${ti('loader-2')}</span> Uploading…</span>` : `
        <button class="sbtn" data-dc="pick-file" data-slot="${slot}">${ti('upload')} ${v ? 'Change' : 'From my PC'}</button>
        <button class="sbtn" data-dc="pick-url" data-slot="${slot}">${ti('world-www')} Web address</button>
        ${v ? `<button class="tbtn danger" data-dc="pic-remove" data-slot="${slot}">${ti('x')} Remove</button>` : ''}`}</div>
      <input type="file" id="dc-file-${slot}" data-dc-file="${slot}" accept="image/png,image/jpeg,image/gif,image/webp" hidden>
      ${v ? '' : '<p class="hint">PNG, JPG, GIF or WEBP, up to 3.5 MB.</p>'}</div>`;
  }
  function editor() {
    const p = S.post, locked = !!p.sent, h = hookOf(p.webhookId), view = S.mdView;
    const [stLabel, stCls] = statusOf(p);
    const hookOpts = `<option value="">${hooks().length ? 'Pick a channel' : 'Add a channel first'}</option>`
      + hooks().map(x => `<option value="${esc(x.id)}" ${x.id === p.webhookId ? 'selected' : ''}>${esc(x.label)}</option>`).join('')
      + (p.webhookId && !h ? `<option value="${esc(p.webhookId)}" selected>Removed channel</option>` : '');
    const preset = COLORS.some(c => c[0] === p.color) && !S.customColor;
    const publish = `<div class="card dc-box"><h2>Publish</h2>
        <div class="dc-statusrow"><span class="muted">Status</span><span id="dc-status" class="tag ${stCls}">${esc(stLabel)}</span></div>
        ${p.sent ? `<p class="psub" style="margin:0 0 10px">Posted ${esc(fmt(p.sent.at))}${p.sent.editedAt ? ` · edited ${esc(fmt(p.sent.editedAt))}` : ''}${p.link ? ` · <a href="${esc(p.link)}" target="_blank" rel="noopener">View in Discord ${ti('external-link')}</a>` : ''}</p>` : ''}
        <div class="field"><label for="dc-hook">Channel</label><select id="dc-hook" class="wide" data-dcf="webhookId" ${locked ? 'disabled' : ''}>${hookOpts}</select>
          ${locked ? '<p class="hint">A posted message stays in its channel. To move it, delete it and post it again.</p>' : ''}
          ${hooks().length ? '' : `<div class="row-actions" style="margin-top:8px"><button class="sbtn" data-dc="add-channel">${ti('plus')} Add a channel</button></div>`}</div>
        <label class="check"><input type="checkbox" id="dc-ping" data-dcf="ping" ${p.ping ? 'checked' : ''}> Notify everyone (@everyone)</label>
        <p class="hint" style="margin-top:6px">${p.sent ? "Updating a post doesn't notify anyone again." : 'Leave it off to post quietly.'}</p>
        <div id="dc-warn">${warnHtml(p)}</div>
        <div class="dc-actions">
          <button class="pbtn" data-dc="send" ${S.busy === 'send' ? 'aria-busy="true"' : ''}>${S.busy === 'send' ? `<span class="spin">${ti('loader-2')}</span> Sending…` : `${ti('brand-discord')} ${p.sent ? 'Update on Discord' : 'Post to Discord'}`}</button>
          <button class="sbtn" data-dc="save">${ti('device-floppy')} ${p.sent ? 'Save without updating' : 'Save draft'}</button>
        </div>
        <button class="tbtn danger" data-dc="delete" data-id="${esc(p.id)}">${ti('trash')} Delete</button></div>`;
    const look = `<div class="card dc-box"><h2>Look</h2>
        <div class="field"><label for="dc-style">Style</label><select id="dc-style" class="wide" data-dcf="style">
          <option value="card" ${p.style !== 'simple' ? 'selected' : ''}>Announcement card</option>
          <option value="simple" ${p.style === 'simple' ? 'selected' : ''}>Simple message</option></select>
          <p class="hint">${p.style === 'simple' ? 'A normal chat message, like you typed it in Discord.' : 'A boxed post with a colored edge, a title, a picture and an icon.'}</p></div>
        ${p.style === 'simple' ? '' : `<div class="field"><label for="dc-color">Edge color</label><div class="dc-colorrow"><span class="dc-swatch" id="dc-swatch" style="background:${esc(p.color)}"></span>
          <select id="dc-color" class="wide" data-dcf="colorPick">${COLORS.map(([c, n]) => `<option value="${c}" ${preset && c === p.color ? 'selected' : ''}>${n}</option>`).join('')}<option value="custom" ${preset ? '' : 'selected'}>Pick my own…</option></select></div>
          ${preset ? '' : `<input type="color" id="dc-color-own" data-dcf="color" value="${esc(p.color)}" class="dc-colorpick" aria-label="Your color">`}</div>`}</div>`;
    return `<div class="crumbs"><button class="tbtn" data-dc="back">${ti('arrow-left')} All posts</button></div>
      <div class="page-head"><h1>${p._isNew ? 'New post' : 'Edit post'}</h1><span id="dc-save" class="small ${S.saveState === 'error' ? 'bad-text' : 'muted'}">${esc(saveText())}</span></div>
      <div class="dc-layout">
        <div class="dc-mainc"><div class="card">
          <div class="field"><label for="dc-title">Title</label><input id="dc-title" type="text" class="wide big-input" data-dcf="title" value="${esc(p.title)}" maxlength="256" placeholder="War Diary 1.5.8 is out"></div>
          <div class="field">
            <div class="md-head"><span class="field-label">Post</span>
              <div class="seg" role="group" aria-label="Editor layout">${VIEWS.map(([v, l, ic]) => `<button class="${view === v ? 'on' : ''}" data-dc="view" data-view="${v}" aria-pressed="${view === v}">${ti(ic)} ${l}</button>`).join('')}</div></div>
            <div class="md-toolbar dc-tools" role="toolbar" aria-label="Formatting">${TOOLS.map(t => t === '|' ? '<span class="sep"></span>' : `<button data-dc="md" data-md="${t[0]}" title="${t[2]}" aria-label="${t[2]}">${ti(t[1])}</button>`).join('')}</div>
            <div class="dc-editor view-${view}${partsOf(p).length > 1 ? ' multi' : ''}" id="dc-editor">
              <div class="dc-parts" id="dc-parts">${partsHtml(p)}</div>
              <div class="dc-preview" id="dc-preview" aria-label="How it looks in Discord">${previewHtml(p)}</div>
            </div>
            <p class="hint" id="dc-count">${countText(p)}</p>
            <p class="hint dc-remind" id="dc-remind">${esc(remindText(p))}</p>
          </div></div></div>
        <aside class="dc-side">${publish}${look}${picBox('image')}${p.style === 'simple' ? '' : picBox('icon')}</aside>
      </div>`;
  }
  // Updates the bits that change while typing, without redrawing the text box.
  function refreshBits() {
    const p = S.post; if (!p) return;
    const pv = $id('dc-preview'); if (pv) pv.innerHTML = previewHtml(p);
    const c = $id('dc-count'); if (c) c.innerHTML = countText(p);
    const rm = $id('dc-remind'); if (rm) rm.textContent = remindText(p);
    const parts = partsOf(p);
    parts.forEach((_, i) => {
      const el = $id('dc-pc-' + i); if (!el) return;
      const n = partLen(p, i, parts);
      el.textContent = `${n} / ${LIMIT(p)}`; el.className = n > LIMIT(p) ? 'dc-over' : '';
    });
    const s = $id('dc-status'); if (s) { const [l, cls] = statusOf(p); s.textContent = l; s.className = 'tag ' + cls; }
    const sw = $id('dc-swatch'); if (sw) sw.style.background = p.color;
    const w = $id('dc-warn'); if (w) w.innerHTML = warnHtml(p);
  }
  function setSaveNote() {
    const el = $id('dc-save'); if (!el) return;
    el.textContent = saveText(); el.className = 'small ' + (S.saveState === 'error' ? 'bad-text' : 'muted');
  }

  // ---------- Saving (automatic, like the rest of the Admin) ----------
  let saveTimer = null, saving = Promise.resolve();
  const postData = p => ({ id: p.id, title: p.title, body: p.body, style: p.style, color: p.color, image: p.image, icon: p.icon, ping: p.ping, webhookId: p.webhookId });
  function mergePost(sp) {
    const i = S.st.posts.findIndex(x => x.id === sp.id);
    if (i >= 0) S.st.posts[i] = sp; else S.st.posts.unshift(sp);
  }
  function saveSoon() {
    S.saveState = 'dirty'; setSaveNote();
    clearTimeout(saveTimer); saveTimer = setTimeout(saveNow, 400);
  }
  function saveNow() {
    clearTimeout(saveTimer); saveTimer = null;
    const p = S.post; if (!p) return saving;
    const snap = postData(p);
    S.saveState = 'saving'; setSaveNote();
    saving = saving.then(async () => {
      try {
        const r = await api('PUT', '/api/discord/post', { post: snap });
        mergePost(r.post);
        if (S.post && S.post.id === r.post.id) { S.post.sent = r.post.sent; S.post.link = r.post.link; S.post._isNew = false; }
        if (!saveTimer) S.saveState = 'saved';
      } catch (e) { S.saveState = 'error'; toast(e.message, true); }
      setSaveNote(); refreshBits();
    });
    return saving;
  }

  // ---------- Formatting buttons (Discord's own formatting) ----------
  function mdInsert(ta, text, from, to, selA, selB) {
    ta.focus(); ta.setSelectionRange(from, to);
    let ok = false;
    try { ok = document.execCommand('insertText', false, text); } catch { ok = false; }
    if (!ok) { ta.setRangeText(text, from, to, 'end'); ta.dispatchEvent(new Event('input', { bubbles: true })); }
    ta.setSelectionRange(from + selA, from + selB);
  }
  let lastBox = 'dc-body';
  function mdApply(kind) {
    const ta = $id(lastBox) || $id('dc-body'); if (!ta) return;
    const v = ta.value, s = ta.selectionStart, e = ta.selectionEnd, sel = v.slice(s, e);
    const wrap = (l, r, ph) => { const inner = sel || ph; mdInsert(ta, l + inner + r, s, e, l.length, l.length + inner.length); };
    const ls = v.lastIndexOf('\n', s - 1) + 1;
    let le = v.indexOf('\n', e > s && v[e - 1] === '\n' ? e - 1 : e); if (le < 0) le = v.length;
    const lines = fn => { const out = v.slice(ls, le).split('\n').map(fn).join('\n'); mdInsert(ta, out, ls, le, out.length, out.length); };
    const strip = l => l.replace(/^\s*(#{1,3} |-# |[-*] |\d+\. |> )/, '');
    const prefix = (mark, ph) => {
      if (!v.slice(ls, le).trim()) return mdInsert(ta, mark + ph, ls, le, mark.length, mark.length + ph.length);
      return lines(l => mark + strip(l));
    };
    switch (kind) {
      case 'bold': return wrap('**', '**', 'bold text');
      case 'italic': return wrap('*', '*', 'italic text');
      case 'underline': return wrap('__', '__', 'underlined text');
      case 'strike': return wrap('~~', '~~', 'crossed out text');
      case 'spoiler': return wrap('||', '||', 'hidden text');
      case 'code': return wrap('`', '`', 'code');
      case 'codeblock': return wrap('```\n', '\n```', 'code');
      case 'h1': return prefix('# ', 'Big heading');
      case 'h2': return prefix('## ', 'Heading');
      case 'h3': return prefix('### ', 'Small heading');
      case 'sub': return prefix('-# ', 'Small grey text');
      case 'quote': return prefix('> ', 'Quote');
      case 'ul': return prefix('- ', 'List item');
      case 'ol': { if (!v.slice(ls, le).trim()) return mdInsert(ta, '1. List item', ls, le, 3, 12); let k = 0; return lines(l => `${++k}. ` + strip(l)); }
      case 'link': { const t = sel || 'link text'; return mdInsert(ta, `[${t}](https://)`, s, e, t.length + 3, t.length + 11); }
    }
  }
  // Enter in a list starts the next item; Enter on an empty item ends the list.
  function mdEnter(ev) {
    const ta = ev.target, v = ta.value, s = ta.selectionStart;
    if (s !== ta.selectionEnd) return;
    const ls = v.lastIndexOf('\n', s - 1) + 1, line = v.slice(ls, s);
    const m = line.match(/^(\s*)([-*]|(\d+)\.)\s+(.*)$/);
    if (!m) return;
    ev.preventDefault();
    if (!m[4].trim()) return mdInsert(ta, '\n', ls, s, 1, 1);
    const ins = `\n${m[1]}${m[3] ? `${Number(m[3]) + 1}.` : m[2]} `;
    mdInsert(ta, ins, s, s, ins.length, ins.length);
  }

  // ---------- Actions ----------
  function newPost() {
    const hs = hooks();
    const last = S.st.posts.find(x => hookOf(x.webhookId));
    S.post = { id: 'p' + rand12(), title: '', body: '', style: 'card', color: '#f2c75c', image: null, icon: null, ping: false,
      webhookId: hs.length === 1 ? hs[0].id : last ? last.webhookId : '', sent: null, link: '', _isNew: true };
    S.customColor = false; S.saveState = 'saved'; S.view = 'edit'; S.problem = '';
    draw(); window.scrollTo(0, 0);
    const t = $id('dc-title'); if (t) t.focus();
  }
  function editPost(id) {
    const p = S.st.posts.find(x => x.id === id); if (!p) return;
    S.post = JSON.parse(JSON.stringify(p));
    S.customColor = !COLORS.some(c => c[0] === S.post.color);
    S.saveState = 'saved'; S.view = 'edit'; S.problem = '';
    draw(); window.scrollTo(0, 0);
  }
  async function back() {
    if (saveTimer) await saveNow(); else await saving;
    S.post = null; S.view = 'list'; draw(); window.scrollTo(0, 0);
  }
  function readFile(f) {
    return new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = () => reject(new Error("That picture couldn't be read")); r.readAsDataURL(f); });
  }
  async function useFile(input) {
    const slot = input.dataset.dcFile, f = input.files && input.files[0], p = S.post;
    input.value = '';
    if (!f || !p) return;
    if (!/^image\/(png|jpeg|gif|webp)$/.test(f.type)) return toast('Pick a PNG, JPG, GIF or WEBP picture', true);
    if (f.size > MAX_IMAGE) return toast(`That picture is ${mb(f.size)}. Pick one up to 3.5 MB.`, true);
    S.busy = slot; draw();
    try {
      const r = await api('POST', '/api/discord/media', { name: f.name, data: await readFile(f) });
      p[slot] = { kind: 'upload', media: r.media, name: r.name };
      if (S.post === p) saveSoon();
    } catch (e) { toast(e.message, true); }
    S.busy = ''; draw();
  }
  function askUrl(slot) {
    showModal(`<h2>${slot === 'icon' ? 'Icon' : 'Picture'} from a web address</h2>
      <div class="field"><label for="dc-url">Picture address</label><input id="dc-url" type="url" class="wide" placeholder="https://" autocomplete="off">
        <p class="hint">Right-click a picture on a website, choose "Copy image address", and paste it here. It has to start with https://</p></div>
      <div class="actions"><button class="sbtn" data-dc="modal-cancel">Cancel</button><button class="pbtn" data-dc="url-go" data-slot="${slot}">Use this picture</button></div>`);
  }
  function addChannel() {
    showModal(`<h2>Add a Discord channel</h2>
      <ol class="setup-steps">
        <li><span>In Discord, open your server's <b>Server Settings</b>, go to <b>Integrations</b>, then <b>Webhooks</b>, and press <b>New Webhook</b>.</span></li>
        <li><span>Pick the channel it posts in. Its name and picture are what your posts show as. Then press <b>Copy Webhook URL</b>.</span></li>
        <li><span>Paste it below.</span></li>
      </ol>
      <div class="field" style="margin-top:16px"><label for="dc-hook-url">Webhook link</label><input id="dc-hook-url" type="text" class="wide" placeholder="https://discord.com/api/webhooks/..." autocomplete="off" spellcheck="false"></div>
      <div class="field"><label for="dc-hook-label">Name for it here <span class="muted small">(optional)</span></label><input id="dc-hook-label" type="text" class="wide" maxlength="60" placeholder="#announcements">
        <p class="hint">Only shown in the Admin, so you can tell your channels apart.</p></div>
      <p class="hint">The link is saved only on this PC (admin\\data\\discord.json). Anyone who has it can post in that channel, so don't share it.</p>
      <div class="actions"><button class="sbtn" data-dc="modal-cancel">Cancel</button><button class="pbtn" data-dc="channel-add-go">${ti('plus')} Add channel</button></div>`);
  }
  async function channelAddGo(btn) {
    const url = ($id('dc-hook-url') || {}).value || '', label = ($id('dc-hook-label') || {}).value || '';
    if (!url.trim()) return toast('Paste the webhook link first', true);
    btn.disabled = true; btn.innerHTML = `<span class="spin">${ti('loader-2')}</span> Checking with Discord…`;
    try {
      const r = await api('POST', '/api/discord/channel-add', { url: url.trim(), label });
      S.st = { webhooks: r.webhooks, posts: r.posts };
      if (S.post && !S.post.webhookId && !S.post.sent) { S.post.webhookId = r.added; saveSoon(); }
      closeModal(); draw(); toast('Channel added');
    } catch (e) { toast(e.message, true); btn.disabled = false; btn.innerHTML = `${ti('plus')} Add channel`; }
  }
  function renameChannel(id) {
    const h = hookOf(id); if (!h) return;
    showModal(`<h2>Rename ${esc(h.label)}</h2><div class="field"><label for="dc-rename">Name here</label><input id="dc-rename" type="text" class="wide" maxlength="60" value="${esc(h.label)}"></div>
      <div class="actions"><button class="sbtn" data-dc="modal-cancel">Cancel</button><button class="pbtn" data-dc="rename-go" data-id="${esc(id)}">Save</button></div>`);
  }
  function removeChannel(id) {
    const h = hookOf(id); if (!h) return;
    const used = S.st.posts.filter(p => p.webhookId === id && p.sent).length;
    confirmBox(`Remove ${h.label}?`, `<p>It's only removed from the Admin. The webhook stays in Discord.</p>
      ${used ? `<p class="warn-text">${used} posted message${used === 1 ? '' : 's'} came from it. They stay in Discord, but you can't update or delete ${used === 1 ? 'it' : 'them'} from here until you add the same webhook again.</p>` : ''}`,
    'Remove', async () => {
      try { S.st = await api('POST', '/api/discord/channel-remove', { id }); draw(); toast('Channel removed'); } catch (e) { toast(e.message, true); }
    }, true);
  }
  function send() {
    const p = S.post; if (!p || S.busy === 'send') return;
    const h = hookOf(p.webhookId);
    const cant = html => notice(p.sent ? "Can't update this yet" : "Can't post this yet", html);
    if (stale()) return cant(`<p>${esc(STALE_TEXT)}</p><p>${STALE_FIX}</p>`);
    if (!h) return cant(`<p>${p.sent ? "This post's channel was removed here. Add it again to update the post." : 'Pick a channel first, in the Publish box.'}</p>`);
    if (!p.title.trim() && !p.body.trim() && !p.image) return cant('<p>Write something first.</p>');
    const over = overLimit(p); if (over) return cant(`<p>${esc(over)}</p>`);
    const n = partsOf(p).length, had = p.sent ? 1 + (Array.isArray(p.sent.more) ? p.sent.more.length : 0) : 0;
    const many = n > 1 ? `<p>It's sent as ${n} messages, one after another.</p>` : '';
    const change = !p.sent ? '' : n > had ? `<p>${n - had === 1 ? '1 new message gets' : `${n - had} new messages get`} added at the bottom of the channel, after anything posted since.</p>`
      : n < had ? `<p class="warn-text">${had - n === 1 ? 'The last message' : `The last ${had - n} messages`} of this post ${had - n === 1 ? 'gets' : 'get'} deleted from Discord, because the text is shorter now.</p>` : '';
    confirmBox(p.sent ? 'Update this post on Discord?' : `Post to ${h.label}?`,
      `<p>${p.sent ? `The ${had > 1 ? 'messages' : 'message'} in Discord change${had > 1 ? '' : 's'} to what you see in the preview.` : 'It shows up in the channel right away. You can still edit or delete it later.'}</p>
       ${p.sent ? change : many}
       ${p.ping && !p.sent ? '<p class="warn-text">Everyone in the server gets a notification.</p>' : ''}`,
      p.sent ? 'Update' : 'Post', async () => {
        S.busy = 'send'; S.problem = ''; draw();
        let failed = '';
        try {
          await saveNow();
          const r = await api('POST', '/api/discord/send', { id: p.id });
          S.st = { webhooks: r.webhooks, posts: r.posts };
          const fresh = r.posts.find(x => x.id === p.id);
          if (fresh && S.post && S.post.id === p.id) { S.post.sent = fresh.sent; S.post.link = fresh.link; }
          toast(r.result === 'updated' ? 'Updated on Discord' : 'Posted to Discord');
        } catch (e) {
          failed = e.message;
          try {
            S.st = await api('GET', '/api/discord/state');
            const fresh = S.st.posts.find(x => x.id === p.id);
            if (fresh && S.post && S.post.id === p.id) { S.post.sent = fresh.sent; S.post.link = fresh.link; }
          } catch { /* keep what we have */ }
        }
        S.busy = '';
        if (failed && S.post && S.post.id === p.id) S.problem = failed;
        draw();
        if (failed) notice("That didn't work", `<p>${esc(failed)}</p><p class="hint">This message also stays in the Publish box, next to the button.</p>`);
      });
  }
  function del(id) {
    const p = S.post && S.post.id === id ? S.post : S.st.posts.find(x => x.id === id);
    if (!p) return;
    if (p._isNew && !S.st.posts.some(x => x.id === id)) { clearTimeout(saveTimer); saveTimer = null; S.post = null; S.view = 'list'; return draw(); }
    const name = p.title.trim() ? `<p><b>${esc(p.title)}</b></p>` : '';
    const body = p.sent
      ? `${name}<label class="check"><input type="checkbox" id="dc-del-discord" checked> Also delete ${p.sent.more && p.sent.more.length ? `its ${p.sent.more.length + 1} messages` : 'the message'} from Discord</label><p class="hint" style="margin-top:8px">Untick it to only remove the post from this list and leave ${p.sent.more && p.sent.more.length ? 'the messages' : 'the message'} in Discord.</p>`
      : `${name}<p>This draft was never posted, so nothing changes in Discord.</p>`;
    confirmBox(p.sent ? 'Delete this post?' : 'Delete this draft?', body, 'Delete', async vals => {
      clearTimeout(saveTimer); saveTimer = null;
      await saving;
      try {
        S.st = await api('POST', '/api/discord/delete', { id, fromDiscord: !!(p.sent && vals['dc-del-discord']) });
        if (S.post && S.post.id === id) { S.post = null; S.view = 'list'; }
        draw(); toast(p.sent && vals['dc-del-discord'] ? 'Deleted here and in Discord' : 'Deleted');
      } catch (e) { toast(e.message, true); }
    }, true);
  }

  // ---------- Text flows from one message box into the next ----------
  const boxes = () => [...document.querySelectorAll('#dc-parts textarea[data-part]')];
  // Typing, pasting or deleting in any box: put the whole text back together, then cut it again.
  function bodyInput(ta) {
    const all = boxes(), i = all.indexOf(ta);
    const before = all.slice(0, Math.max(i, 0)).reduce((n, x) => n + x.value.length, 0);
    S.post.body = all.map(x => x.value).join('');
    reflow(before + ta.selectionStart, before + ta.selectionEnd);
  }
  // Makes the boxes match the text. The cursor stays where it was in the text, even if that's now in another box.
  function reflow(caret, caretEnd) {
    const p = S.post, wrap = $id('dc-parts'); if (!p || !wrap) return;
    const parts = partsOf(p), all = boxes();
    if (all.length === parts.length && all.every((x, i) => x.value === parts[i])) return;
    const focused = all.indexOf(document.activeElement);
    if (focused >= 0 && caret === undefined) {
      const before = all.slice(0, focused).reduce((n, x) => n + x.value.length, 0);
      caret = before + all[focused].selectionStart; caretEnd = before + all[focused].selectionEnd;
    }
    if (all.length === parts.length) all.forEach((x, i) => { if (x.value !== parts[i]) x.value = parts[i]; });
    else {
      wrap.innerHTML = partsHtml(p, parts);
      const ed = $id('dc-editor'); if (ed) ed.classList.toggle('multi', parts.length > 1);
    }
    if (caret === undefined) return;
    const now = boxes();
    let off = 0, j = 0;
    while (j < parts.length - 1 && caret > off + parts[j].length) { off += parts[j].length; j++; }
    const box = now[j]; if (!box) return;
    box.focus({ preventScroll: true });
    box.setSelectionRange(caret - off, Math.min(caretEnd, off + parts[j].length) - off);
    lastBox = box.id;
    const r = box.getBoundingClientRect();
    if (r.top < 0 || r.top > innerHeight - 80) box.scrollIntoView({ block: 'center' });
  }
  document.addEventListener('focusin', e => { if (e.target.dataset && e.target.dataset.part !== undefined) lastBox = e.target.id; });

  // ---------- Pasting from a web page keeps its links, pictures and formatting ----------
  // The page's copy comes as HTML; it's written out the Discord way: [text](link), **bold**, # headings,
  // - lists, > quotes, and a ![picture](link) line for each picture. Ctrl+Shift+V still pastes plain text.
  const SKIP = /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|HEAD|TITLE|META|LINK|BUTTON|INPUT|SELECT|TEXTAREA|SVG|IFRAME|OBJECT|VIDEO|AUDIO|CANVAS)$/;
  const BLOCK = /^(P|DIV|SECTION|ARTICLE|HEADER|FOOTER|MAIN|ASIDE|NAV|FIGURE|FIGCAPTION|TABLE|THEAD|TBODY|TR|DL|DT|DD|ADDRESS|DETAILS|SUMMARY|CENTER)$/;
  const oneLine = t => t.replace(/\s+/g, ' ').trim();
  function tidy(t) {
    return t.replace(/[​‌﻿]/g, '').replace(/^‍+|‍+$/gm, '').replace(/[ \t]+$/gm, '')
      .replace(/^[ \t]+(?![ \t]|[-*] |\d+\. )/gm, '').replace(/\n{3,}/g, '\n\n').replace(/^\n+|\n+$/g, '');
  }
  function wrapMark(t, m) {
    const core = t.trim();
    if (!core || core.includes('\n\n') || (core.startsWith(m) && core.endsWith(m))) return t;
    return t.match(/^\s*/)[0] + m + core + m + t.match(/\s*$/)[0];
  }
  // A full web address, or '' for links and pictures that only work on the page they came from.
  function absUrl(u) {
    try { const x = new URL(u); return /^https?:$/.test(x.protocol) && !/^(127\.0\.0\.1|localhost)$/.test(x.hostname) ? x.href : ''; } catch { return ''; }
  }
  function htmlToDiscord(html, count) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const walk = (n, depth) => {
      if (n.nodeType === 3) return n.nodeValue.replace(/\s+/g, ' ');
      if (n.nodeType !== 1) return '';
      const tag = n.tagName.toUpperCase();
      if (SKIP.test(tag)) return '';
      const inner = (d = depth) => [...n.childNodes].map(c => walk(c, d)).join('');
      if (tag === 'BR') return '\n';
      if (tag === 'HR') return '\n\n';
      if (tag === 'IMG') {
        const url = absUrl(n.getAttribute('src') || '');
        const w = Number(n.getAttribute('width')) || 0, h = Number(n.getAttribute('height')) || 0;
        // Leave out what Discord can't show (SVG drawings) and tiny icons.
        if (!url || /\.svg(\?|#|$)/i.test(url) || (w && w < 40) || (h && h < 40)) { count.skipped++; return ''; }
        count.pics++;
        return `\n\n![${oneLine(n.getAttribute('alt') || '').replace(/[[\]]/g, '')}](${url.replace(/\)/g, '%29')})\n\n`;
      }
      if (tag === 'PRE') return '\n\n```\n' + n.textContent.replace(/\n+$/, '') + '\n```\n\n';
      if (tag === 'CODE') return wrapMark(n.textContent.replace(/`/g, ''), '`');
      if (/^H[1-6]$/.test(tag)) { const t = oneLine(inner()); return t ? `\n\n${'#'.repeat(Math.min(3, Number(tag[1])))} ${t}\n\n` : ''; }
      if (tag === 'A') {
        const t = inner();
        if (t.includes('![')) return t; // a picture that is also a link: keep the picture
        const href = absUrl(n.getAttribute('href') || ''), text = oneLine(t);
        if (!href || !text) return t;
        count.links++;
        if (text === href || text === href.replace(/^https?:\/\//, '').replace(/\/$/, '')) return t.replace(text, href);
        return t.replace(text, `[${text.replace(/[[\]]/g, '')}](${href.replace(/\)/g, '%29').replace(/ /g, '%20')})`);
      }
      if (tag === 'STRONG' || tag === 'B') return wrapMark(inner(), '**');
      if (tag === 'EM' || tag === 'I') return wrapMark(inner(), '*');
      if (tag === 'U' || tag === 'INS') return wrapMark(inner(), '__');
      if (tag === 'S' || tag === 'DEL' || tag === 'STRIKE') return wrapMark(inner(), '~~');
      if (tag === 'UL' || tag === 'OL') {
        let k = Number(n.getAttribute('start')) || 1;
        const pad = '  '.repeat(depth);
        const items = [...n.children].filter(c => c.tagName.toUpperCase() === 'LI').map(li => {
          const lines = tidy([...li.childNodes].map(c => walk(c, depth + 1)).join('')).split('\n');
          const own = lines.filter(l => l.trim() && !/^\s+([-*]|\d+\.) /.test(l)).join(' ');
          const sub = lines.filter(l => /^\s+([-*]|\d+\.) /.test(l));
          if (!own && !sub.length) return '';
          return [`${pad}${n.tagName.toUpperCase() === 'OL' ? `${k++}.` : '-'} ${own}`, ...sub].join('\n');
        }).filter(Boolean);
        return items.length ? `\n\n${items.join('\n')}\n\n` : '';
      }
      if (tag === 'BLOCKQUOTE') { const t = tidy(inner()); return t ? `\n\n${t.split('\n').map(l => '> ' + l).join('\n')}\n\n` : ''; }
      if (tag === 'TD' || tag === 'TH') return inner() + '  ';
      if (BLOCK.test(tag)) return `\n\n${inner()}\n\n`;
      return inner();
    };
    return tidy(walk(doc.body, 0));
  }
  document.addEventListener('paste', e => {
    const ta = e.target;
    if (!ta || !ta.dataset || ta.dataset.part === undefined || !S.post) return;
    const html = e.clipboardData && e.clipboardData.getData('text/html');
    if (!html || !/<(a|img|strong|b|em|i|u|s|del|h[1-6]|ul|ol|blockquote|pre|code)[\s>]/i.test(html)) return; // plain text: normal paste
    const count = { links: 0, pics: 0, skipped: 0 };
    let text = '';
    try { text = htmlToDiscord(html, count); } catch { return; }
    if (!text) return;
    e.preventDefault();
    ta.focus();
    let ok = false;
    try { ok = document.execCommand('insertText', false, text); } catch { ok = false; }
    if (!ok) { ta.setRangeText(text, ta.selectionStart, ta.selectionEnd, 'end'); ta.dispatchEvent(new Event('input', { bubbles: true })); }
    const bits = [count.links && `${count.links} link${count.links === 1 ? '' : 's'}`, count.pics && `${count.pics} picture${count.pics === 1 ? '' : 's'}`].filter(Boolean);
    if (bits.length || count.skipped) toast(`Pasted${bits.length ? ' with ' + bits.join(' and ') : ''}.${count.skipped ? ` Left out ${count.skipped} small icon${count.skipped === 1 ? '' : 's'} or drawing${count.skipped === 1 ? '' : 's'} Discord can't show.` : ''}`);
  });

  // ---------- Events (only for things on this page, marked data-dc / data-dcf) ----------
  document.addEventListener('click', async e => {
    const el = e.target.closest('[data-dc]'); if (!el) return;
    const a = el.dataset.dc, id = el.dataset.id, slot = el.dataset.slot;
    switch (a) {
      case 'reload': S.err = ''; draw(); return load();
      case 'new': return newPost();
      case 'edit': return editPost(id);
      case 'back': return back();
      case 'filter': S.filter = el.dataset.f; return draw();
      case 'view': S.mdView = el.dataset.view; try { localStorage.setItem('wl.admin.dcView', S.mdView); } catch { /* ignore */ } return draw();
      case 'md': return mdApply(el.dataset.md);
      case 'save': await saveNow(); return toast(S.saveState === 'error' ? "Couldn't save" : 'Saved on this PC', S.saveState === 'error');
      case 'send': return send();
      case 'delete': return del(id);
      case 'pick-file': { const f = $id('dc-file-' + slot); if (f) f.click(); return; }
      case 'pick-url': return askUrl(slot);
      case 'url-go': {
        const v = (($id('dc-url') || {}).value || '').trim();
        if (!/^https:\/\/\S+$/i.test(v)) return toast('The address has to start with https://', true);
        if (S.post) { S.post[slot] = { kind: 'url', url: v }; saveSoon(); }
        closeModal(); return draw();
      }
      case 'pic-remove': if (S.post) { S.post[slot] = null; saveSoon(); } return draw();
      case 'add-channel': return addChannel();
      case 'channel-add-go': return channelAddGo(el);
      case 'rename-channel': return renameChannel(id);
      case 'rename-go': {
        const label = ($id('dc-rename') || {}).value || '';
        try { S.st = await api('POST', '/api/discord/channel-update', { id, label }); closeModal(); draw(); } catch (err) { toast(err.message, true); }
        return;
      }
      case 'remove-channel': return removeChannel(id);
      case 'modal-cancel': return closeModal();
      case 'problem-close': { S.problem = ''; const w = $id('dc-warn'); if (w && S.post) w.innerHTML = warnHtml(S.post); return; }
      case 'modal-ok': {
        const vals = {};
        $id('modal').querySelectorAll('input').forEach(i => { vals[i.id] = i.type === 'checkbox' ? i.checked : i.value; });
        const f = modalFn; closeModal(); if (f) await f(vals);
        return;
      }
    }
  });
  document.addEventListener('input', e => {
    const t = e.target, k = t.dataset && t.dataset.dcf;
    if (!k || !S.post) return;
    if (k === 'body') { bodyInput(t); refreshBits(); return saveSoon(); }
    if (k === 'title') { S.post.title = t.value; reflow(); refreshBits(); return saveSoon(); }
    if (k === 'color') { S.post.color = t.value.toLowerCase(); refreshBits(); return saveSoon(); }
  });
  document.addEventListener('change', e => {
    const t = e.target;
    if (t.dataset && t.dataset.dcFile) return useFile(t);
    const k = t.dataset && t.dataset.dcf;
    if (!k || !S.post) return;
    if (k === 'webhookId') { S.post.webhookId = t.value; refreshBits(); return saveSoon(); }
    if (k === 'ping') { S.post.ping = t.checked; reflow(); refreshBits(); return saveSoon(); }
    if (k === 'style') { S.post.style = t.value === 'simple' ? 'simple' : 'card'; saveSoon(); return draw(); }
    if (k === 'colorPick') {
      if (t.value === 'custom') { S.customColor = true; return draw(); }
      S.customColor = false; S.post.color = t.value; saveSoon(); return draw();
    }
  });
  document.addEventListener('keydown', e => {
    if (e.target.dataset && e.target.dataset.part !== undefined) {
      if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.altKey) mdEnter(e);
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey) {
        const map = { b: 'bold', i: 'italic', u: 'underline', k: 'link' }, k = e.key.toLowerCase();
        if (map[k]) { e.preventDefault(); mdApply(map[k]); }
      }
    }
    if (e.key === 'Enter') {
      const go = { 'dc-url': 'url-go', 'dc-hook-url': 'channel-add-go', 'dc-hook-label': 'channel-add-go', 'dc-rename': 'rename-go' }[e.target.id];
      if (go) { e.preventDefault(); const b = $id('modal').querySelector(`[data-dc="${go}"]`); if (b) b.click(); }
    }
  });
  // Formatting buttons keep the text selected while you click them.
  document.addEventListener('mousedown', e => { if (e.target.closest('.dc-tools button')) e.preventDefault(); });

  window.WLDiscord = { page };
})();

// Warchief Admin page. Everything here saves to a draft on this PC; Publish sends it to GitHub for the launchers.
(function () {
  'use strict';

  const $ = s => document.querySelector(s);
  const main = $('#main'), nav = $('#nav'), overlay = $('#overlay'), modal = $('#modal'), toastEl = $('#toast'), topStatus = $('#top-status');
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ti = n => `<i class="ti ti-${n}" aria-hidden="true"></i>`;
  const clone = o => JSON.parse(JSON.stringify(o));
  const fmt = t => t ? new Date(t).toLocaleString([], { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }) : '';
  const fmtDay = t => t ? new Date(t).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : '';

  const A = { st: null, page: 'publish', repos: null, reposErr: '', rel: {}, relErr: {}, loadingRel: {}, branches: {}, edit: null, inspecting: {}, busy: false };

  // "repo" lets the Admin read releases from private addon repos too (Members & access page).
  const TOKEN_URL = 'https://github.com/settings/tokens/new?scopes=repo&description=Warchief%20Admin';
  const LINK_TARGETS = [['discord', 'Discord link'], ['support', 'Support link'], ['news', 'News link'], ['curseforge', 'CurseForge link'], ['github', 'GitHub link'], ['none', 'No link']];
  const LINK_FIELDS = [
    ['news', 'News page', 'Opens from the News tab at the top of the launcher.'],
    ['discord', 'Discord invite', 'Used by Help > Discord and the news card.'],
    ['support', 'Support page', 'Used by Help > Support.'],
    ['curseforge', 'CurseForge page', 'Shown in Options > About.'],
    ['github', 'GitHub', 'Shown in Options > About.']
  ];
  const KNOWN_FOLDERS = [
    ['_retail_', 'Retail'], ['_classic_beta_', 'Classic beta / WoW: Forever'], ['_classic_', 'Classic (progression)'],
    ['_classic_era_', 'Classic Era'], ['_anniversary_', 'Anniversary'], ['_beta_', 'Beta'], ['_ptr_', 'PTR'],
    ['_xptr_', 'Experimental PTR'], ['_classic_ptr_', 'Classic PTR'], ['_classic_era_ptr_', 'Classic Era PTR']
  ];

  // ---------- Server calls ----------
  async function api(method, url, body) {
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json', 'X-Admin': '1' }, body: body ? JSON.stringify(body) : undefined });
    let data = {};
    try { data = await res.json(); } catch { /* empty */ }
    if (!res.ok) throw new Error(data.error || 'Something went wrong');
    return data;
  }
  let toastTimer = null;
  function toast(msg, bad) {
    toastEl.textContent = msg; toastEl.classList.toggle('bad', !!bad); toastEl.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { toastEl.hidden = true; }, bad ? 6000 : 3800);
  }

  const draft = () => A.st.draft;
  const published = () => (A.st.published ? A.st.published.catalog : null);
  const gameName = id => { const g = draft().games.find(x => x.id === id); return g ? g.name : id; };

  let saveTimer = null;
  function changed() {
    renderTop(); renderNav();
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      try { await api('PUT', '/api/draft', { draft: draft() }); } catch (e) { toast(e.message, true); }
    }, 250);
  }

  // ---------- What changed since the last publish ----------
  const pickCat = c => c ? { games: c.games || [], links: c.links || {}, news: c.news || [], products: c.products || [], access: c.access || null, tickets: c.tickets || null, roadmap: c.roadmap || null } : null;
  // The Tickets settings and to-do list the way Publish sends them (only finished buttons and items)
  // The To-do board the way Publish sends it (finished columns and cards only)
  const pubRoadmap = r => (r ? { title: (r.title || '').trim(), columns: (r.columns || []).filter(c => (c.name || '').trim()).map(c => ({ ...c, name: c.name.trim(), cards: (c.cards || []).filter(k => (k.title || '').trim()).map(k => ({ ...k, title: k.title.trim(), text: (k.text || '').trim() })) })) } : null);
  const pubTickets = t => (t ? { ...t, types: (t.types || []).filter(y => (y.label || '').trim()).map(y => ({ ...y, label: y.label.trim(), questions: (y.questions || []).filter(q => (q.label || '').trim()) })) } : null);
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  function changes() {
    const a = pickCat(draft()), b = pickCat(published());
    const out = [];
    const ver = p => (p && p.release ? p.release.version : null);
    if (!b) {
      out.push(['sparkles', 'First publish: the launcher starts reading your addon list']);
      a.products.filter(p => p.enabled !== false).forEach(p => out.push(['package', `${p.name}: ${ver(p) || 'no version picked yet'}`]));
      return out;
    }
    const bp = new Map(b.products.map(p => [p.id, p]));
    const ap = new Map(a.products.map(p => [p.id, p]));
    for (const p of a.products) {
      const o = bp.get(p.id);
      if (!o) { out.push(['plus', `Added ${p.name}${ver(p) ? ' ' + ver(p) : ''}`]); continue; }
      if (ver(p) !== ver(o)) out.push(['arrow-up-circle', `${p.name}: ${ver(o) || 'none'} → ${ver(p) || 'none'}`]);
      const bv = x => (x.beta ? x.beta.version : null);
      if (bv(p) !== bv(o)) out.push(['flask', `${p.name} beta: ${bv(o) || 'none'} → ${bv(p) || 'none'}`]);
      if (p.enabled !== o.enabled) out.push([p.enabled === false ? 'eye-off' : 'eye', `${p.name} ${p.enabled === false ? 'hidden' : 'shown again'}`]);
      const meta = ['name', 'short', 'icon', 'type', 'requires', 'game', 'repo', 'changelogUrl', 'access'];
      if (meta.some(k => !same(p[k] ?? null, o[k] ?? null))) out.push(['edit', `${p.name}: details changed`]);
    }
    for (const o of b.products) if (!ap.has(o.id)) out.push(['trash', `Removed ${o.name}`]);
    const order = list => list.map(p => p.id).filter(id => ap.has(id) && bp.has(id));
    if (!same(order(a.products), order(b.products))) out.push(['arrows-sort', 'Addon order changed']);
    if (!same(a.games, b.games)) out.push(['device-gamepad-2', 'Game versions changed']);
    if (!same(a.news, b.news)) out.push(['news', 'News changed']);
    if (!same(a.links, b.links)) out.push(['link', 'Links changed']);
    if (!same(a.access, b.access)) out.push(['lock', 'Members & access changed']);
    if (!same(pubTickets(a.tickets), b.tickets)) out.push(['ticket', 'Tickets changed']);
    if (!same(pubRoadmap(a.roadmap), b.roadmap)) out.push(['checklist', 'To-do board changed']);
    return out;
  }
  const changeCount = () => (published() ? changes().length : 1);

  // ---------- GitHub data ----------
  function loadReleases(repo, force) {
    if (!repo) return Promise.resolve([]);
    if (A.rel[repo] && !force) return Promise.resolve(A.rel[repo]);
    if (A.loadingRel[repo]) return A.loadingRel[repo];
    A.loadingRel[repo] = api('GET', '/api/releases?repo=' + encodeURIComponent(repo))
      .then(r => { A.rel[repo] = r; delete A.relErr[repo]; return r; })
      .catch(e => { A.relErr[repo] = e.message; A.rel[repo] = []; return []; })
      .finally(() => { delete A.loadingRel[repo]; });
    return A.loadingRel[repo];
  }
  async function loadAllReleases(force) {
    const repos = [...new Set(draft().products.map(p => p.repo).filter(Boolean))];
    await Promise.all(repos.map(r => loadReleases(r, force)));
  }
  async function ensureRepos(force) {
    if (!A.st.connected) return [];
    if (A.repos && !force) return A.repos;
    try { A.repos = await api('GET', '/api/repos'); A.reposErr = ''; }
    catch (e) { A.repos = []; A.reposErr = e.message; }
    return A.repos;
  }
  function pickMainToc(info, version) {
    const tocs = info.tocs || [];
    return tocs.find(t => t.version && t.version.replace(/^v/i, '') === version) || tocs.slice().sort((a, b) => a.folder.length - b.folder.length)[0] || null;
  }
  async function releaseFor(repo, tag, assetName) {
    const rels = await loadReleases(repo);
    const r = rels.find(x => x.tag === tag);
    if (!r) throw new Error('That release is gone. Press Refresh and try again.');
    const zips = r.assets.filter(a => /\.zip$/i.test(a.name));
    if (!zips.length) throw new Error(`${tag} has no .zip file attached on GitHub, so the launcher can't install it`);
    const asset = zips.find(a => a.name === assetName) || zips[0];
    const info = await api('POST', '/api/inspect', { url: asset.url });
    if (!info.folders.length) throw new Error(`${asset.name} has no addon folders inside`);
    const toc = pickMainToc(info, r.version);
    return {
      tag: r.tag, version: r.version, name: r.name, prerelease: r.prerelease, publishedAt: r.publishedAt,
      asset: asset.name, size: asset.size, url: asset.url,
      folders: info.folders, mainFolder: toc ? toc.folder : info.folders[0],
      tocVersion: toc ? toc.version : '', interface: toc ? toc.interface : '',
      notes: r.notes || ''
    };
  }
  function tocWarning(rel) {
    if (!rel) return '';
    if (rel.tocVersion && rel.tocVersion.replace(/^v/i, '') !== rel.version) {
      return `The .toc in ${rel.mainFolder} says ${rel.tocVersion}, but the release is ${rel.version}. Players would always see an update. Fix the .toc or the tag.`;
    }
    return '';
  }

  // ---------- Layout ----------
  const NAV = [['publish', 'Publish', 'rocket'], ['addons', 'Addons', 'puzzle'], ['games', 'Game versions', 'device-gamepad-2'], ['news', 'News', 'news'], ['todo', 'To-do', 'checklist'], ['discord', 'Discord posts', 'brand-discord'], ['tickets', 'Tickets', 'ticket'], ['access', 'Members & access', 'lock'], ['links', 'Links', 'link'], ['launcher', 'Launcher', 'app-window'], ['settings', 'GitHub settings', 'brand-github']];
  function renderNav() {
    const n = changeCount();
    nav.innerHTML = NAV.map(([id, label, ic]) => `<button class="${A.page === id ? 'on' : ''}" data-action="page" data-page="${id}">${ti(ic)} ${label}${id === 'publish' && n ? `<span class="count">${n}</span>` : ''}${id === 'news' && A.newsEdit && A.newsEdit.dirty ? '<span class="count" title="A post you are writing is not saved yet">Draft</span>' : ''}</button>`).join('');
  }
  function renderTop() {
    if (!A.st.connected) { topStatus.innerHTML = `<span class="warn-text"><span class="dot warn"></span>GitHub not connected</span>`; return; }
    const n = changeCount();
    topStatus.innerHTML = n
      ? `<span class="warn-text"><span class="dot warn"></span>${published() ? `${n} unpublished change${n > 1 ? 's' : ''}` : 'Not published yet'}</span><button class="pbtn" data-action="publish">${ti('rocket')} Publish</button>`
      : `<span class="ok-text"><span class="dot ok"></span>Everything is published</span>`;
  }
  function render() {
    renderTop(); renderNav();
    const pages = { publish: pPublish, addons: pAddons, games: pGames, news: pNews, links: pLinks, launcher: pLauncher, settings: pSettings, discord: () => (window.WLDiscord ? window.WLDiscord.page() : '<p class="muted">Loading…</p>'), access: () => (window.WLAccess ? window.WLAccess.page() : '<p class="muted">Loading…</p>'), tickets: () => (window.WLTickets ? window.WLTickets.page() : '<p class="muted">Loading…</p>'), todo: () => (window.WLTodo ? window.WLTodo.page() : '<p class="muted">Loading…</p>') };
    const y = window.scrollY;
    main.innerHTML = `<div class="page">${(pages[A.page] || pPublish)()}</div>`;
    window.scrollTo(0, y);
  }

  // ---------- Publish page ----------
  function groupedOptions() {
    const d = draft();
    let html = '';
    for (const p of d.products) {
      const rels = A.rel[p.repo];
      html += `<optgroup label="${esc(p.name)} (${esc(gameName(p.game))})">`;
      if (A.loadingRel[p.repo] || rels === undefined) html += `<option disabled>Loading releases…</option>`;
      else if (A.relErr[p.repo]) html += `<option disabled>Couldn't load: ${esc(A.relErr[p.repo])}</option>`;
      else if (!rels.length) html += `<option disabled>No releases on GitHub yet</option>`;
      else {
        for (const r of rels) {
          const cur = p.release && p.release.tag === r.tag;
          html += `<option value="${esc(p.id)}|${esc(r.tag)}">${esc(r.tag)}  ·  ${esc(fmtDay(r.publishedAt))}${r.prerelease ? '  ·  pre-release' : ''}${cur ? '  ·  current' : ''}</option>`;
        }
      }
      html += '</optgroup>';
    }
    return html;
  }
  function pPublish() {
    const st = A.st, d = draft(), pub = A.st.published;
    const steps = [
      [st.connected, 'Connect your GitHub account', 'settings'],
      [!!st.catalogRepo, 'Choose the repo the launcher reads from', 'settings'],
      [d.products.every(p => p.enabled === false || p.release), 'Pick a version for each addon (below)', null],
      [!!pub, 'Publish', null]
    ];
    const setup = steps.every(s => s[0]) ? '' : `<div class="card"><h2>Getting set up</h2><ol class="setup-steps">${steps.map(([done, label, page]) =>
      `<li class="${done ? 'done' : ''}"><span>${label}</span>${!done && page ? `<button class="sbtn" data-action="page" data-page="${page}">Open</button>` : ''}</li>`).join('')}</ol></div>`;

    const status = `<div class="card"><div class="status-list">
      <span class="k">GitHub</span><span>${st.connected ? `<span class="dot ok"></span>Connected as @${esc(st.login)}` : '<span class="dot bad"></span>Not connected'}</span><span><button class="tbtn" data-action="page" data-page="settings">${ti('settings')} Change</button></span>
      <span class="k">Launcher reads from</span><span>${st.catalogRepo ? `<span class="mono">${esc(st.catalogRepo)} · ${esc(st.branch)} · ${esc(st.catalogPath)}</span>` : '<span class="warn-text">Not chosen yet</span>'}</span><span></span>
      <span class="k">Last published</span><span>${pub ? `${esc(fmt(pub.at))}${pub.commitUrl ? ` · <a href="${esc(pub.commitUrl)}" target="_blank" rel="noopener">View on GitHub ${ti('external-link')}</a>` : ''}` : '<span class="muted">Never</span>'}</span><span></span>
    </div></div>`;

    const pubMap = new Map((published() ? published().products : []).map(p => [p.id, p]));
    const rows = d.products.map(p => {
      const was = pubMap.get(p.id), now = p.release ? p.release.version : null, before = was && was.release ? was.release.version : null;
      const tag = p.enabled === false ? '<span class="tag off">Hidden</span>' : !now ? '<span class="tag warn">Pick a version</span>' : now !== before ? '<span class="tag new">Changes on publish</span>' : '<span class="tag ok">Live</span>';
      const warn = tocWarning(p.release);
      return `<tr><td>${prodCell(p)}</td><td>${before ? esc(before) : '<span class="muted">—</span>'}</td><td>${now ? esc(now) : '<span class="muted">—</span>'}${p.beta ? ` <span class="tag">beta ${esc(p.beta.version)}</span>` : ''}${warn ? `<div class="warn-text small">${ti('alert-triangle')} ${esc(warn)}</div>` : ''}</td><td>${tag}</td></tr>`;
    }).join('');

    const versions = `<div class="card">
      <div class="card-head"><div><h2>Set versions</h2><p class="hint">Pick the version the launcher offers for each addon. Each addon shows its ${A.st.maxReleases} newest GitHub releases.</p></div>
        <button class="sbtn" data-action="refresh-releases">${ti('refresh')} Refresh</button></div>
      <div class="picker"><select id="quick" aria-label="Release">${groupedOptions()}</select><button class="pbtn" data-action="quick-set" ${A.busy ? 'aria-busy="true"' : ''}>${A.busy ? `<span class="spin">${ti('loader-2')}</span> Reading zip…` : 'Use this version'}</button></div>
      <table class="table" style="margin-top:16px"><thead><tr><th>Addon</th><th>In the launcher now</th><th>After you publish</th><th></th></tr></thead><tbody>${rows}</tbody></table>
    </div>`;

    const ch = changes();
    const n = changeCount();
    const ready = `<div class="card"><h2>${n ? 'Ready to publish' : 'All published'}</h2>
      ${n ? `<ul class="changes">${ch.map(([ic, t]) => `<li>${ti(ic)}<span>${esc(t)}</span></li>`).join('')}</ul>` : '<p class="muted">The launcher shows exactly what\'s here.</p>'}
      <div class="row-actions"><button class="pbtn big" data-action="publish">${ti('rocket')} Publish to launcher</button>${published() && n ? `<button class="sbtn" data-action="discard">${ti('arrow-back-up')} Discard changes</button>` : ''}</div>
    </div>`;
    return `<h1>Publish</h1><p class="lead">Changes save on this PC as you make them. Players only see them after you publish.</p>${setup}${status}${versions}${ready}`;
  }
  function prodCell(p) {
    const icon = p.icon === 'logo' ? '<div class="picon logo"><img src="/assets/wwd_logo_transparent.png" alt=""></div>' : `<div class="picon">${esc(p.short || '?')}</div>`;
    const needs = p.type === 'plugin' && p.requires ? (draft().products.find(x => x.id === p.requires) || {}).name : '';
    return `<div class="prod-cell">${icon}<div><div class="pname">${esc(p.name)}</div><div class="psub">${p.type === 'plugin' ? `Plugin${needs ? ' for ' + esc(needs) : ''}` : 'Main addon'}</div></div></div>`;
  }

  // ---------- Addons page ----------
  function pAddons() {
    const d = draft();
    const rows = d.products.map((p, i) => `<tr>
      <td>${prodCell(p)}</td>
      <td>${esc(gameName(p.game))}</td>
      <td>${p.release ? esc(p.release.tag) : '<span class="tag warn">Pick a version</span>'}${p.enabled === false ? ' <span class="tag off">Hidden</span>' : ''}</td>
      <td>${accessTag(p)}</td>
      <td class="psub">${esc(p.repo || '—')}</td>
      <td class="acts">
        <button class="tbtn" data-action="move" data-kind="products" data-i="${i}" data-dir="-1" aria-label="Move up" title="Move up">${ti('arrow-up')}</button>
        <button class="tbtn" data-action="move" data-kind="products" data-i="${i}" data-dir="1" aria-label="Move down" title="Move down">${ti('arrow-down')}</button>
        <button class="tbtn" data-action="edit-product" data-id="${esc(p.id)}">${ti('pencil')} Edit</button>
        <button class="tbtn danger" data-action="delete-product" data-id="${esc(p.id)}" aria-label="Delete" title="Delete">${ti('trash')}</button>
      </td></tr>`).join('');
    return `<h1>Addons</h1><p class="lead">Everything the launcher lists, in this order. Plugins sit under their game, after the main addon.</p>
      <div class="card"><div class="card-head"><h2>${d.products.length} addon${d.products.length === 1 ? '' : 's'}</h2><button class="pbtn" data-action="add-product">${ti('plus')} Add addon</button></div>
      ${d.products.length ? `<table class="table"><thead><tr><th>Addon</th><th>Game</th><th>Version</th><th>Who can download</th><th>Repo</th><th></th></tr></thead><tbody>${rows}</tbody></table>` : '<div class="empty">No addons yet. Press Add addon to list your first one.</div>'}
      </div>`;
  }

  // Who can download (Members & access page). Missing means Discord members, the default.
  const ACCESS = [['everyone', 'Everyone', 'No login needed'], ['members', 'Discord members', 'Logged in and in the Warchief Discord'], ['testers', 'Testers only', 'Members with a beta role']];
  const accessOf = p => (ACCESS.some(x => x[0] === p.access) ? p.access : 'members');
  const accessTag = p => { const a = accessOf(p); return `<span class="tag ${a === 'everyone' ? '' : 'lockt'}">${a === 'everyone' ? '' : ti('lock') + ' '}${esc(ACCESS.find(x => x[0] === a)[1])}</span>`; };

  function initials(name) {
    const part = String(name || '').split(/\s+-\s+/).pop().trim();
    const words = part.split(/\s+/).filter(Boolean);
    if (words.length > 1) return (words[0][0] + words[1][0]).toUpperCase();
    return part.slice(0, 2).toUpperCase();
  }
  function slug(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'addon'; }
  function uniqueId(base, list) { let id = base, n = 2; while (list.some(x => x.id === id)) id = `${base}-${n++}`; return id; }
  function nameFromRepo(repo) {
    const n = String(repo || '').split('/').pop().replace(/[_-]+/g, ' ').replace(/\bwow\b/ig, 'WoW').trim();
    return n.replace(/\b\w/g, c => c.toUpperCase());
  }

  function openProduct(id) {
    const d = draft();
    const firstMain = d.products.find(x => x.type === 'main');
    const p = id ? clone(d.products.find(x => x.id === id)) : {
      id: '', name: '', short: '', icon: 'badge', type: firstMain ? 'plugin' : 'main', requires: firstMain ? firstMain.id : null,
      game: (d.games[0] || {}).id, repo: '', enabled: true, changelogUrl: '', release: null, beta: null, access: 'members'
    };
    A.edit = { isNew: !id, p, shortTouched: !!id };
    renderEditor();
    ensureRepos().then(renderEditor);
    if (p.repo) loadReleases(p.repo).then(renderEditor);
  }

  function releaseOptions(p, key) {
    const rels = A.rel[p.repo];
    const cur = p[key] ? p[key].tag : '';
    let html = `<option value="">${key === 'beta' ? 'No beta' : 'Not picked yet'}</option>`;
    if (!p.repo) return html;
    if (A.loadingRel[p.repo] || rels === undefined) return html + '<option disabled>Loading releases…</option>';
    if (A.relErr[p.repo]) return html + `<option disabled>Couldn't load: ${esc(A.relErr[p.repo])}</option>`;
    if (!rels.length) return html + '<option disabled>No releases on GitHub yet</option>';
    for (const r of rels) html += `<option value="${esc(r.tag)}" ${r.tag === cur ? 'selected' : ''}>${esc(r.tag)}  ·  ${esc(fmtDay(r.publishedAt))}${r.prerelease ? '  ·  pre-release' : ''}</option>`;
    if (cur && !rels.some(r => r.tag === cur)) html += `<option value="${esc(cur)}" selected>${esc(cur)} (older than the newest ${A.st.maxReleases})</option>`;
    return html;
  }
  function releaseInfo(p, key) {
    if (A.inspecting[key]) return `<p class="hint"><span class="spin">${ti('loader-2')}</span> Reading the zip…</p>`;
    const r = p[key];
    if (!r) return '';
    const rel = (A.rel[p.repo] || []).find(x => x.tag === r.tag);
    const zips = rel ? rel.assets.filter(a => /\.zip$/i.test(a.name)) : [];
    const assetPick = zips.length > 1
      ? `<div class="field" style="margin:8px 0 0"><label>Zip file</label><select class="wide" data-edit-asset="${key}">${zips.map(z => `<option ${z.name === r.asset ? 'selected' : ''}>${esc(z.name)}</option>`).join('')}</select></div>` : '';
    const warn = tocWarning(r);
    return `${assetPick}<div class="folders small"><div><span class="muted">Zip</span><span class="mono">${esc(r.asset)}</span></div>
      ${r.folders.map(f => `<div><span class="mono">${esc(f)}</span><span class="muted">${f === r.mainFolder ? 'version read from here' : ''}</span></div>`).join('')}
      ${r.interface ? `<div><span class="muted">Game interface</span><span class="mono">${esc(r.interface)}</span></div>` : ''}</div>
      ${warn ? `<p class="hint warn-text">${ti('alert-triangle')} ${esc(warn)}</p>` : ''}`;
  }

  function renderEditor() {
    if (!A.edit) return;
    const { p, isNew } = A.edit;
    const d = draft();
    const repos = (A.repos || []).filter(r => !r.archived);
    const hasCur = !p.repo || repos.some(r => r.fullName === p.repo);
    const repoOpts = `<option value="">${A.st.connected ? (A.repos ? 'Pick a repo' : 'Loading your repos…') : 'Connect GitHub to see your repos'}</option>`
      + (hasCur ? '' : `<option value="${esc(p.repo)}" selected>${esc(p.repo)}</option>`)
      + repos.map(r => `<option value="${esc(r.fullName)}" ${r.fullName === p.repo ? 'selected' : ''}>${esc(r.fullName)}${r.private ? ' (private)' : ''}</option>`).join('');
    const mains = d.products.filter(x => x.type === 'main' && x.id !== p.id);
    const html = `<h2>${isNew ? 'Add addon' : 'Edit ' + esc(p.name)}</h2>
      <div class="field"><label for="e-repo">GitHub repo</label><select id="e-repo" class="wide" data-edit="repo">${repoOpts}</select>
        ${A.reposErr ? `<p class="hint bad-text">${esc(A.reposErr)}</p>` : ''}</div>
      <div class="grid2">
        <div class="field"><label for="e-name">Name in the launcher</label><input id="e-name" type="text" class="wide" data-edit-text="name" value="${esc(p.name)}" placeholder="War Diary - Compass"></div>
        <div class="field"><label for="e-icon">Icon</label><select id="e-icon" class="wide" data-edit="icon"><option value="logo" ${p.icon === 'logo' ? 'selected' : ''}>War Diary logo</option><option value="badge" ${p.icon !== 'logo' ? 'selected' : ''}>Letters: ${esc(p.short || initials(p.name) || '??')}</option></select></div>
      </div>
      <div class="grid3">
        <div class="field"><label for="e-type">Type</label><select id="e-type" class="wide" data-edit="type"><option value="main" ${p.type === 'main' ? 'selected' : ''}>Main addon</option><option value="plugin" ${p.type === 'plugin' ? 'selected' : ''}>Plugin</option></select></div>
        <div class="field"><label for="e-req">Needs</label>${p.type === 'plugin'
          ? `<select id="e-req" class="wide" data-edit="requires"><option value="">Nothing</option>${mains.map(m => `<option value="${esc(m.id)}" ${m.id === p.requires ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select>`
          : '<p class="muted" style="margin:10px 0 0">Main addons stand alone</p>'}</div>
        <div class="field"><label for="e-game">Game</label><select id="e-game" class="wide" data-edit="game">${d.games.map(g => `<option value="${esc(g.id)}" ${g.id === p.game ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}</select></div>
      </div>
      <div class="field"><label for="e-rel">Version the launcher offers</label><select id="e-rel" class="wide" data-edit-release="release">${releaseOptions(p, 'release')}</select>${releaseInfo(p, 'release')}</div>
      <div class="field"><label for="e-beta">Beta version <span class="muted small">(only for players on the beta channel)</span></label><select id="e-beta" class="wide" data-edit-release="beta">${releaseOptions(p, 'beta')}</select>${releaseInfo(p, 'beta')}</div>
      <div class="field"><label for="e-access">Who can download</label><select id="e-access" class="wide" data-edit="access">${ACCESS.map(([v, l, h]) => `<option value="${v}" ${accessOf(p) === v ? 'selected' : ''}>${l}  ·  ${h}</option>`).join('')}</select>
        <p class="hint">Beta versions are always for Testers. Set up the Discord login on the Members &amp; access page.</p></div>
      <div class="field"><label for="e-cl">Changelog link (CurseForge)</label><input id="e-cl" type="url" class="wide" data-edit-text="changelogUrl" value="${esc(p.changelogUrl || '')}" placeholder="https://www.curseforge.com/wow/addons/...">
        <p class="hint">Leave it empty until the CurseForge page is approved. Until then the launcher shows the GitHub release notes.</p></div>
      <div class="grid2">
        <div class="field"><label for="e-short">Letters on the badge</label><input id="e-short" type="text" maxlength="3" class="wide" data-edit-text="short" value="${esc(p.short || '')}" placeholder="${esc(initials(p.name) || 'CP')}"></div>
        <div class="field"><span class="field-label">Visibility</span><label class="check" style="margin-top:10px"><input type="checkbox" data-edit-check="enabled" ${p.enabled !== false ? 'checked' : ''}> Show in the launcher</label></div>
      </div>
      <div class="actions"><button class="sbtn" data-action="edit-cancel">Cancel</button><button class="pbtn" data-action="edit-save">${isNew ? `${ti('plus')} Add addon` : 'Save'}</button></div>`;
    showModal(html);
  }

  async function setEditRelease(key, tag, asset) {
    const p = A.edit.p;
    if (!tag) { p[key] = null; renderEditor(); return; }
    A.inspecting[key] = true; renderEditor();
    try { p[key] = await releaseFor(p.repo, tag, asset); }
    catch (e) { toast(e.message, true); }
    finally { A.inspecting[key] = false; renderEditor(); }
  }

  function saveProduct() {
    const { p, isNew } = A.edit;
    const d = draft();
    p.name = String(p.name || '').trim();
    if (!p.repo) return toast('Pick the GitHub repo first', true);
    if (!p.name) return toast('Give it a name for the launcher', true);
    if (!p.game) return toast('Pick which game it is for', true);
    if (!p.short) p.short = initials(p.name);
    if (p.changelogUrl && !/^https:\/\//i.test(p.changelogUrl)) return toast('The changelog link should start with https://', true);
    if (p.type !== 'plugin') p.requires = null;
    if (isNew) { p.id = uniqueId(slug(p.name), d.products); d.products.push(p); }
    else { const i = d.products.findIndex(x => x.id === p.id); d.products[i] = p; }
    A.edit = null; closeModal(); changed(); render();
    toast(isNew ? `${p.name} added` : `${p.name} saved`);
  }

  // ---------- Game versions ----------
  function pGames() {
    const d = draft();
    const rows = d.games.map((g, i) => `<tr>
      <td><span class="picon" style="display:inline-flex;width:30px;height:30px">${esc(g.badge || '?')}</span></td>
      <td><div class="pname">${esc(g.name)}</div><div class="psub">${esc(g.title || '')}</div></td>
      <td class="mono">${esc(g.folder)}</td>
      <td>${d.products.filter(p => p.game === g.id).length}</td>
      <td class="acts">
        <button class="tbtn" data-action="move" data-kind="games" data-i="${i}" data-dir="-1" aria-label="Move up" title="Move up">${ti('arrow-up')}</button>
        <button class="tbtn" data-action="move" data-kind="games" data-i="${i}" data-dir="1" aria-label="Move down" title="Move down">${ti('arrow-down')}</button>
        <button class="tbtn" data-action="edit-game" data-i="${i}">${ti('pencil')} Edit</button>
        <button class="tbtn danger" data-action="delete-game" data-i="${i}" aria-label="Delete" title="Delete">${ti('trash')}</button></td></tr>`).join('');
    return `<h1>Game versions</h1><p class="lead">Each one gets its own folder in the launcher's Directories page, and its own group on the Home screen.</p>
      <div class="card"><div class="card-head"><h2>${d.games.length} game version${d.games.length === 1 ? '' : 's'}</h2><button class="pbtn" data-action="add-game">${ti('plus')} Add game version</button></div>
      <table class="table"><thead><tr><th></th><th>Name</th><th>Folder</th><th>Addons</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }
  function openGame(i) {
    const g = i == null ? { id: '', name: '', short: '', title: '', folder: '_retail_', badge: '' } : clone(draft().games[i]);
    A.edit = { kind: 'game', i, g };
    renderGameEditor();
  }
  function renderGameEditor() {
    const { g, i } = A.edit;
    const known = KNOWN_FOLDERS.some(([f]) => f === g.folder);
    showModal(`<h2>${i == null ? 'Add game version' : 'Edit ' + esc(g.name)}</h2>
      <div class="grid2">
        <div class="field"><label for="g-name">Name</label><input id="g-name" type="text" class="wide" data-game-text="name" value="${esc(g.name)}" placeholder="WoW: Forever"></div>
        <div class="field"><label for="g-folder">Game folder</label><select id="g-folder" class="wide" data-game-sel="folder">${known ? '' : `<option value="${esc(g.folder)}" selected>${esc(g.folder)}</option>`}${KNOWN_FOLDERS.map(([f, label]) => `<option value="${f}" ${f === g.folder ? 'selected' : ''}>${f}  ·  ${label}</option>`).join('')}</select></div>
      </div>
      <div class="field"><label for="g-title">Full name</label><input id="g-title" type="text" class="wide" data-game-text="title" value="${esc(g.title)}" placeholder="World of Warcraft: Forever"><p class="hint">Shown as the heading in the launcher's Directories page.</p></div>
      <div class="grid2">
        <div class="field"><label for="g-short">Short name</label><input id="g-short" type="text" class="wide" data-game-text="short" value="${esc(g.short)}" placeholder="Forever"><p class="hint">Used on plugin tags, like "Forever plugin".</p></div>
        <div class="field"><label for="g-badge">Badge letter</label><input id="g-badge" type="text" maxlength="2" class="wide" data-game-text="badge" value="${esc(g.badge)}" placeholder="F"></div>
      </div>
      <div class="actions"><button class="sbtn" data-action="edit-cancel">Cancel</button><button class="pbtn" data-action="save-game">${i == null ? 'Add' : 'Save'}</button></div>`);
  }
  function saveGame() {
    const { g, i } = A.edit, d = draft();
    g.name = String(g.name || '').trim();
    if (!g.name) return toast('Give it a name', true);
    g.title = g.title || g.name; g.short = g.short || g.name; g.badge = (g.badge || g.name.charAt(0)).toUpperCase();
    if (i == null) { g.id = uniqueId(slug(g.name), d.games); d.games.push(g); } else d.games[i] = g;
    A.edit = null; closeModal(); changed(); render();
  }

  // ---------- News: a full page with a Markdown editor ----------
  const MD = window.WLMarkdown;
  const NEWS_KEY = 'wl.admin.newsEdit';
  function saveNewsEdit() {
    try { if (A.newsEdit) localStorage.setItem(NEWS_KEY, JSON.stringify(A.newsEdit)); else localStorage.removeItem(NEWS_KEY); } catch { /* storage off */ }
  }
  function loadNewsEdit() {
    try { const v = JSON.parse(localStorage.getItem(NEWS_KEY) || 'null'); if (v && v.n) A.newsEdit = v; } catch { /* ignore */ }
  }
  let newsSaveTimer = null;
  const persistNewsSoon = () => { clearTimeout(newsSaveTimer); newsSaveTimer = setTimeout(saveNewsEdit, 300); };

  function pNews() { return A.newsEdit ? newsEditor() : newsList(); }

  function linkSummary(n) {
    return n.link && n.link !== 'none'
      ? `${esc(n.linkLabel || 'Open')} <span class="muted">→ ${esc((LINK_TARGETS.find(t => t[0] === n.link) || [, n.link])[1])}</span>`
      : '<span class="muted">No button</span>';
  }
  function newsList() {
    const d = draft();
    const rows = d.news.map((n, i) => `<tr>
      <td><div class="pname">${esc(n.title)}</div><div class="psub news-excerpt">${esc(MD.excerpt(n.body, 170))}</div></td>
      <td class="psub nowrap">${n.date ? esc(fmtDay(n.date)) : ''}</td>
      <td class="nowrap">${linkSummary(n)}</td>
      <td class="nowrap">${i === 0 ? '<span class="tag ok">On the card</span>' : ''}</td>
      <td class="acts">
        <button class="tbtn" data-action="move" data-kind="news" data-i="${i}" data-dir="-1" aria-label="Move up" title="Move up">${ti('arrow-up')}</button>
        <button class="tbtn" data-action="move" data-kind="news" data-i="${i}" data-dir="1" aria-label="Move down" title="Move down">${ti('arrow-down')}</button>
        <button class="tbtn" data-action="edit-news" data-i="${i}">${ti('pencil')} Edit</button>
        <button class="tbtn danger" data-action="delete-news" data-i="${i}" aria-label="Delete" title="Delete">${ti('trash')}</button></td></tr>`).join('');
    return `<h1>News</h1><p class="lead">Posts show on the launcher's News page, top post first. The top post also shows as the card on the launcher's sidebar.</p>
      <div class="card"><div class="card-head"><h2>${d.news.length} post${d.news.length === 1 ? '' : 's'}</h2><button class="pbtn" data-action="add-news">${ti('plus')} New post</button></div>
      ${d.news.length ? `<table class="table"><thead><tr><th>Post</th><th>Date</th><th>Button</th><th></th><th></th></tr></thead><tbody>${rows}</tbody></table>` : '<div class="empty">No posts yet. The news card is hidden in the launcher until you add one.</div>'}</div>`;
  }

  const MD_TOOLS = [
    ['bold', 'bold', 'Bold (Ctrl+B)'], ['italic', 'italic', 'Italic (Ctrl+I)'], ['strike', 'strikethrough', 'Crossed out'], '|',
    ['h2', 'h-2', 'Big heading'], ['h3', 'h-3', 'Small heading'], '|',
    ['ul', 'list', 'Bulleted list'], ['ol', 'list-numbers', 'Numbered list'], ['quote', 'quote', 'Quote'], '|',
    ['link', 'link', 'Link (Ctrl+K)'], ['image', 'photo', 'Picture from a web address'], ['code', 'code', 'Code'], ['hr', 'separator-horizontal', 'Divider line']
  ];
  const MD_VIEWS = [['split', 'Side by side', 'layout-columns'], ['write', 'Write', 'pencil'], ['preview', 'Preview', 'eye']];

  // The editor's toolbar and layout switch, shared with the To-do page
  const mdToolbar = () => `<div class="md-toolbar" role="toolbar" aria-label="Formatting">${MD_TOOLS.map(t => t === '|' ? '<span class="sep"></span>' : `<button data-action="md" data-md="${t[0]}" title="${t[2]}" aria-label="${t[2]}">${ti(t[1])}</button>`).join('')}</div>`;
  const mdViews = () => { const view = A.mdView || 'split'; return `<div class="seg" role="group" aria-label="Editor layout">${MD_VIEWS.map(([v, l, ic]) => `<button class="${view === v ? 'on' : ''}" data-action="md-view" data-view="${v}" aria-pressed="${view === v}">${ti(ic)} ${l}</button>`).join('')}</div>`; };
  function cardPreview(n) {
    const body = MD.excerpt(n.body, 150);
    return `<div class="cp-title">${esc(n.title || 'Your title')}</div>${body ? `<div class="cp-body">${esc(body)}</div>` : ''}
      <div class="cp-actions"><span class="cp-more">Read more</span>${n.link && n.link !== 'none' ? `<span class="cp-link">${esc(n.linkLabel || 'Open')} ${ti('arrow-up-right')}</span>` : ''}</div>`;
  }
  function dirtyNote(e) { return e.dirty ? 'Not saved yet. It stays here even if you click away or close the tab.' : 'Nothing changed yet'; }

  function newsEditor() {
    const e = A.newsEdit, n = e.n, view = A.mdView || 'split';
    return `<div class="crumbs"><button class="tbtn" data-action="news-cancel">${ti('arrow-left')} All posts</button></div>
      <div class="page-head"><h1>${e.i == null ? 'New post' : 'Edit post'}</h1><span id="n-dirty" class="small ${e.dirty ? 'warn-text' : 'muted'}">${dirtyNote(e)}</span></div>
      <div class="card">
        <div class="field"><label for="n-title">Title</label><input id="n-title" type="text" class="wide big-input" data-news-text="title" value="${esc(n.title)}" placeholder="Testers wanted" maxlength="80"></div>
        <div class="field">
          <div class="md-head"><span class="field-label">Post</span>
            <div class="seg" role="group" aria-label="Editor layout">${MD_VIEWS.map(([v, l, ic]) => `<button class="${view === v ? 'on' : ''}" data-action="md-view" data-view="${v}" aria-pressed="${view === v}">${ti(ic)} ${l}</button>`).join('')}</div></div>
          <div class="md-toolbar" role="toolbar" aria-label="Formatting">${MD_TOOLS.map(t => t === '|' ? '<span class="sep"></span>' : `<button data-action="md" data-md="${t[0]}" title="${t[2]}" aria-label="${t[2]}">${ti(t[1])}</button>`).join('')}</div>
          <div class="md-editor view-${view}">
            <textarea id="n-body" data-news-text="body" spellcheck="true" aria-label="Post text" placeholder="Write your post here. Use the buttons above for bold text, headings, lists, links and pictures.">${esc(n.body)}</textarea>
            <div class="md-preview md" id="n-preview" aria-label="Preview">${MD.render(n.body) || '<p class="muted">The preview shows up here as you type.</p>'}</div>
          </div>
          <p class="hint">Write as much as you like. The preview shows how it looks in the launcher's News page.</p>
        </div>
        <div class="grid2">
          <div class="field"><label for="n-link">Button under the post</label><select id="n-link" class="wide" data-news-sel="link">${LINK_TARGETS.map(([k, l]) => `<option value="${k}" ${k === (n.link || 'none') ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
          <div class="field"><label for="n-label">Button text</label><input id="n-label" type="text" class="wide" data-news-text="linkLabel" value="${esc(n.linkLabel || '')}" maxlength="30" placeholder="Join the Discord"></div>
        </div>
        <div class="field"><span class="field-label">How the sidebar card looks</span><div class="card-preview" id="n-card">${cardPreview(n)}</div>
          <p class="hint">The card shows the start of the post. Read more opens the whole post in the launcher.</p></div>
        <div class="row-actions"><button class="pbtn" data-action="save-news">${ti('device-floppy')} ${e.i == null ? 'Add post' : 'Save post'}</button><button class="sbtn" data-action="news-cancel">Cancel</button></div>
      </div>`;
  }
  function refreshNewsBits() {
    const e = A.newsEdit; if (!e) return;
    const pv = document.getElementById('n-preview');
    if (pv) pv.innerHTML = MD.render(e.n.body) || '<p class="muted">The preview shows up here as you type.</p>';
    const card = document.getElementById('n-card'); if (card) card.innerHTML = cardPreview(e.n);
    const note = document.getElementById('n-dirty'); if (note) { note.textContent = dirtyNote(e); note.className = 'small ' + (e.dirty ? 'warn-text' : 'muted'); }
    renderNav();
  }

  function openNews(i) {
    const n = i == null ? { id: '', title: '', body: '', linkLabel: '', link: 'none' } : clone(draft().news[i]);
    A.newsEdit = { i, n, dirty: false };
    A.page = 'news'; saveNewsEdit(); render(); window.scrollTo(0, 0);
    const t = document.getElementById(i == null ? 'n-title' : 'n-body'); if (t) t.focus();
  }
  function saveNews() {
    const e = A.newsEdit, n = e.n, d = draft();
    n.title = String(n.title || '').trim();
    if (!n.title) return toast('Give the post a title', true);
    if (!String(n.body || '').trim()) return toast('Write something in the post first', true);
    const now = new Date().toISOString();
    if (e.i == null) { n.id = uniqueId('n-' + slug(n.title), d.news); n.date = now; d.news.unshift(n); }
    else {
      const idx = d.news.findIndex(x => x.id === n.id);
      n.updated = now; if (!n.date) n.date = now;
      if (idx >= 0) d.news[idx] = n; else d.news.unshift(n);
    }
    A.newsEdit = null; saveNewsEdit(); changed(); render(); window.scrollTo(0, 0);
    toast(`${e.i == null ? 'Post added' : 'Post saved'}. Publish to send it to the launchers.`);
  }
  function cancelNews() {
    const done = () => { A.newsEdit = null; saveNewsEdit(); render(); };
    if (!A.newsEdit || !A.newsEdit.dirty) return done();
    confirmBox('Throw away this post?', '<p>What you wrote in this post is deleted. Your other posts are not affected.</p>', 'Throw away', done, true);
  }

  // Formatting buttons: they work on the selected text, or add an example to type over.
  // They work in whichever Markdown editor is on the page (News, To-do).
  const mdBox = () => document.querySelector('.md-editor textarea');
  function mdInsert(text, from, to, selA, selB) {
    const ta = mdBox();
    ta.focus(); ta.setSelectionRange(from, to);
    let ok = false;
    try { ok = document.execCommand('insertText', false, text); } catch { ok = false; }
    if (!ok) { ta.setRangeText(text, from, to, 'end'); ta.dispatchEvent(new Event('input', { bubbles: true })); }
    ta.setSelectionRange(from + selA, from + selB);
  }
  function mdApply(kind) {
    const ta = mdBox(); if (!ta) return;
    const v = ta.value, s = ta.selectionStart, e = ta.selectionEnd, sel = v.slice(s, e);
    const wrap = (l, r, ph) => { const inner = sel || ph; mdInsert(l + inner + r, s, e, l.length, l.length + inner.length); };
    const ls = v.lastIndexOf('\n', s - 1) + 1;
    let le = v.indexOf('\n', e > s && v[e - 1] === '\n' ? e - 1 : e); if (le < 0) le = v.length;
    const lines = fn => { const out = v.slice(ls, le).split('\n').map(fn).join('\n'); mdInsert(out, ls, le, out.length, out.length); };
    const strip = l => l.replace(/^\s*(#{1,6}|[-*+]|\d+\.|>)\s+/, '');
    switch (kind) {
      case 'bold': return wrap('**', '**', 'bold text');
      case 'italic': return wrap('*', '*', 'italic text');
      case 'strike': return wrap('~~', '~~', 'crossed out text');
      case 'code': return sel.includes('\n') ? wrap('```\n', '\n```', '') : wrap('`', '`', 'code');
      case 'h2': case 'h3': {
        const mark = kind === 'h2' ? '## ' : '### ', ph = kind === 'h2' ? 'Heading' : 'Smaller heading';
        if (!v.slice(ls, le).trim()) return mdInsert(mark + ph, ls, le, mark.length, mark.length + ph.length);
        return lines(l => mark + strip(l));
      }
      case 'quote': return lines(l => '> ' + strip(l));
      case 'ul': return lines(l => '- ' + strip(l));
      case 'ol': { let k = 0; return lines(l => `${++k}. ` + strip(l)); }
      case 'link': { const t = sel || 'link text'; return mdInsert(`[${t}](https://)`, s, e, t.length + 3, t.length + 11); }
      case 'image': { const t = sel || 'picture description'; return mdInsert(`![${t}](https://)`, s, e, t.length + 4, t.length + 12); }
      case 'hr': { const out = (s > 0 && v[s - 1] !== '\n' ? '\n' : '') + '\n---\n\n'; return mdInsert(out, s, e, out.length, out.length); }
    }
  }
  // Pressing Enter in a list starts the next item (Enter on an empty item ends the list).
  function mdEnter(ev) {
    const ta = ev.target, v = ta.value, s = ta.selectionStart;
    if (s !== ta.selectionEnd) return;
    const ls = v.lastIndexOf('\n', s - 1) + 1, line = v.slice(ls, s);
    const m = line.match(/^(\s*)([-*+]|(\d+)\.)\s+(.*)$/);
    if (!m) return;
    ev.preventDefault();
    if (!m[4].trim()) return mdInsert('\n', ls, s, 1, 1);
    const next = m[3] ? `${Number(m[3]) + 1}.` : m[2];
    const ins = `\n${m[1]}${next} `;
    mdInsert(ins, s, s, ins.length, ins.length);
  }

  // ---------- Links ----------
  function pLinks() {
    const l = draft().links;
    return `<h1>Links</h1><p class="lead">Where the launcher's buttons go. Changes save as you leave each box.</p>
      <div class="card">${LINK_FIELDS.map(([k, label, hint]) => `<div class="field"><label for="l-${k}">${label}</label>
        <div class="inline-form"><input id="l-${k}" type="url" data-link-field="${k}" value="${esc(l[k] || '')}" placeholder="https://"><button class="sbtn" data-action="test-link" data-k="${k}">${ti('external-link')} Open</button></div>
        <p class="hint">${hint}</p></div>`).join('')}</div>`;
  }

  // ---------- Launcher ----------
  function pLauncher() {
    const st = A.st;
    return `<h1>Launcher</h1><p class="lead">How your own launcher reads the addon list, and building the launcher itself.</p>
      <div class="card"><h2>Preview on this PC</h2><p class="hint">Show your unpublished changes in the launcher on this PC before players see them. Restart the launcher or press Check for updates to see changes.</p>
        <label class="check"><input type="checkbox" data-setting="usePreview" ${st.usePreview ? 'checked' : ''}> Show my unpublished changes in my launcher</label></div>
      <div class="card"><h2>Where launchers read from</h2>
        ${st.catalogUrl ? `<p class="mono" style="word-break:break-all">${esc(st.catalogUrl)}</p><div class="row-actions"><button class="sbtn" data-action="copy" data-text="${esc(st.catalogUrl)}">${ti('copy')} Copy</button>${A.st.published ? `<a class="sbtn" href="${esc(st.catalogUrl)}" target="_blank" rel="noopener">${ti('external-link')} Open</a>` : ''}</div>` : '<p class="warn-text">Choose a repo in GitHub settings first.</p>'}
        <p class="hint" style="margin-top:12px">GitHub can take up to about 5 minutes to hand out a newly published list.</p></div>
      ${window.WLBuild ? window.WLBuild.card() : ''}`;
  }

  // ---------- GitHub settings ----------
  function pSettings() {
    const st = A.st;
    const connect = st.connected
      ? `<div class="card"><h2>GitHub account</h2><p><span class="dot ok"></span>Connected as <b>@${esc(st.login)}</b></p>
          <div class="row-actions"><button class="sbtn" data-action="disconnect">${ti('plug-off')} Disconnect</button></div></div>`
      : `<div class="card"><h2>Connect GitHub</h2>
          <ol class="setup-steps">
            <li><span>Open GitHub's token page. The right box is already ticked for you.</span><a class="sbtn" href="${TOKEN_URL}" target="_blank" rel="noopener">${ti('external-link')} Create a token</a></li>
            <li><span>Scroll down, press <b>Generate token</b>, then copy the token.</span></li>
            <li><span><input id="token" type="password" class="wide" placeholder="Paste the token here" autocomplete="off" aria-label="GitHub token"></span><button class="pbtn" data-action="connect">Connect</button></li>
          </ol>
          <p class="hint" style="margin-top:12px">The token is saved only on this PC (admin\\data\\config.json). The Admin uses it to read your releases (private repos too) and publish the addon list.</p></div>`;
    let where = '';
    if (st.connected) {
      const repos = (A.repos || []).filter(r => !r.archived);
      const branches = st.catalogRepo ? A.branches[st.catalogRepo] : null;
      where = `<div class="card"><h2>Where to publish</h2><p class="hint">Pick a <b>public</b> repo. The launcher reads catalog.json from it. A small repo just for this works best, so publishing doesn't add commits to your addon repos.</p>
        <div class="field"><label for="s-repo">Repo</label><div class="inline-form"><select id="s-repo" data-setting="catalogRepo"><option value="">${A.repos ? 'Pick a repo' : 'Loading your repos…'}</option>
          ${st.catalogRepo && !repos.some(r => r.fullName === st.catalogRepo) ? `<option value="${esc(st.catalogRepo)}" selected>${esc(st.catalogRepo)}</option>` : ''}
          ${repos.map(r => `<option value="${esc(r.fullName)}" ${r.fullName === st.catalogRepo ? 'selected' : ''} ${r.private ? 'disabled' : ''}>${esc(r.fullName)}${r.private ? '  ·  private, launchers can\'t read it' : ''}</option>`).join('')}
          </select><button class="sbtn" data-action="create-repo">${ti('plus')} Create a new repo</button></div></div>
        ${st.catalogRepo ? `<div class="grid2"><div class="field"><label for="s-branch">Branch</label><select id="s-branch" class="wide" data-setting="branch">${(branches || [st.branch]).map(b => `<option ${b === st.branch ? 'selected' : ''}>${esc(b)}</option>`).join('')}</select></div>
          <div class="field"><span class="field-label">File</span><p class="mono" style="margin:10px 0 0">${esc(st.catalogPath)}</p></div></div>` : ''}
        ${A.reposErr ? `<p class="bad-text small">${esc(A.reposErr)}</p>` : ''}</div>`;
    }
    return `<h1>GitHub settings</h1><p class="lead">The Admin reads your releases from GitHub and publishes the addon list there for the launchers.</p>${connect}${where}`;
  }
  async function loadBranches() {
    const repo = A.st.catalogRepo;
    if (!repo || A.branches[repo]) return;
    try { A.branches[repo] = await api('GET', '/api/branches?repo=' + encodeURIComponent(repo)); } catch { A.branches[repo] = [A.st.branch]; }
    if (A.page === 'settings') render();
  }

  // ---------- Modal ----------
  function showModal(html) {
    const active = document.activeElement;
    const fid = active && modal.contains(active) ? active.id : '';
    const pos = active && 'selectionStart' in active ? active.selectionStart : null;
    modal.innerHTML = html;
    overlay.hidden = false;
    if (fid) { const el = document.getElementById(fid); if (el) { el.focus(); if (pos != null && el.setSelectionRange) { try { el.setSelectionRange(pos, pos); } catch { /* not a text box */ } } } }
  }
  function closeModal() { overlay.hidden = true; modal.innerHTML = ''; A.edit = null; A.inspecting = {}; }
  let confirmFn = null;
  function confirmBox(title, bodyHtml, okLabel, fn, danger) {
    confirmFn = fn;
    showModal(`<h2>${esc(title)}</h2>${bodyHtml}<div class="actions"><button class="sbtn" data-action="edit-cancel">Cancel</button><button class="${danger ? 'dbtn' : 'pbtn'}" data-action="confirm-ok">${esc(okLabel)}</button></div>`);
  }

  // ---------- Actions ----------
  // Publishes without asking (the Tickets page uses it too). Returns true when it worked.
  async function publishNow() {
    try {
      toast('Publishing…');
      clearTimeout(saveTimer);
      await api('PUT', '/api/draft', { draft: draft() }); // the last change can still be on its way to the disk
      A.st = await api('POST', '/api/publish');
      render();
      // The bot also updates the to-do list and ticket panel it posted in Discord, and reads the ticket settings
      const extra = A.st.discord || [];
      toast(['Published. Launchers get it on their next check.', ...extra.map(x => x.text + '.')].join(' '), extra.some(x => !x.ok));
      document.dispatchEvent(new CustomEvent('wl:published'));
      return true;
    } catch (e) { toast(e.message, true); return false; }
  }
  const changeList = () => `<ul class="changes">${changes().map(([ic, t]) => `<li>${ti(ic)}<span>${esc(t)}</span></li>`).join('') || '<li>No changes, publish the same list again</li>'}</ul>`;
  async function publish() {
    confirmBox('Publish to launcher?', `${changeList()}
      <p class="hint" style="margin-top:12px">Launchers pick it up the next time they check. GitHub can take up to about 5 minutes to hand it out.</p>`, 'Publish', publishNow);
  }
  async function quickSet() {
    const v = ($('#quick') || {}).value || '';
    const [id, tag] = v.split('|');
    const p = draft().products.find(x => x.id === id);
    if (!p || !tag) return toast('Pick a release in the list first', true);
    A.busy = true; render();
    try {
      p.release = await releaseFor(p.repo, tag, p.release && p.release.tag === tag ? p.release.asset : undefined);
      changed();
      const warn = tocWarning(p.release);
      toast(warn ? `${p.name} set to ${p.release.version}, but check the warning` : `${p.name} set to ${p.release.version}`, !!warn);
    } catch (e) { toast(e.message, true); }
    A.busy = false; render();
  }
  function move(kind, i, dir) {
    const list = draft()[kind], j = i + dir;
    if (j < 0 || j >= list.length) return;
    [list[i], list[j]] = [list[j], list[i]];
    changed(); render();
  }
  async function saveSetting(key, value) {
    try {
      A.st = Object.assign(await api('POST', '/api/settings', { [key]: value }));
      if (key === 'catalogRepo') loadBranches();
      render();
      if (key === 'usePreview') toast(value ? 'Your launcher now shows unpublished changes' : 'Your launcher shows the published list again');
    } catch (e) { toast(e.message, true); render(); }
  }

  document.addEventListener('click', async e => {
    const el = e.target.closest('[data-action]');
    // Links inside the preview open in a new tab.
    const mdLink = e.target.closest('.md a');
    if (mdLink) { e.preventDefault(); const href = mdLink.getAttribute('href') || ''; if (/^https:\/\//i.test(href)) window.open(href, '_blank', 'noopener'); return; }
    // Clicking outside a box only closes simple questions, never an editor with your typing in it.
    if (!el) { if (e.target === overlay && !A.edit) closeModal(); return; }
    const a = el.dataset.action;
    switch (a) {
      case 'page':
        A.page = el.dataset.page; closeModal(); render();
        if (A.page === 'settings' && A.st.connected) { ensureRepos().then(() => { if (A.page === 'settings') render(); }); loadBranches(); }
        return;
      case 'publish': return publish();
      case 'discard':
        return confirmBox('Discard changes?', '<p>Everything goes back to what\'s published right now.</p>', 'Discard', async () => {
          try { A.st = await api('POST', '/api/discard'); render(); toast('Changes discarded'); } catch (err) { toast(err.message, true); }
        }, true);
      case 'refresh-releases':
        A.rel = {}; A.relErr = {}; render();
        await loadAllReleases(true); render(); return toast('Releases refreshed');
      case 'quick-set': return quickSet();
      case 'move': return move(el.dataset.kind, Number(el.dataset.i), Number(el.dataset.dir));
      case 'add-product': return openProduct(null);
      case 'edit-product': return openProduct(el.dataset.id);
      case 'delete-product': {
        const d = draft(), p = d.products.find(x => x.id === el.dataset.id);
        const deps = d.products.filter(x => x.requires === p.id);
        return confirmBox(`Delete ${p.name}?`, `<p>It disappears from the launcher after you publish. Players who already have it installed keep it.</p>${deps.length ? `<p class="warn-text">${deps.map(x => esc(x.name)).join(', ')} need${deps.length === 1 ? 's' : ''} it. They'll stay listed without it.</p>` : ''}`, 'Delete', () => {
          d.products = d.products.filter(x => x.id !== p.id);
          deps.forEach(x => { x.requires = null; });
          changed(); render(); toast(`${p.name} deleted`);
        }, true);
      }
      case 'edit-save': return saveProduct();
      case 'edit-cancel': return closeModal();
      case 'confirm-ok': { const f = confirmFn; confirmFn = null; closeModal(); if (f) await f(); return; }
      case 'add-game': return openGame(null);
      case 'edit-game': return openGame(Number(el.dataset.i));
      case 'save-game': return saveGame();
      case 'delete-game': {
        const d = draft(), i = Number(el.dataset.i), g = d.games[i];
        const used = d.products.filter(p => p.game === g.id);
        if (used.length) return toast(`Move or delete ${used.map(p => p.name).join(', ')} first`, true);
        if (d.games.length === 1) return toast('Keep at least one game version', true);
        return confirmBox(`Delete ${g.name}?`, '<p>Its folder disappears from the launcher\'s Directories page after you publish.</p>', 'Delete', () => { d.games.splice(i, 1); changed(); render(); }, true);
      }
      case 'add-news': return openNews(null);
      case 'edit-news': return openNews(Number(el.dataset.i));
      case 'save-news': return saveNews();
      case 'news-cancel': return cancelNews();
      case 'md': return mdApply(el.dataset.md);
      case 'md-view': A.mdView = el.dataset.view; try { localStorage.setItem('wl.admin.mdView', A.mdView); } catch { /* ignore */ } return render();
      case 'delete-news': {
        const d = draft(), i = Number(el.dataset.i);
        return confirmBox('Delete this post?', `<p>${esc(d.news[i].title)}</p>`, 'Delete', () => { d.news.splice(i, 1); changed(); render(); }, true);
      }
      case 'test-link': {
        const v = draft().links[el.dataset.k];
        if (!v) return toast('Add a link first', true);
        return window.open(v, '_blank', 'noopener');
      }
      case 'copy':
        try { await navigator.clipboard.writeText(el.dataset.text); toast('Copied'); } catch { toast('Copy failed, select the text instead', true); }
        return;
      case 'connect': {
        const token = ($('#token') || {}).value || '';
        if (!token.trim()) return toast('Paste your token first', true);
        try {
          A.st = await api('POST', '/api/connect', { token });
          toast(`Connected as @${A.st.login}`);
          render(); await ensureRepos(); loadAllReleases().then(render); render();
        } catch (err) { toast(err.message, true); }
        return;
      }
      case 'disconnect':
        return confirmBox('Disconnect GitHub?', '<p>The token is removed from this PC. You can connect again any time.</p>', 'Disconnect', async () => {
          A.st = await api('POST', '/api/disconnect'); A.repos = null; render();
        }, true);
      case 'create-repo':
        A.edit = { kind: 'repo' };
        return showModal(`<h2>Create a repo for the addon list</h2>
          <div class="field"><label for="r-name">Repo name</label><input id="r-name" type="text" class="wide" value="Warchief_Launcher" maxlength="100"><p class="hint">Created as a public repo on @${esc(A.st.login)}. Step 4 can use the same repo for launcher updates.</p></div>
          <div class="actions"><button class="sbtn" data-action="edit-cancel">Cancel</button><button class="pbtn" data-action="create-repo-go">${ti('plus')} Create</button></div>`);
      case 'create-repo-go': {
        const name = ($('#r-name') || {}).value || '';
        try {
          A.st = await api('POST', '/api/create-repo', { name: name.trim() });
          closeModal(); A.repos = null; await ensureRepos(true); loadBranches(); render();
          toast(`Created ${A.st.catalogRepo}. The launcher reads from it now.`);
        } catch (err) { toast(err.message, true); }
        return;
      }
      case 'shutdown':
        return confirmBox('Close the Admin?', '<p>Your changes are saved. Open it again with Open Admin.bat.</p>', 'Close Admin', async () => {
          try { await api('POST', '/api/shutdown'); } catch { /* already closed */ }
          document.getElementById('app').innerHTML = '<div class="page"><h1>Admin closed</h1><p class="muted">You can close this tab.</p></div>';
        });
    }
  });

  document.addEventListener('change', e => {
    const t = e.target;
    if (A.edit && A.edit.p && t.dataset.edit) {
      const p = A.edit.p, key = t.dataset.edit, v = t.value;
      if (key === 'repo') {
        p.repo = v; p.release = null; p.beta = null;
        if (A.edit.isNew && !p.name) { p.name = nameFromRepo(v); if (!A.edit.shortTouched) p.short = initials(p.name); }
        renderEditor(); if (v) loadReleases(v).then(renderEditor);
        return;
      }
      if (key === 'type') { p.type = v; if (v === 'plugin' && !p.requires) { const m = draft().products.find(x => x.type === 'main' && x.id !== p.id); p.requires = m ? m.id : null; } }
      else if (key === 'requires') p.requires = v || null;
      else p[key] = v;
      return renderEditor();
    }
    if (A.edit && A.edit.p && t.dataset.editRelease) return setEditRelease(t.dataset.editRelease, t.value);
    if (A.edit && A.edit.p && t.dataset.editAsset) { const key = t.dataset.editAsset; return setEditRelease(key, A.edit.p[key].tag, t.value); }
    if (A.edit && A.edit.p && t.dataset.editCheck) { A.edit.p[t.dataset.editCheck] = t.checked; return; }
    if (A.edit && A.edit.g && t.dataset.gameSel) { A.edit.g[t.dataset.gameSel] = t.value; return; }
    if (A.newsEdit && t.dataset.newsSel) { A.newsEdit.n[t.dataset.newsSel] = t.value; A.newsEdit.dirty = true; refreshNewsBits(); persistNewsSoon(); return; }
    if (t.dataset.setting) return saveSetting(t.dataset.setting, t.type === 'checkbox' ? t.checked : t.value);
    if (t.dataset.linkField) {
      const v = t.value.trim();
      if (v && !/^https:\/\//i.test(v)) { toast('Links need to start with https://', true); t.value = draft().links[t.dataset.linkField] || ''; return; }
      draft().links[t.dataset.linkField] = v; changed(); toast('Link saved');
    }
  });

  document.addEventListener('input', e => {
    const t = e.target;
    if (A.edit && A.edit.p && t.dataset.editText) {
      const key = t.dataset.editText;
      A.edit.p[key] = t.value;
      if (key === 'short') A.edit.shortTouched = true;
      if (key === 'name' && !A.edit.shortTouched) A.edit.p.short = initials(t.value);
    }
    if (A.edit && A.edit.g && t.dataset.gameText) A.edit.g[t.dataset.gameText] = t.value;
    if (A.newsEdit && t.dataset.newsText) {
      A.newsEdit.n[t.dataset.newsText] = t.value; A.newsEdit.dirty = true;
      refreshNewsBits(); persistNewsSoon();
    }
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && !overlay.hidden && !A.edit) closeModal();
    if (e.target.closest && e.target.closest('.md-editor')) {
      if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.altKey) mdEnter(e);
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey) {
        const k = e.key.toLowerCase(), map = { b: 'bold', i: 'italic', k: 'link' };
        if (map[k]) { e.preventDefault(); mdApply(map[k]); }
      }
    }
    if (e.key === 'Enter' && e.target.id === 'token') document.querySelector('[data-action="connect"]').click();
  });

  // Formatting buttons keep the text selected while you click them.
  document.addEventListener('mousedown', e => { if (e.target.closest('.md-toolbar button')) e.preventDefault(); });
  // Save the post you're writing if the tab is closed.
  window.addEventListener('beforeunload', saveNewsEdit);

  // Keeps the Admin running while this tab is open.
  setInterval(() => { api('POST', '/api/heartbeat').catch(() => {}); }, 20000);

  // Lets page modules (like Members & access) change the draft the same way the built-in pages do.
  window.WLAdmin = { draft, published, changed, render, toast, api, showModal, closeModal, confirmBox, publishNow, changeList, mdToolbar, mdViews, mdView: () => A.mdView || 'split', page: () => A.page };

  async function start() {
    try { A.st = await api('GET', '/api/state'); }
    catch { main.innerHTML = '<div class="page"><h1>Admin isn\'t running</h1><p class="muted">Open it again with Open Admin.bat.</p></div>'; return; }
    api('POST', '/api/heartbeat').catch(() => {});
    loadNewsEdit();
    // Back from the Discord login (Tickets page): /?page=tickets
    try {
      const want = new URLSearchParams(location.search).get('page');
      if (want && NAV.some(n => n[0] === want)) A.page = want;
      if (location.search) history.replaceState(null, '', '/');
    } catch { /* stay on Publish */ }
    try { A.mdView = localStorage.getItem('wl.admin.mdView') || 'split'; } catch { A.mdView = 'split'; }
    render();
    await loadAllReleases(); render();
    if (A.st.connected) ensureRepos();
  }
  start();
})();

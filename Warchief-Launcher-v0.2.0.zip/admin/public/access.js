// Members & access page for the Admin: Discord login for downloads. Members of the Warchief Discord get every
// addon and plugin for free; people who aren't members can look, and update the launcher, but not download.
// The settings live in the draft (draft.access) and reach the launchers and the access service with Publish.
(function () {
  'use strict';

  const W = () => window.WLAdmin;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ti = n => `<i class="ti ti-${n}" aria-hidden="true"></i>`;

  // Your Discord app and server (from the setup form).
  const APP_ID = '1564364152359616636';
  const GUILD_ID = '1564085762755002508';
  const SERVICE = 'https://warchief-access.vercel.app';
  const VERCEL_PROJECT = 'https://vercel.com/nolvus/warchief-access';
  const ROLE = { member: '1564354159191400639', tester: '1564362388260782150', guide: '1564363328686653481', mods: '1564353338105929810', admins: '1564352290221985902' };
  const KNOWN = [[ROLE.admins, 'Admins'], [ROLE.mods, 'Mods'], [ROLE.guide, 'Guide Creator'], [ROLE.tester, 'Tester'], [ROLE.member, 'Member']];
  // View Channels + Send Messages + Embed Links + Attach Files
  const BOT_INVITE = `https://discord.com/oauth2/authorize?client_id=${APP_ID}&scope=bot&permissions=52224&guild_id=${GUILD_ID}&disable_guild_select=true`;
  const GH_KEY_URL = 'https://github.com/settings/personal-access-tokens/new';
  const defaults = () => ({
    enabled: true, service: SERVICE,
    memberRoles: [ROLE.member, ROLE.tester, ROLE.guide, ROLE.mods, ROLE.admins],
    testerRoles: [ROLE.tester, ROLE.mods, ROLE.admins],
    invite: 'https://discord.gg/pCjPx2c5s6', bugReports: true
  });
  const ACCESS = [['everyone', 'Everyone', 'no login needed'], ['members', 'Discord members', 'the default'], ['testers', 'Testers only', 'members with a beta role']];

  const S = { test: null, testedFor: '', testing: false, testErr: '', roles: null, rolesFor: '', rolesErr: '', loadingRoles: false };

  // What the page shows: the saved settings, or the starting ones until you change something.
  const view = () => Object.assign(defaults(), W().draft().access || {});
  function edit(fn) {
    const d = W().draft();
    if (!d.access) d.access = defaults();
    fn(d.access);
    W().changed(); W().render();
  }
  const base = () => String(view().service || '').trim().replace(/\/+$/, '');
  const check = label => (S.test && S.testedFor === base() && S.test.checks ? S.test.checks.find(c => c.label === label) : null);
  const passed = (...labels) => labels.every(l => { const c = check(l); return c && c.ok; });

  // ---------- Page ----------
  function page() {
    const a = view();
    if (base() && S.rolesFor !== base() && !S.loadingRoles) setTimeout(loadRoles, 0);
    return `<h1>Members &amp; access</h1>
      <p class="lead">Players log in with Discord in the launcher. Members of the Warchief Discord download every addon and plugin for free. Anyone else can still look around and update the launcher, and gets a reminder to log in. Changes here reach the launchers when you Publish.</p>
      ${statusCard(a)}${setupCard(a)}${rolesCard(a)}${addonsCard()}${extrasCard(a)}`;
  }

  function statusCard(a) {
    const allGood = S.test && S.testedFor === base() && S.test.ok;
    const res = S.testing ? `<p class="hint"><span class="spin">${ti('loader-2')}</span> Testing… this asks Discord and GitHub, it takes a few seconds.</p>`
      : S.testErr ? `<p class="bad-text small">${ti('alert-triangle')} ${esc(S.testErr)}</p>`
        : S.test && S.testedFor === base() ? `<ul class="acc-checks">${S.test.checks.map(c => `<li class="${c.ok ? 'ok' : 'bad'}">${ti(c.ok ? 'circle-check' : 'circle-x')}<div><b>${esc(c.label)}</b>${c.ok ? '' : `${c.note ? ` <span class="muted">(${esc(c.note)})</span>` : ''}<div class="hint">${esc(c.fix)}</div>`}</div></li>`).join('')}</ul>
          ${allGood ? `<p class="ok-text small">${ti('check')} Everything is set up.</p>` : ''}` : '';
    return `<div class="card"><div class="card-head"><div><h2>Discord login for downloads</h2>
        <p class="hint">Players log in with Discord to download addons and plugins. Members of the Warchief Discord get everything for free.</p></div></div>
      <div class="field"><label for="acc-service">Access service address</label>
        <div class="inline-form"><input id="acc-service" type="url" data-acc-field="service" value="${esc(a.service || '')}" placeholder="${SERVICE}">
        <button class="sbtn" data-action="acc-test" ${S.testing ? 'disabled' : ''}>${ti('stethoscope')} Test</button></div>
        <p class="hint">The small login service on Vercel. Test checks every key and permission without showing any of them.</p></div>
      ${res}</div>`;
  }

  function step(done, html, buttons) {
    return `<li class="${done ? 'done' : ''}"><span>${html}</span>${buttons || ''}</li>`;
  }
  const open = (url, label) => `<a class="sbtn" href="${esc(url)}" target="_blank" rel="noopener">${ti('external-link')} ${label || 'Open'}</a>`;
  function setupCard() {
    const cb = (S.test && S.test.callbackUrl) || base() + '/api/callback';
    const env = `${VERCEL_PROJECT}/settings/environment-variables`;
    return `<div class="card"><h2>One-time setup</h2>
      <p class="hint">Keys go straight from Discord and GitHub into Vercel. Never paste them in a chat, an email or a Discord message. After you add or change a key in Vercel, open Deployments, press the three dots on the newest one, then Redeploy, so the service picks it up.</p>
      <ol class="setup-steps acc-steps">
        ${step(false, `<b>Discord: allow the login to come back.</b> In your app's OAuth2 page, under Redirects, press Add Redirect, paste <code class="mono">${esc(cb)}</code>, then Save Changes.`,
          `<button class="sbtn" data-action="copy" data-text="${esc(cb)}">${ti('copy')} Copy</button>${open(`https://discord.com/developers/applications/${APP_ID}/oauth2`)}`)}
        ${step(passed('Discord Client Secret'), `<b>Discord: the Client Secret.</b> On the same OAuth2 page, press Reset Secret and copy it. In Vercel, add it as <code class="mono env">DISCORD_CLIENT_SECRET</code> and tick Sensitive.`,
          `${open(`https://discord.com/developers/applications/${APP_ID}/oauth2`, 'Discord')}${open(env, 'Vercel')}`)}
        ${step(passed('Discord bot key'), `<b>Discord: the bot key.</b> On the Bot page, press Reset Token and copy it. In Vercel, add it as <code class="mono env">DISCORD_BOT_TOKEN</code> and tick Sensitive. While you're on the Bot page, turn off Public Bot and leave the three Privileged Gateway Intents off.`,
          `${open(`https://discord.com/developers/applications/${APP_ID}/bot`, 'Discord')}${open(env, 'Vercel')}`)}
        ${step(passed('Bot is in your Discord server', 'Bot can see the bug channel'), '<b>Add the bot to your server.</b> It asks for 4 small permissions: View Channels, Send Messages, Embed Links and Attach Files. It uses them to check who is a member and to post bug reports.', open(BOT_INVITE, 'Add bot'))}
        ${step(passed('GitHub key can read the addon downloads'), `<b>GitHub: a read-only key for the addon downloads.</b> One key covers every addon and plugin, including new ones later. Make a fine-grained token: Repository access → All repositories, Repository permissions → Contents: Read-only, and the longest expiration it offers. Copy it into Vercel as <code class="mono env">GITHUB_TOKEN</code> and tick Sensitive.`,
          `${open(GH_KEY_URL, 'GitHub')}${open(env, 'Vercel')}`)}
        ${step(S.test && S.testedFor === base() && S.test.ok, '<b>Redeploy, then press Test</b> at the top of this page. Every line should get a green tick.', open(`${VERCEL_PROJECT}/deployments`, 'Deployments'))}
        ${step(false, '<b>Make the addon repos private</b> (each repo: Settings → General → Danger Zone → Change visibility). Then, in GitHub settings here, disconnect and connect again with a new token. Its page ticks the right box for private repos.', `<button class="sbtn" data-action="page" data-page="settings">${ti('brand-github')} GitHub settings</button>`)}
        ${step(false, '<b>Publish</b>, then try "Log in with Discord" in your launcher.')}
      </ol></div>`;
  }

  function rolesCard(a) {
    const list = S.roles || KNOWN.map(([id, name]) => ({ id, name, color: '' }));
    const extra = [...new Set([...a.memberRoles, ...a.testerRoles])].filter(id => !list.some(r => r.id === id)).map(id => ({ id, name: 'Unknown role ' + id, color: '' }));
    const rows = [...list, ...extra].map(r => `<tr><td><span class="acc-role"><span class="acc-dot" style="background:${esc(r.color || '#8e88b0')}"></span>${esc(r.name)}</span></td>
      <td><label class="check"><input type="checkbox" data-acc-role="memberRoles" data-id="${esc(r.id)}" ${a.memberRoles.includes(r.id) ? 'checked' : ''}> Can download</label></td>
      <td><label class="check"><input type="checkbox" data-acc-role="testerRoles" data-id="${esc(r.id)}" ${a.testerRoles.includes(r.id) ? 'checked' : ''}> Gets betas</label></td></tr>`).join('');
    const note = S.loadingRoles ? `<span class="spin">${ti('loader-2')}</span> Loading the roles from Discord…`
      : S.rolesErr ? `${ti('info-circle')} Showing the roles from your setup form. ${esc(S.rolesErr)}` : S.roles ? 'Roles from your Discord server, top role first.' : '';
    return `<div class="card"><div class="card-head"><div><h2>Who counts as a member</h2>
        <p class="hint">Someone with any role ticked under Can download is treated like they bought the addons. Everyone else in the server (people with only the @everyone role) is a guest: they can look, but not download.</p></div>
        <button class="sbtn" data-action="acc-roles">${ti('refresh')} Reload roles</button></div>
      <table class="table acc-roles"><thead><tr><th>Discord role</th><th>Addons and plugins</th><th>Beta versions</th></tr></thead><tbody>${rows}</tbody></table>
      ${note ? `<p class="hint">${note}</p>` : ''}</div>`;
  }

  function addonsCard() {
    const d = W().draft();
    const rows = d.products.map(p => {
      const cur = ACCESS.some(x => x[0] === p.access) ? p.access : 'members';
      return `<tr><td><div class="pname">${esc(p.name)}</div><div class="psub">${p.type === 'plugin' ? 'Plugin' : 'Main addon'}</div></td>
        <td><select data-acc-product="${esc(p.id)}" aria-label="Who can download ${esc(p.name)}">${ACCESS.map(([v, l, h]) => `<option value="${v}" ${v === cur ? 'selected' : ''}>${l} (${h})</option>`).join('')}</select></td></tr>`;
    }).join('');
    return `<div class="card"><h2>Who can download each addon</h2>
      <p class="hint">Beta versions are always for the roles ticked under Gets betas. You can also change this in each addon's Edit box.</p>
      ${d.products.length ? `<table class="table"><thead><tr><th>Addon</th><th>Who can download</th></tr></thead><tbody>${rows}</tbody></table>` : '<p class="muted">No addons yet.</p>'}</div>`;
  }

  function extrasCard(a) {
    return `<div class="card"><h2>Join link and bug reports</h2>
      <div class="field"><label for="acc-invite">Discord invite</label><input id="acc-invite" type="url" class="wide" data-acc-field="invite" value="${esc(a.invite || '')}" placeholder="https://discord.gg/…">
        <p class="hint">Used by the launcher's "Join our Discord" button for people who aren't members yet.</p></div>
      <label class="check"><input type="checkbox" data-acc-flag="bugReports" ${a.bugReports !== false ? 'checked' : ''}> <span>Show <b>Help → Report a bug</b> in the launcher</span></label>
      <p class="hint">Reports are posted by the Warchief bot in #🪲bug-reports, with the player's support info attached as a file. Only logged-in people in your server can send them.</p></div>`;
  }

  // ---------- Talking to the service ----------
  async function test() {
    S.testing = true; S.testErr = ''; W().render();
    try { S.test = await W().api('POST', '/api/access/test', { service: base() }); S.testedFor = base(); }
    catch (e) { S.test = null; S.testErr = e.message; }
    S.testing = false; W().render();
    if (S.test && S.test.ok && !S.roles) loadRoles();
  }
  async function loadRoles() {
    if (!base()) return;
    S.loadingRoles = true; S.rolesFor = base();
    if (W().page() === 'access') W().render();
    try { S.roles = (await W().api('POST', '/api/access/roles', { service: base() })).roles; S.rolesErr = ''; }
    catch (e) { S.roles = null; S.rolesErr = "Couldn't load them from Discord yet (" + e.message.replace(/\.$/, '') + ').'; }
    S.loadingRoles = false;
    if (W().page() === 'access') W().render();
  }

  // ---------- Events ----------
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-action]');
    if (!el || !window.WLAdmin || W().page() !== 'access') return;
    switch (el.dataset.action) {
      case 'acc-test': return test();
      case 'acc-roles': S.roles = null; S.rolesFor = ''; return loadRoles();
    }
  });
  document.addEventListener('change', e => {
    const t = e.target;
    if (!window.WLAdmin || W().page() !== 'access' || !t.dataset) return;
    if (t.dataset.accField) {
      const k = t.dataset.accField, v = k === 'service' ? t.value.trim().replace(/\/+$/, '') : t.value.trim();
      if (k === 'service' && v && !/^https:\/\/[\w.-]+$/i.test(v)) { W().toast('The address should look like https://warchief-access.vercel.app', true); return W().render(); }
      if (k === 'invite' && v && !/^https:\/\/(discord\.gg|discord\.com\/invite)\/[\w-]+$/.test(v)) { W().toast('The invite should look like https://discord.gg/abc123', true); return W().render(); }
      edit(a => { a[k] = v; });
      if (k === 'service') { S.test = null; S.roles = null; S.rolesFor = ''; }
      return;
    }
    if (t.dataset.accRole) {
      const list = t.dataset.accRole, id = t.dataset.id;
      if (list === 'memberRoles' && !t.checked && view().memberRoles.filter(x => x !== id).length === 0) { W().toast('Keep at least one role that can download', true); return W().render(); }
      return edit(a => { a[list] = t.checked ? [...new Set([...a[list], id])] : a[list].filter(x => x !== id); });
    }
    if (t.dataset.accFlag) return edit(a => { a[t.dataset.accFlag] = t.checked; });
    if (t.dataset.accProduct) {
      const p = W().draft().products.find(x => x.id === t.dataset.accProduct);
      if (p) { p.access = t.value; W().changed(); W().render(); W().toast(`${p.name}: ${ACCESS.find(x => x[0] === t.value)[1]}`); }
    }
  });

  window.WLAccess = { page };
})();

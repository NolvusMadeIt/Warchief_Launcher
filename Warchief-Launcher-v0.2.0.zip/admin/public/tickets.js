// Tickets page for the Admin: the Discord ticket system, the way the popular ticket bots work.
// Members press a button on the ticket panel in Discord, fill in a short form and get a private channel with the
// Warchief team, with Claim and Close buttons. Closing saves a transcript in the log channel and DMs the member a copy.
// Here you read and answer tickets, and set it all up. Staff log in with Discord (only staff roles get in).
(function () {
  'use strict';

  const W = () => window.WLAdmin;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ti = n => `<i class="ti ti-${n}" aria-hidden="true"></i>`;
  const fmt = t => (t ? new Date(t).toLocaleString([], { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }) : '');

  const APP_ID = '1564364152359616636';
  const GUILD_ID = '1564085762755002508';
  // View Channels + Send Messages + Manage Channels + Embed Links + Attach Files + Read Message History
  const PERMS = 1024 + 2048 + 16 + 16384 + 32768 + 65536;
  const BOT_INVITE = `https://discord.com/oauth2/authorize?client_id=${APP_ID}&scope=bot&permissions=${PERMS}&guild_id=${GUILD_ID}&disable_guild_select=true`;
  const DEV = `https://discord.com/developers/applications/${APP_ID}`;
  const STYLES = [['primary', 'Blue'], ['secondary', 'Grey'], ['success', 'Green'], ['danger', 'Red']];
  const KNOWN_ROLES = [['1564352290221985902', 'Admins'], ['1564353338105929810', 'Mods'], ['1564363328686653481', 'Guide Creator'], ['1564362388260782150', 'Tester'], ['1564354159191400639', 'Member']];
  const discordLink = (ch, msg) => `https://discord.com/channels/${GUILD_ID}/${ch}${msg ? '/' + msg : ''}`;

  const S = {
    st: null, stErr: '', loading: false, tab: 'tickets',
    me: null, meErr: '', checkingMe: false,
    guild: null, guildErr: '', loadingGuild: false,
    status: null, statusErr: '', loadingStatus: false,
    list: null, listErr: '', loadingList: false,
    view: null, busy: '', panelChannel: ''
  };
  const later = fn => setTimeout(fn, 0);

  // ---------- Talking to the Admin server (which talks to the access service) ----------
  async function req(method, url, body) {
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json', 'X-Admin': '1' }, body: body ? JSON.stringify(body) : undefined });
    let data = {};
    try { data = await res.json(); } catch { /* empty */ }
    if (!res.ok) throw Object.assign(new Error(data.error || 'Something went wrong'), { status: res.status, need: data.need || '' });
    return data;
  }
  function loggedOut() { if (S.st) S.st.loggedIn = false; S.me = null; S.meErr = ''; S.guild = null; S.status = null; S.list = null; }
  async function call(act, extra) {
    try { return await req('POST', '/api/staff/call', { do: act, ...(extra || {}) }); }
    catch (e) { if (e.need === 'login') { loggedOut(); refresh(); } throw e; }
  }
  // Redraws the page but keeps the box you're typing in.
  function refresh() {
    if (!W() || !['tickets', 'todo'].includes(W().page())) return;
    const a = document.activeElement, id = a && a.id;
    const pos = a && typeof a.selectionStart === 'number' ? [a.selectionStart, a.selectionEnd] : null;
    W().render();
    if (id) { const el = document.getElementById(id); if (el && el !== document.activeElement) { el.focus(); if (pos && el.setSelectionRange) { try { el.setSelectionRange(pos[0], pos[1]); } catch { /* not text */ } } } }
  }
  function ensureState() {
    if (S.st || S.loading) return;
    S.loading = true;
    later(async () => {
      try { S.st = await req('GET', '/api/staff/state'); S.stErr = ''; } catch (e) { S.stErr = e.message; }
      S.loading = false; refresh();
    });
  }
  function ensureMe() {
    if (!S.st || !S.st.loggedIn || S.me || S.meErr || S.checkingMe) return;
    S.checkingMe = true;
    later(async () => {
      try { S.me = (await call('me')).user; S.meErr = ''; } catch (e) { if (e.need !== 'login') S.meErr = e.message; }
      S.checkingMe = false; refresh();
    });
  }
  function ensureGuild(force) {
    if (!S.me || S.loadingGuild || (S.guild && !force) || (S.guildErr && !force)) return;
    S.loadingGuild = true;
    later(async () => {
      try { S.guild = await call('guild'); S.guildErr = ''; } catch (e) { S.guildErr = e.message; }
      S.loadingGuild = false; refresh();
    });
  }
  function ensureStatus(force) {
    if (!S.me || S.loadingStatus || (S.status && !force) || (S.statusErr && !force)) return;
    S.loadingStatus = true;
    later(async () => {
      try { S.status = await call('status'); S.statusErr = ''; } catch (e) { S.statusErr = e.message; }
      S.loadingStatus = false; refresh();
    });
  }
  function ensureList(force) {
    if (!S.me || S.loadingList || (S.list && !force) || (S.listErr && !force)) return;
    S.loadingList = true;
    later(async () => {
      try { S.list = await call('tickets'); S.listErr = ''; } catch (e) { S.listErr = e.message; }
      S.loadingList = false; refresh();
    });
  }
  async function login() {
    try { const r = await req('POST', '/api/staff/login'); window.location.href = r.url; }
    catch (e) { W().toast(e.message, true); }
  }
  async function logout() {
    try { await req('POST', '/api/staff/logout'); } catch { /* gone anyway */ }
    loggedOut(); refresh(); W().toast('Logged out of Discord');
  }

  // ---------- Bits shared with the To-do page ----------
  const spin = text => `<p class="hint"><span class="spin">${ti('loader-2')}</span> ${esc(text)}</p>`;
  function loginCard(why) {
    if (S.stErr) return `<div class="card"><p class="bad-text">${ti('alert-triangle')} ${esc(S.stErr)}</p></div>`;
    return `<div class="card tk-login"><h2>${ti('brand-discord')} Log in with Discord</h2>
      <p class="hint">${esc(why || 'Tickets need your Discord login.')} Only the Warchief team gets in: the staff roles on this page, the server owner, and anyone with an Administrator role.</p>
      <div class="row-actions"><button class="pbtn" data-action="tk-login">${ti('brand-discord')} Log in with Discord</button></div>
      <p class="hint">Your browser opens Discord, then comes back here. The login is kept on this PC only.</p></div>`;
  }
  function whoBar() {
    if (!S.me) return '';
    return `<div class="tk-who"><img src="${esc(S.me.avatar)}" alt=""><span>Logged in as <b>${esc(S.me.name)}</b></span><button class="tbtn" data-action="tk-logout">${ti('logout')} Log out</button></div>`;
  }
  // The person is logged in and on the team: returns '' when ready, or what to show instead.
  function gate(why) {
    ensureState();
    if (!S.st) return S.stErr ? loginCard() : spin('Loading…');
    if (!S.st.loggedIn) return loginCard(why);
    ensureMe();
    if (S.meErr) return `<div class="card"><h2>Not on the Warchief team</h2><p class="bad-text">${ti('lock')} ${esc(S.meErr)}</p>
      <div class="row-actions"><button class="sbtn" data-action="tk-logout">${ti('logout')} Log out</button><button class="sbtn" data-action="tk-recheck">${ti('refresh')} Check again</button></div></div>`;
    if (!S.me) return spin('Checking your Discord account…');
    return '';
  }
  function channelSelect(id, value, placeholder, attrs) {
    const g = S.guild;
    const cats = g ? new Map(g.categories.map(c => [c.id, c.name])) : new Map();
    const list = g ? g.channels : [];
    const known = list.some(c => c.id === value);
    return `<select id="${id}" class="wide" ${attrs || ''} ${g ? '' : 'disabled'}><option value="">${esc(g ? placeholder : S.guildErr ? "Couldn't load the channels" : 'Loading the channels…')}</option>
      ${value && !known ? `<option value="${esc(value)}" selected>Channel ${esc(value)}</option>` : ''}
      ${list.map(c => `<option value="${esc(c.id)}" ${c.id === value ? 'selected' : ''}>#${esc(c.name)}${c.parent && cats.get(c.parent) ? `  ·  ${esc(cats.get(c.parent))}` : ''}</option>`).join('')}</select>`;
  }

  // ---------- Page ----------
  function page() {
    const head = `<h1>Tickets</h1><p class="lead">Members open a private ticket from the panel in your Discord. Only they and the Warchief team can see it. Answer here or in Discord.</p>`;
    const g = gate('Tickets need your Discord login.');
    if (g) return head + g;
    const tabs = `<div class="tk-tabs seg" role="tablist">${[['tickets', 'Tickets', 'ticket'], ['setup', 'Setup', 'settings']].map(([id, l, ic]) =>
      `<button class="${S.tab === id ? 'on' : ''}" role="tab" aria-selected="${S.tab === id}" data-action="tk-tab" data-tab="${id}">${ti(ic)} ${l}</button>`).join('')}</div>`;
    return head + whoBar() + tabs + (S.tab === 'setup' ? setupTab() : ticketsTab());
  }

  // ---------- Tickets tab ----------
  const person = (name, id) => (name ? esc(name) : id ? `<span class="muted">${esc(id)}</span>` : '<span class="muted">—</span>');
  function ticketsTab() {
    ensureList();
    const pub = W().published();
    const ready = pub && pub.tickets && pub.tickets.categoryId;
    const chosen = W().draft().tickets.categoryId;
    const notice = ready ? '' : chosen
      ? `<div class="card tk-notice">${ti('info-circle')}<div><b>Almost there: press Publish.</b> The ticket settings are on this page but not published, so the bot still says tickets aren't set up.</div><button class="pbtn" data-action="publish">${ti('rocket')} Publish</button></div>`
      : `<div class="card tk-notice">${ti('info-circle')}<div><b>Not set up yet.</b> Open Setup to choose where tickets go and post the ticket panel in your Discord.</div><button class="sbtn" data-action="tk-tab" data-tab="setup">${ti('settings')} Setup</button></div>`;
    if (S.loadingList && !S.list) return notice + spin('Loading tickets from Discord…');
    if (S.listErr) return notice + `<div class="card"><p class="bad-text">${ti('alert-triangle')} ${esc(S.listErr)}</p><button class="sbtn" data-action="tk-refresh">${ti('refresh')} Try again</button></div>`;
    if (!S.list) return notice;
    const open = S.list.open, closed = S.list.closed;
    const openRows = open.map(t => `<tr><td class="mono">#${String(t.n).padStart(4, '0')}</td><td>${esc(t.type)}</td><td>${person(t.openerName, t.opener)}</td>
      <td>${t.claimer ? person(t.claimerName, t.claimer) : '<span class="tag warn">Not claimed</span>'}</td><td>${esc(fmt(t.openedAt))}</td>
      <td class="acts"><button class="sbtn" data-action="tk-view" data-id="${esc(t.id)}">${ti('message-circle')} Open</button></td></tr>`).join('');
    const closedRows = closed.map(t => `<tr><td class="mono">#${String(t.n).padStart(4, '0')}</td><td>${esc(t.type)}</td><td>${person(t.openerName, t.opener)}</td>
      <td>${person(t.closerName, t.closer)}</td><td>${esc(fmt(t.closedAt))}</td><td class="tk-reason">${t.reason ? esc(t.reason) : '<span class="muted">—</span>'}</td>
      <td class="acts">${t.transcript ? `<a class="tbtn" href="${esc(t.transcript)}" target="_blank" rel="noopener">${ti('file-text')} Transcript</a>` : ''}</td></tr>`).join('');
    return notice + `<div class="card"><div class="card-head"><div><h2>Open tickets <span class="tag">${open.length}</span></h2><p class="hint">Each one is a private channel in your Discord.</p></div>
        <button class="sbtn" data-action="tk-refresh" ${S.loadingList ? 'disabled' : ''}>${S.loadingList ? `<span class="spin">${ti('loader-2')}</span>` : ti('refresh')} Refresh</button></div>
      ${open.length ? `<table class="table"><thead><tr><th>Ticket</th><th>Type</th><th>Opened by</th><th>Claimed by</th><th>Opened</th><th></th></tr></thead><tbody>${openRows}</tbody></table>` : '<p class="muted">No open tickets.</p>'}</div>
      <div class="card"><h2>Closed tickets</h2><p class="hint">The newest 50, read from the log channel. Each has the whole conversation as a transcript.</p>
      ${closed.length ? `<table class="table"><thead><tr><th>Ticket</th><th>Type</th><th>Opened by</th><th>Closed by</th><th>Closed</th><th>Reason</th><th></th></tr></thead><tbody>${closedRows}</tbody></table>` : '<p class="muted">No closed tickets yet.</p>'}</div>`;
  }

  // ---------- One ticket (a box over the page) ----------
  function msgHtml(m) {
    const tag = m.author.staff ? '<span class="tk-tag staff">Staff</span>' : m.bot ? '<span class="tk-tag">Bot</span>' : '';
    const text = s => esc(s).replace(/\n/g, '<br>');
    return `<div class="tk-msg"><img src="${esc(m.author.avatar)}" alt=""><div class="tk-msg-body"><div class="tk-msg-head"><b>${esc(m.author.name)}</b>${tag}<span class="muted small">${esc(fmt(m.at))}</span></div>
      ${m.content ? `<div class="tk-msg-text">${text(m.content)}</div>` : ''}
      ${m.embeds.map(e => `<div class="tk-embed">${e.title ? `<b>${esc(e.title)}</b>` : ''}${e.description ? `<div>${text(e.description)}</div>` : ''}${e.fields.map(f => `<div class="tk-field"><b>${esc(f.name)}</b><div>${text(f.value)}</div></div>`).join('')}</div>`).join('')}
      ${m.attachments.map(a => `<div><a href="${esc(a.url)}" target="_blank" rel="noopener">${ti('paperclip')} ${esc(a.name)}</a></div>`).join('')}</div></div>`;
  }
  function viewHtml() {
    const v = S.view;
    if (!v.ticket) return `<h2>Ticket</h2>${v.err ? `<p class="bad-text">${esc(v.err)}</p>` : spin('Loading the conversation…')}<div class="actions"><button class="sbtn" data-action="tk-close-view">Close</button></div>`;
    const t = v.ticket;
    return `<div class="tk-view"><h2>Ticket #${String(t.n).padStart(4, '0')} · ${esc(t.type)}</h2>
      <p class="hint">Opened by ${person(t.openerName, t.opener)} · ${esc(fmt(t.openedAt))} · ${t.claimer ? `Claimed by ${person(t.claimerName, t.claimer)}` : 'Not claimed yet'}
        · <a href="${esc(discordLink(t.id))}" target="_blank" rel="noopener">Open in Discord ${ti('external-link')}</a></p>
      <div class="tk-msgs" id="tk-msgs">${v.messages.length ? v.messages.map(msgHtml).join('') : '<p class="muted">No messages yet.</p>'}</div>
      <div class="field"><label for="tk-reply">Reply</label><textarea id="tk-reply" class="wide" rows="3" maxlength="4000" placeholder="Write a reply. It's posted in the ticket with your name.">${esc(v.draft || '')}</textarea></div>
      <div class="actions tk-view-actions">
        <button class="dbtn" data-action="tk-close-ask" ${S.busy ? 'disabled' : ''}>${ti('lock')} Close ticket</button>
        ${t.claimer ? '' : `<button class="sbtn" data-action="tk-claim" ${S.busy ? 'disabled' : ''}>${ti('hand-stop')} Claim</button>`}
        <button class="sbtn" data-action="tk-view-refresh" ${S.busy ? 'disabled' : ''}>${ti('refresh')} Refresh</button>
        <span class="grow"></span>
        <button class="sbtn" data-action="tk-close-view">Done</button>
        <button class="pbtn" data-action="tk-send" ${S.busy ? 'disabled' : ''}>${S.busy === 'send' ? `<span class="spin">${ti('loader-2')}</span>` : ti('send')} Send</button>
      </div></div>`;
  }
  function showView() {
    const box0 = document.getElementById('tk-reply');
    if (box0 && S.view) S.view.draft = box0.value; // keep what you're typing
    W().showModal(viewHtml());
    const box = document.getElementById('tk-msgs');
    if (box) box.scrollTop = box.scrollHeight;
  }
  // keep: refreshing the ticket that's open, so it stays on screen until the new copy arrives
  async function openView(id, keep) {
    const same = keep && S.view && S.view.id === id;
    if (!same) { S.view = { id, draft: '' }; showView(); }
    try {
      const r = await call('ticket', { id });
      if (!S.view || S.view.id !== id) return;
      const box = document.getElementById('tk-reply');
      S.view = { id, draft: box ? box.value : S.view.draft, ...r };
    } catch (e) { if (!S.view || S.view.id !== id) return; S.view.err = e.message; if (same) W().toast(e.message, true); }
    showView();
  }

  // ---------- Setup tab ----------
  const check = (ok, title, text, buttons) => `<li class="${ok ? 'ok' : 'bad'}">${ti(ok ? 'circle-check' : 'circle-x')}<div class="grow"><b>${title}</b>${ok ? '' : `<div class="hint">${text}</div>`}</div>${ok ? '' : buttons || ''}</li>`;
  const open = (url, label) => `<a class="sbtn" href="${esc(url)}" target="_blank" rel="noopener">${ti('external-link')} ${label}</a>`;
  function setupTab() {
    ensureGuild(); ensureStatus();
    const t = W().draft().tickets;
    return checklistCard() + whereCard(t) + typesCard(t) + panelCard(t);
  }
  function checklistCard() {
    const s = S.status;
    let body;
    if (S.loadingStatus && !s) body = spin('Asking Discord…');
    else if (S.statusErr) body = `<p class="bad-text small">${ti('alert-triangle')} ${esc(S.statusErr)}</p>`;
    else if (!s) body = '';
    else {
      body = `<ul class="acc-checks">
        ${check(s.botCanManage, 'The bot can make ticket channels', 'The bot needs 2 more permissions for tickets: Manage Channels and Read Message History (it keeps View Channels, Send Messages, Embed Links and Attach Files). Open the link, check the server is Warchief\'s Citadel, then press Authorize. That updates the bot\'s role.', open(BOT_INVITE, 'Update bot'))}
        ${check(s.connected, 'Discord sends ticket button presses here', `Connect points your Discord app's Interactions Endpoint URL at <code class="mono">${esc(s.wantUrl)}</code>. Discord checks the address before it saves it.`, `<button class="pbtn" data-action="tk-connect" ${S.busy ? 'disabled' : ''}>${S.busy === 'connect' ? `<span class="spin">${ti('loader-2')}</span>` : ti('plug-connected')} Connect</button>`)}
        ${check(s.messageContent, 'The bot can read ticket messages', 'Needed so transcripts include what people wrote. Connect turns it on, or switch on Message Content Intent on the Bot page.', open(DEV + '/bot', 'Bot page'))}
        ${check(s.categoryOk && !ticketsUnpublished(), 'Tickets have a category, and the bot knows it', W().draft().tickets.categoryId ? (s.categoryOk ? 'You changed the ticket settings. Press Publish so the bot uses them.' : "It's chosen below but not published yet, so the bot still says tickets aren't set up. Press Publish.") : 'Choose or make the ticket category below.', W().draft().tickets.categoryId ? `<button class="pbtn" data-action="publish">${ti('rocket')} Publish</button>` : '')}
        ${check(s.logOk, 'Closed tickets have a log channel', W().draft().tickets.logChannelId ? "It's chosen below but not published yet. Press Publish." : 'Choose or make the log channel below. Transcripts are saved there.')}
      </ul>${[s.botCanManage, s.connected, s.messageContent, s.categoryOk && !ticketsUnpublished(), s.logOk].every(Boolean) ? `<p class="ok-text small">${ti('check')} Everything is set up.</p>` : ''}`;
    }
    return `<div class="card"><div class="card-head"><div><h2>Connect the bot</h2><p class="hint">The ticket buttons are answered by the access service on Vercel, the same one that runs the Discord login.</p></div>
      <button class="sbtn" data-action="tk-status" ${S.loadingStatus ? 'disabled' : ''}>${ti('refresh')} Check again</button></div>${body}</div>`;
  }
  function whereCard(t) {
    const g = S.guild;
    const cats = g ? g.categories : [];
    const roles = g && g.roles.length ? g.roles : KNOWN_ROLES.map(([id, name]) => ({ id, name, color: '' }));
    const extra = t.staffRoles.filter(id => !roles.some(r => r.id === id)).map(id => ({ id, name: 'Unknown role ' + id, color: '' }));
    const catKnown = cats.some(c => c.id === t.categoryId);
    return `<div class="card"><h2>Where tickets go</h2>
      <div class="grid2">
        <div class="field"><label for="tk-cat">Ticket category</label>
          <select id="tk-cat" class="wide" data-tk-field="categoryId" ${g ? '' : 'disabled'}><option value="">${g ? 'Choose a category' : S.guildErr ? "Couldn't load the categories" : 'Loading…'}</option>
            ${t.categoryId && !catKnown ? `<option value="${esc(t.categoryId)}" selected>Category ${esc(t.categoryId)}</option>` : ''}
            ${cats.map(c => `<option value="${esc(c.id)}" ${c.id === t.categoryId ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
          <p class="hint">Each ticket becomes a channel in it. Make it private: only the staff roles should see it. <button class="text-btn" data-action="tk-make" data-what="category" ${S.busy ? 'disabled' : ''}>${ti('plus')} Make a private "Tickets" category</button></p></div>
        <div class="field"><label for="tk-log">Log channel</label>${channelSelect('tk-log', t.logChannelId, 'Choose a channel', 'data-tk-field="logChannelId"')}
          <p class="hint">Closed tickets and their transcripts go here. Keep it staff-only. <button class="text-btn" data-action="tk-make" data-what="log" ${S.busy ? 'disabled' : ''}>${ti('plus')} Make a staff-only "ticket-logs" channel</button></p></div>
      </div>
      <div class="field"><div class="field-label">Staff roles</div><div class="tk-roles">
        ${[...roles, ...extra].map(r => `<label class="check"><input type="checkbox" data-tk-role="${esc(r.id)}" ${t.staffRoles.includes(r.id) ? 'checked' : ''}><span class="acc-role"><span class="acc-dot" style="background:${esc(r.color || '#8e88b0')}"></span>${esc(r.name)}</span></label>`).join('')}</div>
        <p class="hint">They see every ticket, can claim and close them, and can use this page. The server owner and Administrator roles always can.</p></div>
      <label class="check"><input type="checkbox" data-tk-field="pingStaff" ${t.pingStaff ? 'checked' : ''}> <span>Ping the staff roles when a ticket opens</span></label>
      <p class="hint">A role only gets pinged if it allows it: Server Settings → Roles → the role → Allow anyone to @mention this role.</p>
      <p class="hint">${S.guildErr ? `${ti('alert-triangle')} ${esc(S.guildErr)} ` : ''}Changes here reach the bot when you Publish.</p></div>`;
  }
  function typesCard(t) {
    const emoji = (S.st && S.st.emoji) || [''];
    const types = t.types.map((y, i) => `<div class="tk-type">
        <div class="tk-type-head"><span class="tk-btnprev ${esc(y.style)}" id="tk-prev-${i}">${esc(y.emoji)} ${esc(y.label || 'Button name')}</span><span class="grow"></span>
          <button class="tbtn" data-action="tk-type-move" data-i="${i}" data-dir="-1" ${i === 0 ? 'disabled' : ''} aria-label="Move up">${ti('arrow-up')}</button>
          <button class="tbtn" data-action="tk-type-move" data-i="${i}" data-dir="1" ${i === t.types.length - 1 ? 'disabled' : ''} aria-label="Move down">${ti('arrow-down')}</button>
          <button class="tbtn danger" data-action="tk-type-del" data-i="${i}" aria-label="Delete">${ti('trash')}</button></div>
        <div class="tk-type-grid">
          <div class="field"><label for="tk-t-${i}-label">Button name</label><input id="tk-t-${i}-label" type="text" class="wide" maxlength="80" data-tk-type="${i}" data-k="label" value="${esc(y.label)}" placeholder="Get help"></div>
          <div class="field"><label for="tk-t-${i}-emoji">Emoji</label><select id="tk-t-${i}-emoji" data-tk-type="${i}" data-k="emoji">${emoji.map(e => `<option value="${esc(e)}" ${e === y.emoji ? 'selected' : ''}>${e || 'None'}</option>`).join('')}</select></div>
          <div class="field"><label for="tk-t-${i}-style">Color</label><select id="tk-t-${i}-style" data-tk-type="${i}" data-k="style">${STYLES.map(([v, l]) => `<option value="${v}" ${v === y.style ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
        </div>
        <div class="field"><label for="tk-t-${i}-welcome">Welcome message</label><textarea id="tk-t-${i}-welcome" class="wide" rows="2" maxlength="2000" data-tk-type="${i}" data-k="welcome" placeholder="Thanks for reaching out! A member of the Warchief team will be with you soon.">${esc(y.welcome)}</textarea>
          <p class="hint">Posted at the top of the ticket, with the answers to the questions below.</p></div>
        <div class="field-label">Questions in the form <span class="muted small">(up to 5; with none, the ticket opens straight away)</span></div>
        ${y.questions.map((q, j) => `<div class="tk-q">
          <input id="tk-q-${i}-${j}-label" type="text" maxlength="45" data-tk-q="${i}" data-j="${j}" data-k="label" value="${esc(q.label)}" placeholder="Question (up to 45 letters)" aria-label="Question ${j + 1}">
          <select data-tk-q="${i}" data-j="${j}" data-k="style" aria-label="Answer size"><option value="short" ${q.style === 'short' ? 'selected' : ''}>One line</option><option value="paragraph" ${q.style !== 'short' ? 'selected' : ''}>Paragraph</option></select>
          <input id="tk-q-${i}-${j}-ph" type="text" maxlength="100" data-tk-q="${i}" data-j="${j}" data-k="placeholder" value="${esc(q.placeholder)}" placeholder="Example answer (optional)" aria-label="Example answer">
          <label class="check"><input type="checkbox" data-tk-q="${i}" data-j="${j}" data-k="required" ${q.required ? 'checked' : ''}> Required</label>
          <button class="tbtn danger" data-action="tk-q-del" data-i="${i}" data-j="${j}" aria-label="Remove question">${ti('x')}</button></div>`).join('')}
        ${y.questions.length < 5 ? `<button class="text-btn" data-action="tk-q-add" data-i="${i}">${ti('plus')} Add a question</button>` : ''}
      </div>`).join('');
    return `<div class="card"><div class="card-head"><div><h2>Ticket buttons</h2><p class="hint">One button per kind of ticket on the panel. Each can ask a few questions in a form before the ticket opens.</p></div>
      ${t.types.length < 10 ? `<button class="sbtn" data-action="tk-type-add">${ti('plus')} Add a button</button>` : ''}</div>
      ${types || '<p class="muted">No buttons yet. Add one so members can open tickets.</p>'}</div>`;
  }
  // The settings the way Publish sends them (only finished buttons), to see if the published ones are different.
  const pubForm = t => JSON.stringify({ ...t, types: t.types.filter(y => y.label.trim()).map(y => ({ ...y, label: y.label.trim(), questions: y.questions.filter(q => q.label.trim()) })) });
  function ticketsUnpublished() { const pub = W().published(); return !pub || !pub.tickets || pubForm(W().draft().tickets) !== JSON.stringify(pub.tickets); }
  // A channel members can't see: the log channel, or anything inside the private ticket category.
  function staffOnly(id) {
    const t = T();
    if (!id) return false;
    if (id === t.logChannelId) return true;
    const c = S.guild && S.guild.channels.find(x => x.id === id);
    return !!(c && t.categoryId && c.parent === t.categoryId);
  }
  // A channel members can see, for a first panel: one named like support or help.
  function suggestChannel() {
    const list = S.guild ? S.guild.channels.filter(c => !staffOnly(c.id)) : [];
    const c = list.find(x => /support|help|ticket/i.test(x.name));
    return c ? c.id : '';
  }
  function panelCard(t) {
    const posted = S.st && S.st.posts && S.st.posts.panel;
    const ch = S.panelChannel || (posted && !staffOnly(posted.channelId) ? posted.channelId : '') || suggestChannel();
    const unpublished = ticketsUnpublished();
    const same = posted && posted.channelId === ch;
    const hidden = staffOnly(ch);
    const name = id => { const c = S.guild && S.guild.channels.find(x => x.id === id); return c ? '#' + c.name : 'that channel'; };
    const label = `${unpublished ? 'Publish and ' : ''}${same ? 'update the panel' : posted ? 'move the panel here' : 'post the panel'}`;
    return `<div class="card"><h2>Ticket panel</h2><p class="hint">The message in your Discord with the ticket buttons. Put it in a channel everyone can see, like #support.</p>
      <div class="field"><label for="tk-p-title">Title</label><input id="tk-p-title" type="text" class="wide" maxlength="256" data-tk-panel="title" value="${esc(t.panel.title)}"></div>
      <div class="field"><label for="tk-p-desc">Text</label><textarea id="tk-p-desc" class="wide" rows="3" maxlength="2000" data-tk-panel="description">${esc(t.panel.description)}</textarea></div>
      <div class="field"><label for="tk-panel-ch">Channel</label>${channelSelect('tk-panel-ch', ch, 'Choose a channel everyone can see')}</div>
      ${posted && staffOnly(posted.channelId) ? `<p class="bad-text small">${ti('alert-triangle')} The panel is in ${esc(name(posted.channelId))}, which only staff can see, so members can't open tickets. Pick a channel everyone can see and press the button below. The old panel is taken away.</p>` : ''}
      ${hidden ? `<p class="bad-text small">${ti('lock')} ${esc(name(ch))} is staff-only (it's the log channel or inside the ticket category). Members wouldn't see the panel there.</p>` : ''}
      ${unpublished && !hidden ? `<p class="hint">${ti('info-circle')} The ticket settings aren't published yet. The button publishes them first, so the panel's buttons work straight away.</p>` : ''}
      <div class="row-actions"><button class="pbtn" data-action="tk-panel" ${S.busy || hidden || !ch ? 'disabled' : ''}>${S.busy === 'panel' ? `<span class="spin">${ti('loader-2')}</span>` : ti('send')} ${label.charAt(0).toUpperCase() + label.slice(1)}</button>
        ${posted ? `<a class="sbtn" href="${esc(discordLink(posted.channelId, posted.messageId))}" target="_blank" rel="noopener">${ti('external-link')} See it in Discord</a>` : ''}</div>
      ${posted && !staffOnly(posted.channelId) ? `<p class="hint">Posted in ${esc(name(posted.channelId))}, ${esc(fmt(posted.at))}. Publish updates it by itself when you change the buttons.</p>` : ''}</div>`;
  }

  // ---------- Changing the draft ----------
  const T = () => W().draft().tickets;
  function edit(fn, redraw) { fn(T()); W().changed(); if (redraw) refresh(); }
  const newId = () => 't' + Math.random().toString(36).slice(2, 8);

  async function make(what) {
    S.busy = 'make'; refresh();
    try {
      await req('PUT', '/api/draft', { draft: W().draft() });
      const r = await call('setup', { body: { [what]: true, staffRoles: T().staffRoles } });
      edit(t => { if (r.categoryId) t.categoryId = r.categoryId; if (r.logChannelId) t.logChannelId = r.logChannelId; });
      W().toast(what === 'category' ? 'Made the private Tickets category. Publish to start using it.' : 'Made the ticket-logs channel. Publish to start using it.');
      S.guild = null; ensureGuild(true); ensureStatus(true);
    } catch (e) { W().toast(e.message, true); }
    S.busy = ''; refresh();
  }
  async function connect() {
    S.busy = 'connect'; refresh();
    try {
      const r = await call('connect');
      W().toast(r.note ? 'Connected. ' + r.note : 'Connected. Discord now sends ticket button presses to the access service.', !!r.note);
      ensureStatus(true);
    }
    catch (e) { W().toast(e.message, true); }
    S.busy = ''; refresh();
  }
  async function postPanel(published) {
    const ch = (document.getElementById('tk-panel-ch') || {}).value || S.panelChannel || '';
    if (!ch) return W().toast('Choose a channel for the panel first', true);
    if (staffOnly(ch)) return W().toast("Members can't see that channel. Pick one everyone can see.", true);
    // Not published yet: publish first (after showing what goes out), so the buttons work straight away
    if (ticketsUnpublished() && !published) {
      S.panelChannel = ch;
      return W().confirmBox('Publish, then post the panel?', `${W().changeList()}<p class="hint" style="margin-top:12px">The bot needs the published ticket settings for the buttons to work.</p>`, 'Publish and post', async () => {
        if (await W().publishNow()) await postPanel(true);
      });
    }
    S.busy = 'panel'; refresh();
    try {
      await req('PUT', '/api/draft', { draft: W().draft() }); // so the bot posts exactly what's on the page
      const r = await call('panel', { channelId: ch });
      S.st = await req('GET', '/api/staff/state');
      W().toast(r.updated ? 'Ticket panel updated in Discord' : r.removedOld ? 'Ticket panel moved. The old one is gone.' : 'Ticket panel posted in Discord');
    } catch (e) { W().toast(e.message, true); }
    S.busy = ''; refresh();
  }
  async function send() {
    const box = document.getElementById('tk-reply');
    const text = box ? box.value.trim() : '';
    if (!text) return W().toast('Write a reply first', true);
    S.busy = 'send'; showView();
    try {
      await call('reply', { body: { id: S.view.id, text } });
      S.busy = ''; const b = document.getElementById('tk-reply'); if (b) b.value = ''; S.view.draft = '';
      await openView(S.view.id, true); W().toast('Reply sent');
    }
    catch (e) { S.busy = ''; showView(); W().toast(e.message, true); }
  }
  async function claim() {
    S.busy = 'claim'; showView();
    try {
      const r = await call('claim', { body: { id: S.view.id } });
      S.busy = '';
      W().toast(r.taken ? 'Someone else already claimed it' : r.already ? 'You already claimed it' : 'You claimed this ticket');
      await openView(S.view.id, true); ensureList(true);
    } catch (e) { S.busy = ''; showView(); W().toast(e.message, true); }
  }
  function askClose() {
    const v = S.view;
    if (v) v.draft = (document.getElementById('tk-reply') || {}).value || '';
    W().showModal(`<h2>Close ticket #${String(v.ticket.n).padStart(4, '0')}?</h2>
      <p>A transcript of the whole conversation is saved in the log channel and sent to the member by DM. Then the ticket channel is deleted.</p>
      <div class="field"><label for="tk-reason">Reason <span class="muted small">(optional, the member sees it)</span></label><input id="tk-reason" type="text" class="wide" maxlength="1000" placeholder="Sorted, thanks for reaching out!"></div>
      <div class="actions"><button class="sbtn" data-action="tk-close-back">Back</button><button class="dbtn" data-action="tk-close-go">${ti('lock')} Close ticket</button></div>`);
  }
  async function doClose() {
    const reason = ((document.getElementById('tk-reason') || {}).value || '').trim();
    const id = S.view.id;
    W().showModal(`<h2>Closing…</h2>${spin('Saving the transcript, then deleting the ticket channel.')}`);
    try { await call('close', { body: { id, reason } }); S.view = null; W().closeModal(); W().toast('Ticket closed. The transcript is in the log channel.'); }
    catch (e) { showView(); W().toast(e.message, true); }
    ensureList(true);
  }

  // ---------- Events ----------
  const mine = () => window.WLAdmin && W().page() === 'tickets';
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-action]');
    if (!el || !window.WLAdmin) return;
    const a = el.dataset.action;
    if (!a.startsWith('tk-')) return;
    const i = Number(el.dataset.i), j = Number(el.dataset.j);
    switch (a) {
      case 'tk-login': return login();
      case 'tk-logout': return logout();
      case 'tk-recheck': S.meErr = ''; S.me = null; return refresh();
      case 'tk-tab': S.tab = el.dataset.tab; return refresh();
      case 'tk-refresh': return ensureList(true), refresh();
      case 'tk-status': return ensureStatus(true), ensureGuild(true), refresh();
      case 'tk-view': return openView(el.dataset.id);
      case 'tk-view-refresh': return openView(S.view.id, true);
      case 'tk-close-view': S.view = null; return W().closeModal();
      case 'tk-send': return send();
      case 'tk-claim': return claim();
      case 'tk-close-ask': return askClose();
      case 'tk-close-back': return showView();
      case 'tk-close-go': return doClose();
      case 'tk-connect': return connect();
      case 'tk-make': return make(el.dataset.what);
      case 'tk-panel': return postPanel();
      case 'tk-type-add': return edit(t => { t.types.push({ id: newId(), label: '', emoji: '', style: 'secondary', welcome: '', questions: [] }); }, true);
      case 'tk-type-del': {
        const y = T().types[i];
        return W().confirmBox(`Delete "${y.label || 'this button'}"?`, '<p>It disappears from the ticket panel after you Publish. Open tickets of this kind stay open.</p>', 'Delete', () => { edit(t => { t.types.splice(i, 1); }, true); }, true);
      }
      case 'tk-type-move': return edit(t => { const k = i + Number(el.dataset.dir); if (k >= 0 && k < t.types.length) [t.types[i], t.types[k]] = [t.types[k], t.types[i]]; }, true);
      case 'tk-q-add': return edit(t => { if (t.types[i].questions.length < 5) t.types[i].questions.push({ label: '', style: 'paragraph', required: true, placeholder: '' }); }, true);
      case 'tk-q-del': return edit(t => { t.types[i].questions.splice(j, 1); }, true);
    }
  });
  document.addEventListener('change', e => {
    const x = e.target;
    if (!mine() || !x.dataset) return;
    if (x.id === 'tk-panel-ch') { S.panelChannel = x.value; return refresh(); }
    if (x.dataset.tkField) return edit(t => { t[x.dataset.tkField] = x.type === 'checkbox' ? x.checked : x.value; }, true);
    if (x.dataset.tkRole) {
      const id = x.dataset.tkRole;
      if (!x.checked && T().staffRoles.filter(r => r !== id).length === 0) { W().toast('Keep at least one staff role', true); return refresh(); }
      return edit(t => { t.staffRoles = x.checked ? [...new Set([...t.staffRoles, id])] : t.staffRoles.filter(r => r !== id); }, true);
    }
    if (x.dataset.tkType && x.tagName === 'SELECT') return edit(t => { t.types[Number(x.dataset.tkType)][x.dataset.k] = x.value; }, true);
    if (x.dataset.tkQ && (x.tagName === 'SELECT' || x.type === 'checkbox')) return edit(t => { t.types[Number(x.dataset.tkQ)].questions[Number(x.dataset.j)][x.dataset.k] = x.type === 'checkbox' ? x.checked : x.value; });
  });
  document.addEventListener('input', e => {
    const x = e.target;
    if (!mine() || !x.dataset) return;
    if (x.dataset.tkType && x.tagName !== 'SELECT') {
      const i = Number(x.dataset.tkType);
      edit(t => { t.types[i][x.dataset.k] = x.value; });
      if (x.dataset.k === 'label') { const p = document.getElementById('tk-prev-' + i); if (p) p.textContent = `${T().types[i].emoji} ${x.value || 'Button name'}`; }
      return;
    }
    if (x.dataset.tkQ && x.type === 'text') return edit(t => { t.types[Number(x.dataset.tkQ)].questions[Number(x.dataset.j)][x.dataset.k] = x.value; });
    if (x.dataset.tkPanel) return edit(t => { t.panel[x.dataset.tkPanel] = x.value; });
  });

  // After any Publish: the checklist and the list ask the bot again
  document.addEventListener('wl:published', () => { if (S.me) { ensureStatus(true); ensureList(true); req('GET', '/api/staff/state').then(st => { S.st = st; refresh(); }).catch(() => {}); } });

  // For the To-do page
  window.WLStaff = {
    gate, whoBar, channelSelect, ensureGuild, req, refresh,
    state: () => S.st, setState: st => { S.st = st; },
    guildError: () => S.guildErr
  };
  window.WLTickets = { page };
})();

// "Build the launcher" on the Admin's Launcher page: make the Setup.exe, and send launcher updates to players.
// admin.js only shows WLBuild.card() in place of the old step 4 placeholder; this file does the rest.
(function () {
  'use strict';

  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ti = n => `<i class="ti ti-${n}" aria-hidden="true"></i>`;
  const $id = id => document.getElementById(id);
  const fmtDay = t => t ? new Date(t).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : '';
  const parseV = v => String(v || '').replace(/^v/i, '').split('.').slice(0, 3).map(x => parseInt(x, 10) || 0);
  const bumpV = (v, k) => { const [a, b, c] = parseV(v); return k === 'major' ? `${a + 1}.0.0` : k === 'minor' ? `${a}.${b + 1}.0` : `${a}.${b}.${c + 1}`; };
  const cmpV = (a, b) => { const x = parseV(a), y = parseV(b); for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1; return 0; };

  const W = { st: null, latest: undefined, latestErr: '', bump: 'patch', notes: '', showLog: false, loading: false };
  let poll = null;

  async function api(method, url, body) {
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json', 'X-Admin': '1' }, body: body ? JSON.stringify(body) : undefined });
    let data = {};
    try { data = await res.json(); } catch { /* empty */ }
    if (!res.ok) throw new Error(data.error || 'Something went wrong');
    return data;
  }
  function toast(msg, bad) {
    const el = $id('toast'); if (!el) return;
    el.textContent = msg; el.classList.toggle('bad', !!bad); el.hidden = false;
    clearTimeout(toast.t); toast.t = setTimeout(() => { el.hidden = true; }, bad ? 7000 : 3800);
  }
  function showModal(html) { $id('modal').innerHTML = html; $id('overlay').hidden = false; }
  function closeModal() { $id('overlay').hidden = true; $id('modal').innerHTML = ''; }

  // ---------- Loading ----------
  async function load() {
    if (W.loading) return;
    W.loading = true;
    try { W.st = await api('GET', '/api/build/state'); } catch { W.st = null; }
    W.loading = false;
    draw();
    if (W.st && W.st.build.running) startPoll();
    if (W.st && W.st.repo && W.latest === undefined) loadLatest();
  }
  async function loadLatest() {
    try { const r = await api('GET', '/api/build/latest'); W.latest = r.latest; W.shareUrl = r.shareUrl; W.latestErr = ''; }
    catch (e) { W.latest = null; W.latestErr = e.message; }
    draw();
  }
  function startPoll() {
    if (poll) return;
    poll = setInterval(async () => {
      if (!$id('wb-root')) { clearInterval(poll); poll = null; return; } // left the Launcher page
      try { W.st = await api('GET', '/api/build/state'); } catch { return; }
      if (!W.st.build.running) {
        clearInterval(poll); poll = null;
        if (W.st.build.ok && W.st.build.kind === 'publish') { W.latest = undefined; loadLatest(); }
        toast(W.st.build.ok ? (W.st.build.kind === 'publish' ? `Launcher ${W.st.build.version} is out. Players get the green update arrow.` : 'Test Setup.exe is ready') : 'The build stopped. See the box for why.', !W.st.build.ok);
      }
      draw();
    }, 1500);
  }
  function draw() {
    const root = $id('wb-root'); if (!root) return;
    const logEl = $id('wb-log');
    const atBottom = !logEl || logEl.scrollTop + logEl.clientHeight >= logEl.scrollHeight - 20;
    const notes = $id('wb-notes'), hadFocus = notes && document.activeElement === notes;
    root.innerHTML = inner();
    const l2 = $id('wb-log'); if (l2 && atBottom) l2.scrollTop = l2.scrollHeight;
    if (hadFocus) { const n = $id('wb-notes'); if (n) { n.focus(); n.setSelectionRange(n.value.length, n.value.length); } }
  }

  // ---------- The card ----------
  function card() {
    if (!W.st) load();
    else if (W.st.build.running) startPoll();
    return `<div class="card" id="wb-root">${inner()}</div>`;
  }
  function inner() {
    const st = W.st;
    if (!st) return '<h2>Build the launcher</h2><p class="muted">Loading…</p>';
    const b = st.build, running = b.running;
    const head = `<div class="card-head"><div><h2>Build the launcher</h2>
        <p class="hint">Makes the Setup.exe players install once. After that, each update you send here shows the green update arrow in their launcher, and it updates by itself.</p></div></div>`;
    const latest = W.latest === undefined && st.repo ? '<span class="muted">checking…</span>'
      : W.latestErr ? `<span class="warn-text">${esc(W.latestErr)}</span>`
        : W.latest ? `v${esc(W.latest.version)} <span class="muted">· ${esc(fmtDay(W.latest.publishedAt))}${W.latest.hasSetup ? ` · ${W.latest.downloads} download${W.latest.downloads === 1 ? '' : 's'}` : ''}</span> · <a href="${esc(W.latest.url)}" target="_blank" rel="noopener">View on GitHub ${ti('external-link')}</a>`
          : '<span class="muted">Nothing sent yet</span>';
    const status = `<div class="status-list wb-status">
        <span class="k">This launcher</span><span>v${esc(st.version)}</span><span></span>
        <span class="k">Players have</span><span>${st.repo ? latest : '<span class="muted">Choose where to publish first</span>'}</span><span></span>
        ${W.latest && W.latest.hasSetup && W.shareUrl ? `<span class="k">Install link</span><span class="mono wb-link">${esc(W.shareUrl)}</span><span><button class="tbtn" data-wb="copy" data-text="${esc(W.shareUrl)}">${ti('copy')} Copy</button></span>` : ''}
      </div>`;
    const progress = (running || b.ok !== null) ? progressHtml(b) : '';
    if (running) return head + status + progress;
    const setup = !st.connected || !st.repo
      ? `<div class="wb-note">${ti('info-circle')}<div>To send updates to players, ${!st.connected ? 'connect GitHub' : 'choose the repo to publish to'} first. You can still make a test Setup.exe.</div><button class="sbtn" data-action="page" data-page="settings">${ti('brand-github')} GitHub settings</button></div>` : '';
    const base = W.latest && cmpV(W.latest.version, st.version) > 0 ? W.latest.version : st.version;
    const opts = [['patch', 'Small fix'], ['minor', 'New features'], ['major', 'Big release']];
    const send = `<div class="wb-section"><h3>Send an update to players</h3>
        <div class="grid2">
          <div class="field"><label for="wb-bump">What kind of update?</label><select id="wb-bump" class="wide" data-wb-field="bump">
            ${opts.map(([k, l]) => `<option value="${k}" ${W.bump === k ? 'selected' : ''}>${l} (${esc(base)} → ${esc(bumpV(base, k))})</option>`).join('')}</select></div>
          <div class="field"><span class="field-label">Players get</span><p class="wb-big">v${esc(bumpV(base, W.bump))}</p></div>
        </div>
        <div class="field"><label for="wb-notes">What's new <span class="muted small">(optional, shown on the GitHub release)</span></label>
          <textarea id="wb-notes" data-wb-field="notes" rows="4" placeholder="- New tray menu&#10;- Fixed …">${esc(W.notes)}</textarea></div>
        <div class="row-actions"><button class="pbtn" data-wb="publish" ${st.connected && st.repo ? '' : 'disabled'}>${ti('rocket')} Build and send to players</button></div>
        <p class="hint">${W.latest ? 'Takes a few minutes.' : 'The first build downloads the build tools and Electron (about 200 MB) and can take 5 to 10 minutes.'} Keep this page open until it's done.</p>
      </div>`;
    const test = `<div class="wb-section"><h3>Try it on this PC first</h3>
        <p class="hint">Makes ${esc(st.setupName)} in the launcher's dist folder without sending anything or changing the version.</p>
        <div class="row-actions"><button class="sbtn" data-wb="test">${ti('hammer')} Make a test Setup.exe</button>
          ${st.hasSetup ? `<button class="sbtn" data-wb="open-folder">${ti('folder')} Open the dist folder</button>` : ''}</div></div>`;
    return head + status + progress + setup + send + test;
  }
  function progressHtml(b) {
    const icon = { waiting: 'circle', active: 'loader-2', done: 'circle-check', failed: 'circle-x' };
    const secs = Math.max(0, Math.round(((b.ended || Date.now()) - b.started) / 1000));
    const time = secs >= 60 ? `${Math.floor(secs / 60)} min ${secs % 60} s` : `${secs} s`;
    const title = b.running ? (b.kind === 'publish' ? `Building and sending v${esc(b.version)}…` : 'Making a test Setup.exe…')
      : b.ok ? (b.kind === 'publish' ? `v${esc(b.version)} is out` : 'Test Setup.exe is ready') : 'The build stopped';
    const result = b.running ? '' : b.ok
      ? (b.kind === 'publish'
        ? `<div class="wb-ok">${ti('circle-check')}<div><b>Players get the green update arrow</b> the next time their launcher checks (when it starts, and every 30 minutes).${b.releaseUrl ? ` <a href="${esc(b.releaseUrl)}" target="_blank" rel="noopener">See the release ${ti('external-link')}</a>` : ''}</div></div>`
        : `<div class="wb-ok">${ti('circle-check')}<div><b>Warchief-Launcher-Setup.exe is in the dist folder.</b> Double-click it to install and try the launcher. Windows may say it "protected your PC" because the file isn't signed: click More info, then Run anyway.</div><button class="sbtn" data-wb="open-folder">${ti('folder')} Open the dist folder</button></div>`)
      : `<div class="wb-bad">${ti('alert-triangle')}<div><b>Nothing was sent to players.</b> ${esc(b.error)}</div></div>`;
    return `<div class="wb-progress"><div class="wb-ptitle"><b>${title}</b><span class="muted small">${time}</span></div>
        <ol class="wb-steps">${b.steps.map(s => `<li class="${s.state}">${ti(icon[s.state] || 'circle')}<span>${esc(s.name)}${s.note && s.state === 'active' ? ` <span class="muted small">· ${esc(s.note)}</span>` : ''}</span></li>`).join('')}</ol>
        ${b.fixedSymlink ? `<p class="hint">${ti('tool')} Fixed a known Windows problem in the build tool by itself and tried again.</p>` : ''}
        ${result}
        <button class="tbtn" data-wb="log">${ti(W.showLog ? 'chevron-up' : 'chevron-down')} ${W.showLog ? 'Hide' : 'Show'} details</button>
        ${W.showLog ? `<pre class="wb-log" id="wb-log">${esc(b.log.join('\n')) || 'Nothing yet.'}</pre>` : ''}</div>`;
  }

  // ---------- Actions ----------
  async function start(kind) {
    try {
      const r = await api('POST', '/api/build/start', { kind, bump: W.bump, notes: kind === 'publish' ? W.notes : '' });
      W.st.build = r.build; W.showLog = false;
      if (kind === 'publish') W.notes = '';
      draw(); startPoll();
    } catch (e) { toast(e.message, true); }
  }
  document.addEventListener('click', async e => {
    const el = e.target.closest('[data-wb]'); if (!el) return;
    const a = el.dataset.wb;
    if (a === 'publish') {
      const base = W.latest && cmpV(W.latest.version, W.st.version) > 0 ? W.latest.version : W.st.version;
      const v = bumpV(base, W.bump);
      showModal(`<h2>Send launcher v${esc(v)} to players?</h2>
        <p>The launcher is built into a new Setup.exe and put on GitHub as v${esc(v)}. Every installed launcher then shows the green update arrow and updates when it's clicked.</p>
        <p class="hint">Keep this page open until it says it's done.</p>
        <div class="actions"><button class="sbtn" data-wb="cancel">Cancel</button><button class="pbtn" data-wb="publish-go">${'Build and send'}</button></div>`);
      return;
    }
    if (a === 'publish-go') { closeModal(); return start('publish'); }
    if (a === 'cancel') return closeModal();
    if (a === 'test') return start('test');
    if (a === 'open-folder') { try { await api('POST', '/api/build/open-folder'); } catch (err) { toast(err.message, true); } return; }
    if (a === 'log') { W.showLog = !W.showLog; return draw(); }
    if (a === 'copy') { try { await navigator.clipboard.writeText(el.dataset.text); toast('Copied. Send it to players to install the launcher.'); } catch { toast('Copy failed, select the link instead', true); } }
  });
  document.addEventListener('change', e => {
    const k = e.target.dataset && e.target.dataset.wbField;
    if (k === 'bump') { W.bump = e.target.value; draw(); }
  });
  document.addEventListener('input', e => {
    const k = e.target.dataset && e.target.dataset.wbField;
    if (k === 'notes') W.notes = e.target.value;
  });

  window.WLBuild = { card };
})();

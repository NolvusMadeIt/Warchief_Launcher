// Draws the To-do board as a picture (PNG) for Discord: the same columns and cards players see in the launcher,
// read-only. Drawn here in the Admin page, so it uses the same fonts and the system's emoji.
(function () {
  'use strict';

  const COLOR = { gray: '#8b949e', blue: '#4493f8', green: '#3fb950', yellow: '#d29922', orange: '#db6d28', red: '#f85149', pink: '#db61a2', purple: '#a371f7' };
  const P = { bg: '#0d0b19', panel: '#161230', card: '#1e1942', cardLine: '#342d63', line: '#2c2650', tx: '#ece8fb', strong: '#ffffff', muted: '#9a93bf', gold: '#f2c75c', top: '#8f74ff', chip: '#2a2452', chipTx: '#cfc8f2' };
  const FB = "Barlow, 'Segoe UI', 'Segoe UI Emoji', 'Apple Color Emoji', sans-serif";
  const FH = "Cinzel, Georgia, 'Segoe UI Emoji', serif";
  const CW = 300, GAP = 16, PAD = 32, CARD_PAD = 12;

  function wrap(ctx, text, max) {
    const out = [];
    for (const para of String(text || '').split('\n')) {
      let line = '';
      for (const word of para.split(/\s+/).filter(Boolean)) {
        const tryLine = line ? line + ' ' + word : word;
        if (ctx.measureText(tryLine).width <= max) { line = tryLine; continue; }
        if (line) out.push(line);
        // a single word longer than the line is cut into pieces
        let w = word;
        while (ctx.measureText(w).width > max) {
          let k = w.length - 1;
          while (k > 1 && ctx.measureText(w.slice(0, k)).width > max) k--;
          out.push(w.slice(0, k)); w = w.slice(k);
        }
        line = w;
      }
      out.push(line);
    }
    while (out.length && !out[out.length - 1]) out.pop();
    return out;
  }
  function round(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  const fmt = d => new Date(d).toLocaleDateString([], { month: 'long', day: 'numeric', year: 'numeric' });

  // board: { title, columns: [{ name, emoji, color, cards: [{ title, text, addon }] }] }; addonName(id) -> label
  async function draw(board, addonName) {
    try { await Promise.all([document.fonts.load(`500 16px ${FB}`), document.fonts.load(`400 14px ${FB}`), document.fonts.load(`500 30px ${FH}`)]); } catch { /* system fonts */ }
    try { await document.fonts.ready; } catch { /* fine */ }
    const cols = board.columns || [];
    const n = Math.max(1, cols.length);
    const width = Math.max(720, PAD * 2 + n * CW + (n - 1) * GAP);
    const m = document.createElement('canvas').getContext('2d');
    const inner = CW - CARD_PAD * 2 - 12;

    // Measure every card first, so all columns get the same height (like a board).
    const layout = cols.map(c => c.cards.map(k => {
      m.font = `500 15px ${FB}`; const tl = wrap(m, k.title, inner);
      m.font = `400 13px ${FB}`; const xl = k.text ? wrap(m, k.text, inner) : [];
      const chip = k.addon && addonName(k.addon) ? addonName(k.addon) : '';
      const h = CARD_PAD + tl.length * 20 + (xl.length ? 4 + xl.length * 18 : 0) + (chip ? 10 + 22 : 0) + CARD_PAD;
      return { tl, xl, chip, h };
    }));
    const colH = Math.max(140, ...layout.map(cards => 52 + cards.reduce((a, c) => a + c.h + 8, 0) + 10));
    const headH = 96;
    const height = PAD + headH + colH + 46;
    const scale = width > 2200 ? 1.2 : 1.5;

    const cv = document.createElement('canvas');
    cv.width = Math.round(width * scale); cv.height = Math.round(height * scale);
    const ctx = cv.getContext('2d');
    ctx.scale(scale, scale);
    ctx.textBaseline = 'top';

    // Background, the launcher's violet top line
    ctx.fillStyle = P.bg; ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = P.top; ctx.fillRect(0, 0, width, 3);
    // Title and date
    ctx.fillStyle = P.strong; ctx.font = `500 28px ${FH}`;
    const title = board.title || 'Development Roadmap';
    ctx.fillText(wrap(ctx, title, width - PAD * 2)[0] || title, PAD, PAD);
    ctx.fillStyle = P.muted; ctx.font = `400 14px ${FB}`;
    const total = cols.reduce((a, c) => a + c.cards.length, 0);
    ctx.fillText(`${total} item${total === 1 ? '' : 's'} · ${n} column${n === 1 ? '' : 's'} · Updated ${fmt(Date.now())}`, PAD, PAD + 44);

    // Columns
    cols.forEach((c, i) => {
      const x = PAD + i * (CW + GAP), y = PAD + headH;
      round(ctx, x, y, CW, colH, 10); ctx.fillStyle = P.panel; ctx.fill();
      ctx.strokeStyle = P.line; ctx.lineWidth = 1; ctx.stroke();
      // header: color dot, emoji + name, count
      ctx.fillStyle = COLOR[c.color] || COLOR.gray;
      ctx.beginPath(); ctx.arc(x + 20, y + 24, 6, 0, Math.PI * 2); ctx.fill();
      ctx.font = `500 13px ${FB}`;
      const count = String(c.cards.length), cwid = ctx.measureText(count).width + 14;
      ctx.fillStyle = P.chip; round(ctx, x + CW - 14 - cwid, y + 14, cwid, 20, 10); ctx.fill();
      ctx.fillStyle = P.chipTx; ctx.fillText(count, x + CW - 14 - cwid + 7, y + 17);
      ctx.fillStyle = P.strong; ctx.font = `500 17px ${FB}`;
      const name = `${c.emoji ? c.emoji + ' ' : ''}${c.name}`;
      ctx.fillText(wrap(ctx, name, CW - 60 - cwid)[0] || name, x + 34, y + 15);
      // cards
      let cy = y + 48;
      if (!c.cards.length) { ctx.fillStyle = P.muted; ctx.font = `400 13px ${FB}`; ctx.fillText('Nothing here yet', x + 16, cy + 6); }
      c.cards.forEach((k, j) => {
        const L = layout[i][j], cx = x + 10, w = CW - 20;
        round(ctx, cx, cy, w, L.h, 8); ctx.fillStyle = P.card; ctx.fill();
        ctx.strokeStyle = P.cardLine; ctx.stroke();
        let ty = cy + CARD_PAD;
        ctx.fillStyle = P.strong; ctx.font = `500 15px ${FB}`;
        L.tl.forEach(t => { ctx.fillText(t, cx + CARD_PAD, ty); ty += 20; });
        if (L.xl.length) {
          ty += 4; ctx.fillStyle = P.muted; ctx.font = `400 13px ${FB}`;
          L.xl.forEach(t => { ctx.fillText(t, cx + CARD_PAD, ty); ty += 18; });
        }
        if (L.chip) {
          ty += 10; ctx.font = `500 12px ${FB}`;
          const cw2 = Math.min(w - CARD_PAD * 2, ctx.measureText(L.chip).width + 16);
          ctx.fillStyle = P.chip; round(ctx, cx + CARD_PAD, ty, cw2, 22, 11); ctx.fill();
          ctx.fillStyle = P.chipTx; ctx.fillText(wrap(ctx, L.chip, cw2 - 16)[0] || '', cx + CARD_PAD + 8, ty + 4);
        }
        cy += L.h + 8;
      });
    });

    // Footer
    ctx.fillStyle = P.muted; ctx.font = `400 13px ${FB}`;
    ctx.fillText("Warchief's War Diary · Read-only. The Warchief team keeps this board up to date.", PAD, height - 32);
    ctx.fillStyle = P.gold; ctx.fillRect(PAD, height - 38, 24, 2);

    return cv.toDataURL('image/png').split(',')[1];
  }

  window.WLBoardImage = { draw, COLOR };
})();

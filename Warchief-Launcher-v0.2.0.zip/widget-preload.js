// What the Discord panel can ask for: its buttons, finding people, the resize grip, and the state to show.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('dw', {
  cmd: a => ipcRenderer.send('dw:cmd', a),
  search: q => ipcRenderer.invoke('dw:search', q),
  grip: phase => ipcRenderer.send('dw:grip', phase),
  onState: cb => ipcRenderer.on('dw:state', (_e, s) => cb(s))
});

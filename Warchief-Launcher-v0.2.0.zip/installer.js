// Real installs: reads what's in the AddOns folder, downloads addons, unpacks them safely, keeps backups,
// rolls back, uninstalls (to the Recycle Bin) and starts WoW. Runs in the launcher's main program.
'use strict';
const { app, ipcMain, shell } = require('electron');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const account = require('./account');
let AdmZip = null;
try { AdmZip = require('adm-zip'); } catch { AdmZip = null; }

const MAX_ZIP = 200 * 1024 * 1024;      // a download bigger than this isn't an addon
const MAX_UNPACKED = 600 * 1024 * 1024; // nor is a zip that unpacks bigger than this
const STALL_MS = 45000;                 // give up when a download stops moving for this long
const SAFE_NAME = /^[A-Za-z0-9][\w .()+'!&,-]{0,120}$/; // an addon folder name: no slashes, no "..", no drive letters
const BACKUPS = () => path.join(app.getPath('userData'), 'backups');

let catalog = null;          // the addon list the screens are showing
const running = new Set();   // addons being worked on right now

// ---------- Small helpers ----------
const bad = msg => Object.assign(new Error(msg), { friendly: true });
const okName = n => typeof n === 'string' && SAFE_NAME.test(n) && !n.includes('..') && !/[ .]$/.test(n);
const tag = v => String(v || '').replace(/[^\w.+-]/g, '_').slice(0, 60) || 'unknown';
function gameOf(id) { return catalog && Array.isArray(catalog.games) ? catalog.games.find(g => g && g.id === id) : null; }
function productOf(id) {
  if (!catalog || !Array.isArray(catalog.products)) return null;
  return catalog.products.find(p => p && p.id === id && p.enabled !== false && p.release && p.release.version) || null;
}
function foldersOf(p, rel) {
  const r = rel || p.release || {};
  const list = [...(r.folders || []), r.mainFolder].filter(okName);
  return [...new Set(list)];
}
const mainFolderOf = p => (okName(p.release && p.release.mainFolder) ? p.release.mainFolder : foldersOf(p)[0]);

// The game folder the screens chose. It has to be a real folder that looks like a WoW install.
function addonsDirFor(dir) {
  if (typeof dir !== 'string' || !path.isAbsolute(dir)) throw bad("The game folder isn't set. Set it in Options > Directories.");
  let st = null;
  try { st = fs.statSync(dir); } catch { st = null; }
  if (!st || !st.isDirectory()) throw bad(`The game folder ${dir} wasn't found. Check Options > Directories.`);
  let names = [];
  try { names = fs.readdirSync(dir); } catch { names = []; }
  const looksLikeWow = names.some(n => /^wow.*\.exe$/i.test(n)) || names.includes('Interface') || names.includes('WTF');
  if (!looksLikeWow) throw bad(`${dir} doesn't look like a WoW game folder.`);
  return path.join(dir, 'Interface', 'AddOns');
}
const inside = (base, p) => { const r = path.relative(base, p); return r && !r.startsWith('..') && !path.isAbsolute(r); };

// The version an installed addon says it is, from its .toc file (## Version: 1.5.7b).
function tocVersion(folderPath, name) {
  let files = [];
  try { files = fs.readdirSync(folderPath).filter(f => /\.toc$/i.test(f)); } catch { return null; }
  if (!files.length) return null;
  const lower = name.toLowerCase();
  files.sort((a, b) => {
    const rank = f => { const n = f.toLowerCase(); return n === lower + '.toc' ? 0 : n.startsWith(lower + '_mainline') ? 1 : n.startsWith(lower) ? 2 : 3; };
    return rank(a) - rank(b);
  });
  for (const f of files) {
    let text = '';
    try { text = fs.readFileSync(path.join(folderPath, f), 'utf8'); } catch { continue; }
    const m = text.match(/^\s*##\s*Version\s*:\s*(.+?)\s*$/im);
    if (m) {
      const v = m[1].replace(/\|c[0-9a-f]{8}|\|r/gi, '').trim();
      return /@.*@/.test(v) ? '' : v.replace(/^v(?=\d)/i, '');
    }
  }
  return '';
}

// ---------- What's installed ----------
function backupsOf(gameId, id) {
  const base = path.join(BACKUPS(), tag(gameId), tag(id));
  let list = [];
  try { list = fs.readdirSync(base); } catch { return []; }
  return list.map(d => {
    try { const meta = JSON.parse(fs.readFileSync(path.join(base, d, 'backup.json'), 'utf8')); return { dir: path.join(base, d), ...meta }; }
    catch { return null; }
  }).filter(b => b && b.version && Array.isArray(b.folders)).sort((a, b) => a.at - b.at);
}
function scan(gameId, dir) {
  const addons = addonsDirFor(dir);
  const out = {};
  for (const p of (catalog && catalog.products) || []) {
    if (!p || !p.id || p.game !== gameId || !p.release) continue;
    const main = mainFolderOf(p);
    const res = { installed: false, version: null, backups: backupsOf(gameId, p.id).map(b => b.version) };
    if (main && fs.existsSync(path.join(addons, main))) {
      res.installed = true;
      res.version = tocVersion(path.join(addons, main), main) || '';
    }
    out[p.id] = res;
  }
  return { addons, items: out };
}

// ---------- Downloading ----------
async function download(url, size, progress) {
  const ctl = new AbortController();
  let stall = setTimeout(() => ctl.abort(), STALL_MS);
  try {
    const res = await fetch(url, { signal: ctl.signal, headers: { 'User-Agent': 'Warchief-Launcher' }, redirect: 'follow' });
    if (!res.ok) {
      throw bad(res.status === 404 ? "The download wasn't found (404). If the addon repos are private, Discord login has to be switched on in the Admin."
        : `The download failed (the server said ${res.status}). Try again in a minute.`);
    }
    const total = Number(res.headers.get('content-length')) || Number(size) || 0;
    if (total > MAX_ZIP) throw bad("That download is too big to be an addon, so it wasn't installed.");
    const reader = res.body.getReader();
    const chunks = [];
    let got = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      clearTimeout(stall); stall = setTimeout(() => ctl.abort(), STALL_MS);
      chunks.push(value); got += value.length;
      if (got > MAX_ZIP) throw bad("That download is too big to be an addon, so it wasn't installed.");
      progress(total ? Math.min(1, got / total) : 0.5);
    }
    return Buffer.concat(chunks.map(c => Buffer.from(c)));
  } catch (e) {
    if (e.friendly) throw e;
    throw bad(e.name === 'AbortError' ? 'The download stopped. Check your internet connection and try again.' : "Couldn't download the addon. Check your internet connection and try again.");
  } finally { clearTimeout(stall); }
}

// Reads the zip and checks every file stays inside its addon folder. Nothing is written yet.
function readZip(buf, expectMain) {
  if (!AdmZip) throw bad('The zip reader is missing from the launcher. Reinstall the launcher.');
  let zip;
  try { zip = new AdmZip(buf); } catch { throw bad("The download isn't a valid zip file."); }
  const files = [];
  const tops = new Set();
  let total = 0;
  for (const e of zip.getEntries()) {
    const name = e.entryName.replace(/\\/g, '/');
    if (!name || name.startsWith('__MACOSX/') || /(^|\/)\.DS_Store$/.test(name) || /(^|\/)Thumbs\.db$/i.test(name)) continue;
    if (name.startsWith('/') || /^[a-z]:/i.test(name)) throw bad('The zip has a file that points outside the AddOns folder, so it was not installed.');
    const parts = name.split('/').filter(Boolean);
    if (parts.some(x => x === '..' || x === '.')) throw bad('The zip has a file that points outside the AddOns folder, so it was not installed.');
    if (parts.length < 2 && !e.isDirectory) continue; // loose files next to the folders (readme etc.)
    if (!okName(parts[0])) throw bad(`The zip has a folder with an odd name (${parts[0].slice(0, 40)}), so it was not installed.`);
    tops.add(parts[0]);
    if (e.isDirectory) continue;
    total += e.header.size;
    if (total > MAX_UNPACKED) throw bad("That zip unpacks too big to be an addon, so it wasn't installed.");
    files.push({ parts, entry: e });
  }
  if (!tops.size) throw bad('The zip has no addon folders in it.');
  if (expectMain && !tops.has(expectMain)) throw bad(`The zip doesn't have the ${expectMain} folder in it.`);
  return { files, folders: [...tops] };
}

// ---------- Moving folders safely ----------
function rmrf(p) { try { fs.rmSync(p, { recursive: true, force: true, maxRetries: 3 }); } catch { /* left for the next run */ } }
function moveDir(from, to) {
  try { fs.renameSync(from, to); }
  catch (e) {
    if (e.code !== 'EXDEV') throw e;
    fs.cpSync(from, to, { recursive: true }); rmrf(from);
  }
}
// Replaces the addon folders in one go: old ones step aside, new ones move in, and if anything fails the old ones come back.
function swapIn(addons, stage, folders) {
  const aside = [];
  const placed = [];
  const tmp = path.join(addons, `.warchief-old-${crypto.randomBytes(4).toString('hex')}`);
  try {
    fs.mkdirSync(tmp, { recursive: true });
    for (const f of folders) {
      const cur = path.join(addons, f);
      if (fs.existsSync(cur)) { fs.renameSync(cur, path.join(tmp, f)); aside.push(f); }
    }
    for (const f of folders) { fs.renameSync(path.join(stage, f), path.join(addons, f)); placed.push(f); }
  } catch (e) {
    for (const f of placed) rmrf(path.join(addons, f));
    for (const f of aside) { try { fs.renameSync(path.join(tmp, f), path.join(addons, f)); } catch { /* keep going */ } }
    rmrf(tmp);
    throw bad(e.code === 'EBUSY' || e.code === 'EPERM' ? 'Windows is using one of the addon files right now. Close WoW (or anything showing the AddOns folder) and try again.' : `Couldn't put the files in place (${e.code || e.message}). Nothing was changed.`);
  }
  rmrf(tmp);
}
function backup(gameId, p, addons, version, keep) {
  const present = [...new Set([...foldersOf(p), ...(p.beta ? foldersOf(p, p.beta) : [])])].filter(f => fs.existsSync(path.join(addons, f)));
  if (!present.length) return;
  const base = path.join(BACKUPS(), tag(gameId), tag(p.id));
  const dir = path.join(base, tag(version || 'unknown'));
  rmrf(dir);
  fs.mkdirSync(dir, { recursive: true });
  for (const f of present) fs.cpSync(path.join(addons, f), path.join(dir, f), { recursive: true });
  fs.writeFileSync(path.join(dir, 'backup.json'), JSON.stringify({ version: version || 'unknown', at: Date.now(), folders: present }));
  const all = backupsOf(gameId, p.id);
  while (all.length > Math.max(1, keep || 1)) rmrf(all.shift().dir);
}

// ---------- The jobs ----------
async function install(job, progress) {
  const p = productOf(job.id);
  if (!p || p.game !== job.gameId) throw bad("That addon isn't in the launcher's list right now. Press Check for updates.");
  const beta = job.channel === 'beta' && p.beta && p.beta.version;
  const rel = beta ? p.beta : p.release;
  const addons = addonsDirFor(job.dir);
  const before = scan(job.gameId, job.dir).items[p.id] || {};

  progress(0.02, 'Getting the download');
  let url = '';
  if (account.accessOn()) {
    const r = await account.fetchLink(p.id, beta ? 'beta' : 'stable');
    if (!r.ok) throw Object.assign(bad(r.error || "Couldn't get the download."), { need: r.need || '', invite: r.invite || '' });
    url = r.url;
  } else {
    url = String(rel.url || '');
    const okUrl = /^https:\/\/github\.com\/[\w.-]+\/[\w.-]+\/releases\/download\//.test(url) || (!app.isPackaged && /^http:\/\/127\.0\.0\.1:\d+\//.test(url));
    if (!okUrl) throw bad(`${p.name} has no download yet.`);
  }

  const buf = await download(url, rel.size, f => progress(0.05 + f * 0.6, 'Downloading'));
  progress(0.67, 'Checking');
  const zip = readZip(buf, okName(rel.mainFolder) ? rel.mainFolder : null);

  if (before.installed && job.keepBackups && before.version !== rel.version && job.kind !== 'repair') {
    progress(0.72, 'Backing up');
    backup(job.gameId, p, addons, before.version, job.backupCount);
  }

  progress(0.8, 'Installing');
  fs.mkdirSync(addons, { recursive: true });
  const stage = path.join(addons, `.warchief-new-${crypto.randomBytes(4).toString('hex')}`);
  try {
    for (const { parts, entry } of zip.files) {
      const out = path.join(stage, ...parts);
      if (!inside(stage, out)) throw bad('The zip has a file that points outside the AddOns folder, so it was not installed.');
      fs.mkdirSync(path.dirname(out), { recursive: true });
      fs.writeFileSync(out, entry.getData());
    }
    for (const f of zip.folders) fs.mkdirSync(path.join(stage, f), { recursive: true });
    swapIn(addons, stage, zip.folders);
  } finally { rmrf(stage); }

  progress(1, 'Done');
  const main = okName(rel.mainFolder) ? rel.mainFolder : zip.folders[0];
  const now = tocVersion(path.join(addons, main), main);
  return { ok: true, from: before.installed ? before.version : null, version: now || rel.version, folders: zip.folders };
}

async function rollback(job, progress) {
  const p = productOf(job.id) || { id: job.id, release: {} };
  const addons = addonsDirFor(job.dir);
  const list = backupsOf(job.gameId, job.id);
  const b = list[list.length - 1];
  if (!b) throw bad('No older version is backed up yet.');
  const folders = b.folders.filter(okName);
  progress(0.3, 'Restoring');
  const stage = path.join(addons, `.warchief-new-${crypto.randomBytes(4).toString('hex')}`);
  try {
    fs.mkdirSync(stage, { recursive: true });
    for (const f of folders) fs.cpSync(path.join(b.dir, f), path.join(stage, f), { recursive: true });
    swapIn(addons, stage, folders);
  } finally { rmrf(stage); }
  // Folders the newer version added that the older one didn't have
  for (const f of [...new Set([...foldersOf(p), ...(p.beta ? foldersOf(p, p.beta) : [])])]) {
    if (!folders.includes(f) && inside(addons, path.join(addons, f))) rmrf(path.join(addons, f));
  }
  rmrf(b.dir);
  progress(1, 'Done');
  const main = mainFolderOf(p) && folders.includes(mainFolderOf(p)) ? mainFolderOf(p) : folders[0];
  return { ok: true, version: tocVersion(path.join(addons, main), main) || b.version };
}

async function uninstall(job, progress) {
  const p = productOf(job.id);
  if (!p) throw bad("That addon isn't in the launcher's list right now.");
  const addons = addonsDirFor(job.dir);
  const folders = [...new Set([...foldersOf(p), ...(p.beta ? foldersOf(p, p.beta) : [])])].filter(f => fs.existsSync(path.join(addons, f)));
  progress(0.4, 'Removing');
  for (const f of folders) {
    const full = path.join(addons, f);
    if (!inside(addons, full)) continue;
    try { await shell.trashItem(full); } catch { rmrf(full); }
  }
  progress(1, 'Done');
  return { ok: true, removed: folders };
}

// ---------- Starting the game ----------
const EXE_ORDER = ['wow.exe', 'wowclassic.exe', 'wowb.exe', 'wowclassicb.exe', 'wowt.exe', 'wowclassict.exe'];
function findExe(dir) {
  let names = [];
  try { names = fs.readdirSync(dir).filter(n => /^wow.*\.exe$/i.test(n) && !/error|launcher|uninstall/i.test(n)); } catch { return null; }
  names.sort((a, b) => {
    const r = n => { const i = EXE_ORDER.indexOf(n.toLowerCase()); return i < 0 ? 99 : i; };
    return r(a) - r(b);
  });
  return names[0] ? path.join(dir, names[0]) : null;
}
function play(dir) {
  try { addonsDirFor(dir); } catch (e) { return { ok: false, error: e.message }; }
  const exe = findExe(dir);
  if (!exe) return { ok: false, error: `Couldn't find the game's .exe in ${dir}. Check Options > Directories.` };
  return new Promise(resolve => {
    let child;
    try { child = spawn(exe, [], { cwd: dir, detached: true, stdio: 'ignore', windowsHide: false }); }
    catch (e) { return resolve({ ok: false, error: `Couldn't start ${path.basename(exe)} (${e.code || e.message}).` }); }
    child.once('error', e => resolve({ ok: false, error: `Couldn't start ${path.basename(exe)} (${e.code || e.message}).` }));
    child.once('spawn', () => { child.unref(); resolve({ ok: true, exe: path.basename(exe) }); });
  });
}

// ---------- Talking to the screens ----------
function setup() {
  // The screens send the addon list they show (online or the saved copy); installs only use addons from it.
  ipcMain.handle('inst:catalog', (_e, cat) => {
    if (cat && typeof cat === 'object' && Array.isArray(cat.products) && Array.isArray(cat.games)) catalog = cat;
  });
  ipcMain.handle('inst:scan', (_e, gameId, dir) => {
    try { return { ok: true, ...scan(String(gameId), dir) }; }
    catch (e) { return { ok: false, error: e.friendly ? e.message : 'Couldn\'t read the AddOns folder.' }; }
  });
  ipcMain.handle('inst:run', async (e, job) => {
    if (!job || typeof job !== 'object' || !/^[\w-]{1,60}$/.test(String(job.id)) || !['install', 'update', 'repair', 'rollback', 'uninstall'].includes(job.kind)) return { ok: false, error: 'Unknown job.' };
    if (!catalog) return { ok: false, error: "The addon list isn't loaded yet. Press Check for updates." };
    if (!gameOf(job.gameId)) return { ok: false, error: "That game isn't in the launcher's list." };
    if (running.has(job.id)) return { ok: false, error: 'Already working on it.' };
    running.add(job.id);
    const sender = e.sender;
    let last = 0;
    const progress = (f, label) => {
      const now = Date.now();
      if (f < 1 && now - last < 120) return;
      last = now;
      if (!sender.isDestroyed()) sender.send('inst:progress', { id: job.id, pct: Math.round(f * 100), label });
    };
    try {
      const fn = job.kind === 'rollback' ? rollback : job.kind === 'uninstall' ? uninstall : install;
      return await fn(job, progress);
    } catch (err) {
      if (!err.friendly) console.error(err);
      return { ok: false, error: err.friendly ? err.message : `Something went wrong (${err.code || err.message}). Nothing was changed.`, need: err.need || '', invite: err.invite || '' };
    } finally { running.delete(job.id); }
  });
  ipcMain.handle('inst:play', (_e, dir) => play(dir));
  ipcMain.handle('inst:openFolder', (_e, dir) => {
    try { const a = addonsDirFor(dir); fs.mkdirSync(a, { recursive: true }); shell.openPath(a); return true; } catch { return false; }
  });
}

module.exports = { setup };

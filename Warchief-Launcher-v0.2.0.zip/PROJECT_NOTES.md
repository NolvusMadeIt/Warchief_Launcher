# Warchief Launcher: Project Notes (where we left off)

Written on Oct 25, 2026, after the original Claude project chat was deleted by accident.
Everything below was read from the files in this folder. Anything that was only said in
the old chat is NOT here. See "Things only the old chat knew" at the bottom.

---

## What it is

**Warchief Launcher v0.1.0** (author: TankyShrimp, GitHub: NolvusMadeIt).
A Windows desktop app (Electron 45) that installs and updates **Warchiefs War Diary** and
its plugins. Think of a small CurseForge-style launcher just for this addon family.

It comes with an **Admin page**, a small website that runs only on this PC. The developer
uses it to decide what the launcher offers (addons, versions, news, links) and publishes
that to GitHub. Every player's launcher reads it from there.

### Addons it knows about (all for Retail)

| Addon | Type | GitHub repo | Version picked in Admin | Folders in its zip |
|---|---|---|---|---|
| Warchiefs War Diary | Main addon | NolvusMadeIt/Warchiefs_Diary_WoW_AddOn | v1.5.7b | Warchiefs_War_Diary, Warchiefs_War_Diary_CommunityGuides, Warchiefs_War_Diary_GuideBuilder |
| War Diary - Compass | Plugin (needs WWD) | NolvusMadeIt/Warchiefs_Diary_Compass | v1.4.9e | Warchiefs_War_Diary_Compass |
| War Diary - Journal | Plugin (needs WWD) | NolvusMadeIt/Warchiefs_Diary_Journal | v1.2.0 | Warchiefs_War_Diary_Journal |
| War Diary - ToDo | Plugin (needs WWD) | NolvusMadeIt/Warchiefs_Diary_ToDo | v1.1.1 | Warchiefs_War_Diary_ToDo |

All four zips have game interface 120105 in their .toc files. WWD's changelog link points to
its CurseForge page; the plugins have none yet (they show GitHub release notes instead).

### Game versions

- **Retail**: game folder `_retail_`, badge R
- **WoW: Forever**: game folder `_classic_beta_`, badge F (no addons listed for it yet)

---

## How to run it

- **Start Launcher.bat**: opens the launcher. The first time (or after an update) it runs
  `npm install`, then starts Electron and closes its black window.
- **Open Admin.bat**: starts the Admin server hidden in the background and opens
  http://127.0.0.1:5179/ in the browser. It stops by itself about 3 minutes after the tab is
  closed (5 minutes if the page was never opened), or with "Close Admin" at the top right.
- Both need Node.js LTS. If it's missing, the .bat opens the Node download page.
- For developers: `npm start` (launcher) and `npm run admin` (Admin).

---

## How the pieces fit together

1. Admin page edits save to `admin/data/draft.json` (auto-saves a moment after each change).
2. **Publish to launcher** writes `catalog.json` to the GitHub repo
   **NolvusMadeIt/Warchief_Launcher**, branch `main`, and records it in
   `admin/data/published.json`.
3. The launcher reads
   `https://raw.githubusercontent.com/NolvusMadeIt/Warchief_Launcher/main/catalog.json`
   (set in `launcher.config.json`, which the Admin writes).

The launcher looks for the addon list in this order:
1. The preview file `admin/data/preview-catalog.json`, only if "Show my unpublished changes
   in my launcher" is on in Admin > Launcher
2. The online catalog on GitHub (10 second timeout)
3. The last copy it saved (browser storage key `wl.catalog.v1`), shown as "Offline"
4. The sample data in `src/js/data.js`, shown as "Sample list"

---

## Folder map

| File | What it does |
|---|---|
| `main.js` | Electron main process: frameless 1120x680 window, single instance, tray icon, start with Windows, folder picker, WoW folder checks and auto-detect (Battle.net registry key + common folders on drives C to H), downloads the catalog |
| `preload.js` | The only things the launcher screens may ask Windows for (minimize, tray, exit, info, open link, pick folder, check folder, detect folders, login item, get catalog) |
| `launcher.config.json` | Where the launcher reads the catalog from, and whether to use the unpublished preview |
| `package.json` | Name, version 0.1.0, scripts, packages |
| `src/index.html` | Launcher page shell: title bar, tabs (My addons, News, Help), sidebar, main area |
| `src/js/app.js` | All launcher screens and behaviour (about 750 lines) |
| `src/js/data.js` | Sample addon list, game versions, links, and all 16 themes |
| `src/js/version.js` | Compares versions like 1.5.7 < 1.5.7a < 1.5.7b < 1.5.8-beta1 < 1.5.8 |
| `src/js/markdown.js` | Turns news posts and release notes into safe HTML (shared with the Admin) |
| `src/css/base.css` | Layout and components |
| `src/css/themes.css` | Theme "families": shapes and fonts |
| `src/css/fonts.css` | Local fonts (Barlow, Barlow Condensed, Cinzel, Source Sans 3, Inter, IM Fell English, EB Garamond) |
| `admin/server.js` | Admin server on 127.0.0.1:5179: GitHub calls, reads release zips, saves the draft, publishes |
| `admin/public/index.html`, `admin.js`, `admin.css` | The Admin page itself |
| `admin/data/config.json` | GitHub token, login, publish repo and branch. **Secret, never share** |
| `admin/data/draft.json` | The current (unpublished) addon list |
| `admin/data/inspect-cache.json` | What was found inside each release zip (folders and .toc info) |
| `assets/` | `wwd_logo.png` (original), `wwd_logo_transparent.png` (used in the app), `wwd_logo.ico` (window, taskbar, tray) |
| `README.txt` | Plain-language guide for the owner |

---

## Catalog format (catalog.json, schema 1)

```
{
  schema: 1,
  publishedAt: "ISO date",
  launcher: { version },
  games:    [ { id, name, short, title, folder, badge } ],
  links:    { news, discord, support, curseforge, github },
  news:     [ { id, title, body (Markdown), linkLabel, link, date, updated } ],
  products: [ { id, name, short, icon ("logo" | "badge"), type ("main" | "plugin"),
                requires, game, repo, enabled, changelogUrl, release, beta,
                access ("everyone" | "members" | "testers", missing = members) } ],
  access:   { enabled, service, memberRoles[], testerRoles[], invite, bugReports }   (optional)
}
release / beta = { tag, version, name, prerelease, publishedAt, asset, size,
                   url (the zip download), folders[], mainFolder, tocVersion, interface, notes }
```

`news[].link` is one of: discord, support, news, curseforge, github, none.
The launcher skips products that are hidden or have no release version, and products whose
game isn't in the list.

---

## Launcher: what's built

- **My addons**: addons grouped by game, with Installed / Latest / Status columns. Status
  button is Install, Update, Play, Up to date, or "Set folder" when the game folder isn't
  found. Toolbar: Check for updates, Update all, Repair, Roll back, Uninstall.
- Installing a plugin without the main addon asks to install both.
- Uninstall lists the folders it would remove, warns about plugins that need it, and says
  WTF settings are kept.
- Sidebar: logo, "War Diary / Launcher v0.1.0", game filter with counts, the top news post as
  a card, "Beta channel on" chip, Options.
- **News** tab: full posts written in Markdown, with dates and an optional button.
- **Help** menu: Support, Discord, Copy support info. Logo menu: Activity log, Options,
  Check for launcher update, Exit.
- **Options** pages:
  - General: language (English only), start with Windows, what the X does
    (taskbar / tray / close), what happens when a game launches
  - Directories: one or more game folders per game version, "Find my WoW folders",
    green/red check per folder, Restore defaults
  - Downloads: Stable or Beta channel, which games to keep updated, auto or ask for addon
    and launcher updates, keep backups (1, 2, 3 or 5 older versions)
  - Appearance: 12 expansion themes (Midnight is the default, then The War Within,
    Dragonflight, Shadowlands, BfA, Legion, WoD, MoP, Cata, WotLK, TBC, Classic) and 4
    styles (Ember, Gold ledger, Slate, Field journal). Original color moods, no Blizzard
    art or logos.
  - Notifications, Support (copyable support info + activity log), About
- Launcher settings are kept in browser storage key `wl.settings.v1`.
- On first run it tries to find WoW folders by itself.

## Admin page: what's built

Pages: **Publish, Addons, Game versions, News, Links, Launcher, GitHub settings**.

- **GitHub settings**: create a token (link pre-ticks the public_repo box), paste, Connect.
  Pick a public repo to publish to (private ones are greyed out) or "Create a new repo"
  (defaults to Warchief_Launcher), pick the branch.
- **Publish**: setup checklist, status (connected account, where launchers read from, last
  published), "Set versions" dropdown showing each addon's 5 newest GitHub releases. Picking
  one downloads the zip and reads which folders and .toc version are inside. Warns if the
  .toc version doesn't match the release tag. Shows a list of changes since the last publish,
  Publish button, Discard changes.
- **Addons**: add, edit, reorder, delete. Editor: repo dropdown, name, icon (logo or letter
  badge), type, "Needs" (for plugins), game, release version, beta version, CurseForge
  changelog link, badge letters, Show in the launcher.
- **Game versions**: add, edit, reorder, delete, with a dropdown of known WoW folders
  (_retail_, _classic_beta_, _classic_, _classic_era_, _anniversary_, _beta_, _ptr_, ...).
- **News**: post list (top post = sidebar card), full Markdown editor with toolbar buttons,
  side-by-side / write / preview views, live card preview, button choice, keeps unsaved
  drafts if the tab closes.
- **Links**: news page, Discord invite, support page, CurseForge, GitHub (https only).
- **Launcher**: "Show my unpublished changes in my launcher" toggle, the catalog address,
  and a placeholder for step 4's "Build the launcher".

---

## Current state (from the files, Oct 25, 2026)

- Steps 1 and 2 are built: the launcher screens, and the Admin + addon list from GitHub.
- GitHub is connected as @NolvusMadeIt. The publish repo is NolvusMadeIt/Warchief_Launcher
  on `main`.
- Versions are picked for all four addons (table above).
- There is **no `admin/data/published.json`**, so a publish has not completed from this PC.
  Until it does, the launcher can't find catalog.json online and falls back to the saved
  copy or the sample list.
- News: one post, "Testers wanted", with a Discord button. The Discord, support and news
  links are still empty, so those buttons say "This link gets set in the Admin page."
- "Show my unpublished changes" is off.
- Last code edits: Oct 24 around 11:40 PM (Eastern). Admin data last changed around
  10:57 PM that night. Packages were reinstalled Oct 25 around 9:08 PM.

## What is still pretend

Nothing (since Oct 26, 2026). No sample addons or news: if the addon list can't load, the launcher says so.
Run from the folder, "Check for launcher update" asks GitHub for the newest launcher release and says whether
one is out (the folder copy can't replace itself; the installed launcher updates by itself).

---

## Next steps (from README.txt and the code comments)

**Step 3: real downloading and installing into AddOns, with backups**: done Oct 26, 2026 (see "Real installs").

**Step 4: the installer and the launcher's self-update**
- The "Build launcher" button in Admin > Launcher: builds the installer the first time,
  then sends launcher updates to players. The Admin hint says step 4 can use the same
  Warchief_Launcher repo.

---

## Safety rules already in the code (keep them)

- Electron window: contextIsolation on, nodeIntegration off, sandbox on. Screens only get
  the small API in preload.js.
- Only https links open, and always in the normal browser, never inside the launcher.
- Markdown is cleaned with DOMPurify. Only https, mailto and # links are allowed.
- The Admin only listens on 127.0.0.1, checks the Host header, and needs an `X-Admin`
  header for any change.
- Zip reading only accepts github.com release download links, 150 MB max.
- Game folder names and repo names are checked before use.

## Secrets

`admin\data\config.json` holds the GitHub token. It's listed in `.gitignore`.
Never paste it into a chat or commit it.
`admin\data\discord.json` holds the Discord webhook links. Same rule.
The access service's keys (Discord Client Secret, Discord Bot Token, GitHub read-only key) live only in
Vercel's settings for the warchief-access project, marked Sensitive. Never in a file here, never in a chat.
The launcher's own login pass is encrypted by Windows in its app data folder (account.dat).

---

## How the owner likes to work

- Not a coder. Runs things by double-clicking .bat files, not the terminal.
- Choice-driven screens: dropdowns, toggles and checkboxes, as little typing as possible.
- Plain, friendly wording on every screen (the existing UI text is the model).
- Standing rules from the War Diary work: never guess; only change what was asked; keep
  changes small; no extra features or "improvements" nobody asked for; say when a restart
  is needed.

## Discord posts page (added Oct 25, 2026)

The Discohook-style Discord editor the old chat was about to build. It's a new page in the Admin
menu, **Discord posts**, right under News. Nothing that already existed was rebuilt.

- **Posts list** (like WordPress's Posts screen): All / Drafts / Posted filters, Edit, View in
  Discord, Delete.
- **Editor**: title, text box with Discord formatting buttons (bold, italic, underline, crossed
  out, spoiler, 3 heading sizes, small grey text, bulleted and numbered lists, quote, link, code,
  code block), Ctrl+B / I / U / K, side by side / write / preview, and a live preview drawn like
  Discord. Saves on this PC by itself.
- **Look**: "Announcement card" (Discord embed: colored edge, title, big picture, small icon in
  the corner) or "Simple message" (a normal chat message). Edge color from a list or your own.
- **Picture and icon**: from your PC (PNG, JPG, GIF, WEBP, up to 3.5 MB) or a web address.
- **Publish box**: pick the channel, optional @everyone, Post to Discord / Update on Discord,
  Save draft, Delete. Asks before posting. Shows "Changed, not updated in Discord yet" after edits.
- **Delete** asks whether to also delete the message from Discord.
- **Channels**: each one is a Discord webhook (Server Settings > Integrations > Webhooks >
  New Webhook > Copy Webhook URL). Add, rename, remove. Removing one here doesn't touch Discord,
  and adding the same webhook again reconnects its old posts.

Limits Discord sets (the page counts them and stops before sending): card title 256 characters,
card text 4096, simple message 2000. A posted message stays in the channel it was posted to.

New files:
- `admin/discord.js`: talks to Discord (post, edit, delete, check a webhook), keeps posts and
  pictures
- `admin/public/discord.js` and `admin/public/discord.css`: the page itself
- Data: `admin/data/discord.json` (posts and **webhook links: secret**, anyone with a link can
  post in that channel) and `admin/data/discord-media/` (uploaded pictures). Both are covered by
  the existing `admin/data/` line in .gitignore.

Hooked in with only these lines in existing files (copies of the originals are in
`_backup/2026-10-25_before-discord-page/`):
- `admin/public/admin.js`: one menu entry, one page slot
- `admin/public/index.html`: one stylesheet line, one script line
- `admin/server.js`: one line that adds the Discord routes

Tested with a pretend Discord (41 checks on the server side, 29 clicking through the page in a
browser). Not yet tried against a real Discord server.

## Long Discord posts become several messages (added Oct 25, 2026)

Asked for: when a post goes over Discord's limit, another message box shows up and the text carries on in
it, as many as needed (no cap), all on the same edit page.

- The post is still one text (`body`). The page cuts it into boxes, **Message 1 of N**, each with its own count.
  Typing, pasting or deleting anywhere re-flows the text between the boxes, and the cursor stays in place.
- Cuts after a line, else after a sentence, else after a space; only mid-word if there's no space at all.
  The same cutting code is in `admin/discord.js` and `admin/public/discord.js` (keep them identical).
- Limits per message: simple message 2000 (the first one also holds @everyone and the title, the last one
  the picture link), card 4096 of text. On cards the title and icon go on the first card, the big picture on
  the last; every card gets the same edge color. @everyone is only on the first message.
- Under the count is the owner's reminder: "Messages hold up to 2,000 characters (4,000 with Nitro), so
  this post takes N messages." (N updates live). Note: webhook posts are always 2000 per message; Nitro
  doesn't raise that.
- Posting sends the messages one after another (0.35 s apart). Updating edits the old ones in place, adds new
  ones at the bottom of the channel if the post got longer, and deletes the leftover ones if it got shorter.
  The confirm box says which. If Discord stops part-way, it says "Posted 2 of 3 messages…" and Update on
  Discord finishes it. Delete removes all of them.
- Saved posts keep the extra message IDs in `sent.more` (the first is still `sent.messageId`). Old posts
  without it work as before. The longest post text kept is now 500,000 characters (was 12,000).
- Originals are in `_backup/2026-10-25_before-message-splitting/`. Tested with a pretend Discord (32 checks).
  Needs an Admin restart (Close Admin, then Open Admin.bat) to take effect.

## Discord posts: problems you can't miss (added Oct 26, 2026)

Why: a long post looked sent but never reached Discord. The page had the new splitting code, but the
Admin's server was still running the old code (it only loads its code when it starts), so it refused
the post, and the only sign was a small pop-up that disappears.

- **Restart check:** the server's Discord state now includes `version: 2` (admin/discord.js) and the page
  has `SERVER_VERSION = 2` (admin/public/discord.js). If they don't match, a red "The Admin needs a
  restart" box shows at the top of Discord posts and Post / Update is blocked with an explanation.
  **Raise both numbers together** whenever the page needs new server code.
- **Problems stay visible:** if Post or Update fails, a box with an OK button explains it, and the same
  message stays in a red box right above the Post button until it's closed (X) or the next try. Things
  that stop a post before sending (no channel, nothing written, too long) open a box too, not a pop-up.
- Backup of the files before this change: `_backup/2026-10-26_before-long-posts/`.
- Tested: 18 server checks with a 14,000-character post (8 messages), 16 browser checks.

## Discord posts: pasting from web pages, and pictures in the text (added Oct 26, 2026)

- **Paste from a web page** into a post box and it's written the Discord way: links become
  `[text](link)`, plus **bold**, *italic*, __underline__, ~~crossed out~~, `#` headings (h1 `#`,
  h2 `##`, h3 and smaller `###`), `-` / `1.` lists (sub-lists indented 2 spaces), `>` quotes and code.
  A pop-up says how many links and pictures came along. Plain-text paste (Ctrl+Shift+V) works as before.
- **Pictures in the text** are a line of their own: `![description](https://…)`. Discord can't show a
  picture inside a message, so the text is cut after each picture line and the picture shows under that
  message (simple message: in a plain embed box; card: as that card's big picture). The post's own
  Picture still goes on the last message (on a card that already has one, as a second picture box).
- Left out when pasting: SVG drawings (Discord can't show them) and icons smaller than 40 pixels.
  The Discord guidelines page has only SVG icons, so pasting it brings links but no pictures.
- Links are normal Discord links. Discord may add a link preview under simple messages; cards don't.
- Fixed: a line break at the very start of a message box was dropped when the boxes were drawn.
- Server code changed, so `version` is now **3** in both files (Admin restart needed).
- Backup: `_backup/2026-10-26_before-paste-links-pictures/`. Tested with the real Discord guidelines page
  (45 links, 9 messages) and a sample page with pictures: 18 + 29 + 16 + 16 checks.

## Step 4: installer, launcher updates and tray menu (added Oct 26, 2026)

**Launcher updates, Discord style** (main.js, preload.js, src/js/app.js, src/css/update.css, src/index.html)
- Uses electron-updater with GitHub releases on the publish repo (NolvusMadeIt/Warchief_Launcher).
  Checks 3 s after start and every 30 minutes, only in the installed launcher.
- A newer version shows a **green down chevron** left of minimize, with a tooltip ("A new version of
  Warchief Launcher (vX) is out. Click to update now.").
- Options > Downloads > Launcher updates: "automatically" downloads it in the background right away and
  installs it when the launcher closes; "let me choose" waits for the click.
- Click: a full-window skeleton loader ("Hang tight while we update your launcher for you", with download
  %) stays at least 5 to 8 seconds (random in that range), longer if the download takes longer. Then the
  launcher closes, the new version installs silently, and it opens again by itself. A short gap with no
  window while Windows swaps the files is normal. If it fails, a box explains and the arrow comes back.
- Run from the folder (Start Launcher.bat), "Check for launcher update" shows a **preview** of all of this
  (pretend version, loader, then the launcher closes and opens again) so it can be tried without building.
  Fixed Oct 26: the preview used to hang on "Restarting the launcher…", because the window isn't allowed to
  reload itself (the will-navigate block in main.js). It now restarts the app (app:restart in main.js).
- Safety net: if the launcher hasn't restarted 20 s (preview) or 45 s (real update) after "Restarting…",
  the loader closes and a box says to close and reopen the launcher. The loader can't hang forever.
- The corner and About now show the real launcher version (from package.json / the installed app).

**Tray icon** (main.js): there the whole time the launcher runs. Menu: Open Warchief Launcher, News,
Play WoW <version> for each WoW version found on the PC, Options, Check for updates (addons + launcher),
Exit. Play starts the game (see "Real installs").

**Installer** (package.json "build", electron-builder 26.17.0, electron-updater 6.8.10)
- One-click NSIS installer, per user (no admin rights, so updates install silently), file name always
  `Warchief-Launcher-Setup.exe`, output in `dist\`.
- Packs only: main.js, preload.js, launcher.config.json, package.json, src, assets, and the launcher's
  packages. **Never the admin folder** (GitHub token, webhook links), backups or notes. The installed
  launcher never uses the unpublished-preview setting.
- Not code-signed, so Windows SmartScreen may say "Windows protected your PC" on first install:
  More info > Run anyway. A code-signing certificate would remove that.

**Admin > Launcher > Build the launcher** (admin/build.js, admin/public/build.js, build.css)
- Shows this launcher's version, what players have on GitHub (with download count), and the install link
  to share: https://github.com/NolvusMadeIt/Warchief_Launcher/releases/latest/download/Warchief-Launcher-Setup.exe
- **Build and send to players**: pick Small fix / New features / Big release (dropdown), optional
  "What's new". Bumps package.json, runs npm install, builds, uploads the release to GitHub with the
  Admin's token (passed only as GH_TOKEN, masked in the details), adds "What's new". On failure the
  version is put back and nothing is sent.
- **Make a test Setup.exe**: builds into dist\ without sending or changing the version.
- First build downloads the tools and Electron (about 200 MB, 5 to 10 minutes). Keep the page open; the
  Admin stays running during a build even if its tab is closed.
- Known electron-builder problem on Windows ("Cannot create symbolic link" while unpacking winCodeSign) is
  fixed by itself (moves the unpacked tools into the cache folder) and the build runs again.
- Hooked in with one line in admin/server.js, the placeholder card in admin.js's Launcher page replaced
  by WLBuild.card(), and a stylesheet + script line in admin/public/index.html.

**Tested** (here, not on Windows yet): launcher screens 27 checks; Electron from the folder and packed,
8 + 8; a real update with electron-updater from 0.1.0 to 0.1.1 (arrow appeared by itself, loader 7.4 s,
closed and replaced itself) on Linux; Admin build page with a stand-in build tool and GitHub, 19 checks.
The Windows installer itself gets its first real test on the first build on the PC.
Backup of the changed files: `_backup/2026-10-26_before-installer-updates/`.

## Discord login for downloads (added Oct 26, 2026)

Being a member of the Warchief Discord counts the same as buying the addons. Everything stays free
(Blizzard's add-on rules say add-ons must be free; a free Discord membership is fine).
- Not logged in: you can look around, read news and update the launcher. Addon/plugin downloads are
  locked (dashed button with a lock) and a bar on Home says "Log in with Discord" / "Join our Discord".
- Logged in but not in the server, or in it without a member role: the bar says what to do, with
  "Check again". Coming back to the launcher window checks again by itself (at most every 15 s).
- Members download everything. Betas only for the roles ticked "Gets betas" (Tester, Mods, Admins by
  default). The Beta choice in Options > Downloads is greyed out for everyone else.
- **Always on.** There is no on/off switch. If the published list has no `access` block, the launcher still
  uses https://warchief-access.vercel.app, and the Admin always publishes the access settings.
- The account sits at the top of the sidebar, above the games, laid out like Zygor's: Discord picture, name,
  top Discord role (in the role's color) or "Guest", then "Plan:" (Warchief Member / Guest) and
  "Member Since:" (the date they joined the Warchief Discord). The arrow opens the menu: My account, Open the
  Warchief Discord, Check my membership, Log out (logged out: Log in with Discord, Join our Discord).
  No login button in the title bar and no reminder bar over the addon list; locked buttons explain themselves.
- The "War Diary" name and launcher version sit centered in the title bar, on the My addons / News / Help line.
- "@everyone" is left off the role list on purpose: ticking it would let guests download.

**The access service** (`access-service\`, online at https://warchief-access.vercel.app, Vercel team
NolvusMadeIt, project `warchief-access`). No database. One package since tickets (`@vercel/functions`). Files: `api\login.js`,
`callback.js`, `me.js`, `download.js`, `report.js`, `roles.js`, `health.js`, shared code in `lib\core.js`.
- Login: launcher opens /api/login?port&nonce in the browser -> Discord (scope "identify" only) ->
  /api/callback -> back to a tiny page the launcher serves on 127.0.0.1:<port>. The pass is signed
  (HMAC from the client secret), lasts 30 days and renews itself while used. The Discord key is not kept.
- /api/me: the bot looks up the person in the server (GET guild member): in the server, roles, joined date.
- /api/download?product&channel: checks "who can download" for that addon, then hands out a
  short-lived GitHub download link using a read-only key. This is the real lock for private repos.
- /api/report: the bot posts bug reports in #🪲bug-reports (embed + support-info.txt), 3 per 10 min.
- /api/health?deep=1: the Admin's Test button. Says yes/no for every key, never shows one.
- Role choices come from the published addon list (`access` block); until then from the Vercel settings.
- Vercel settings already set: DISCORD_CLIENT_ID, DISCORD_GUILD_ID, DISCORD_BUG_CHANNEL_ID,
  CATALOG_URL, MEMBER_ROLE_IDS, TESTER_ROLE_IDS, DISCORD_INVITE. The owner adds the 3 secrets
  himself (DISCORD_CLIENT_SECRET, DISCORD_BOT_TOKEN, GITHUB_TOKEN, all "Sensitive") and redeploys.
- Discord app "Warchief AddOns" 1564364152359616636, server 1564085762755002508. Roles: Member
  1564354159191400639, Tester 1564362388260782150, Guide Creator 1564363328686653481, Mods
  1564353338105929810, Admins 1564352290221985902. Bug channel 1564351649034535012. Invite
  https://discord.gg/pCjPx2c5s6. Bot permissions: View Channels, Send Messages, Embed Links, Attach
  Files (52224); tickets add Manage Channels and Read Message History (117776, see Tickets below).
  Public Bot off; Message Content on for ticket transcripts, the other privileged intents off.
- To change the service later: edit the files, then from `access-service\` run `npx vercel deploy --prod`
  (the `.vercel` folder links it to the right project), or ask Claude to deploy it.

**Launcher** (`account.js` new, small hooks in main.js and preload.js, screens in app.js, `src\css\account.css`)
- account.js does the login, keeps the pass encrypted with Windows (safeStorage) in the launcher's
  own app data folder (account.dat), and makes every call to the service. The screens never see the pass.
- Offline: the last membership check counts for 3 days.
- Sidebar account (top); Options > Account (plan, member since, roles, beta, last checked,
  Check again, Log out); Help > Report a bug.
- Every Install / Update / Repair gets its download link from the service (Roll back and Uninstall
  don't need it). installer.js asks account.js for the link; the screens never see it.
- The installed launcher only accepts an https service address; a 127.0.0.1 test address only works
  when run from the folder.

**Admin** (`admin\access.js`, `admin\public\access.js`, `access.css`, small hooks in server.js,
admin.js and index.html)
- New page **Members & access**: service address + Test (green ticks per step), the
  one-time setup list with Open buttons, role checkboxes (Can download / Gets betas, loaded from Discord),
  who can download each addon, the invite link, the Report a bug switch.
- Each addon's Edit box has **Who can download** (Everyone / Discord members / Testers only), also shown
  on the Addons page. Missing = Discord members.
- The GitHub "Create a token" link now asks for the `repo` box, so the Admin can read releases from
  private addon repos. Release zips of private repos are read through GitHub's API with that token.
- Publish lists "Members & access changed"; Discard keeps the published access settings.

**Catalog additions**: `access: { enabled, service, memberRoles[], testerRoles[], invite, bugReports }`
and `products[].access` ("everyone" | "members" | "testers").

**Tested** (here): access service 44 checks against pretend Discord/GitHub; launcher in real Electron
42 checks (login, not in server, joins and Check again, tester and beta, cancel, report, offline,
switched off); Admin page 21 checks; earlier launcher tests still pass; packed app includes account.js
and still leaves admin\ out. The live service answers at https://warchief-access.vercel.app/api/health.
Backup of the changed files: `_backup/2026-10-26_before-discord-login/`.

## Real installs (step 3, added Oct 26, 2026)

Everything in the addon list works on the real `<game folder>\Interface\AddOns` now. New file `installer.js`
(main program side), small hooks in main.js and preload.js, screens in app.js.
- **Installed versions** come from each addon's main folder .toc (`## Version:`). A .toc without a
  version shows "?" and counts as needing an update. Addons installed by hand or by CurseForge show up too.
- **Install / Update / Repair**: gets the download (through the Discord login when it's on, else the
  release's public GitHub link), checks the zip first (every file must stay inside its addon folder,
  no odd folder names, the main folder must be there, max 200 MB download / 600 MB unpacked), unpacks it
  into a hidden folder inside AddOns, then swaps the folders in one go. If anything fails the old folders
  come back and nothing is changed. Loose files next to the folders in the zip (readme) are skipped.
- **Backups**: before an update, the old version's folders are copied to the launcher's app data folder
  (`%APPDATA%\Warchief Launcher\backups\<game>\<addon>\<version>`), keeping the number chosen in
  Options > Downloads. Repair doesn't make a backup.
- **Roll back** puts the newest backup back, removes folders only the newer version had, and uses up that backup.
- **Uninstall** moves the addon's folders to the Recycle Bin. Other addons, the WTF folder and
  AddOns\_backup are never touched.
- **Play** starts the game's Wow*.exe from the game folder (Wow.exe, WowClassic.exe, WowB.exe ...),
  then does what "When I launch a game" says (minimize, tray, close or nothing).
- **Automatic updates** (Options > Downloads, the default): on start and on Check for updates, addons that
  are installed and have an update get updated by themselves. It never installs addons you didn't install.
- The activity log is now real (`wl.activity.v1`); the old pretend data (`wl.preview.v1`) is ignored.
- Errors show in a box and go into the activity log (Options > Support).

**Tested** (here, Linux; Windows on the first real run): 36 checks in the real app with a test WoW folder
(update with backup, roll back, plugin install through the login, repair, four kinds of bad zips refused with
AddOns unchanged, uninstall, "Install both", Play, automatic updates, login switched off), plus the Discord
login test (42), the screens (27) and start-up (8 + 2). The packed app includes installer.js and adm-zip.
Backup of the changed files: `_backup/2026-10-26_before-real-installs/`.

## Tickets, To-do and the Discord panel (added Oct 27, 2026)

Three things, built from Discord's own docs (Interactions, Message Components, Modals with Label components,
Channels and permission overwrites, Server Widget).

**1. Tickets in the Warchief Discord** (works like Ticket Tool / Tickets v2)
- A **ticket panel** message with one button per kind of ticket (default: Get help, Report a bug, Something else).
- Pressing a button shows a short **form** (up to 5 questions, Discord's pop-up form), or opens straight away
  when the button has no questions. The member gets a private "Your ticket is ready: #ticket-0001" reply.
- Each ticket is a **private channel** `ticket-0001`, `ticket-0002`… in the ticket category. Only the member,
  the staff roles and the bot can see it. The welcome message pings the member (and the staff roles, if
  "Ping the staff roles" is on and the role allows @mentions) and shows the form answers.
- **Claim** (staff only) and **Close** (the member or staff; asks first) buttons in the ticket.
- Closing saves a **transcript** (HTML page that looks like Discord) in the log channel with a summary,
  DMs the member a copy (skipped quietly if their DMs are closed), then deletes the channel. If the transcript
  can't be saved, the ticket stays open.
- Staff are: the staff roles chosen on the Tickets page (default Admins + Mods), the server owner, and anyone
  with an Administrator role.
- Nothing is stored anywhere else: an open ticket IS its channel (the channel topic says number, type,
  who opened it, who claimed it); a closed ticket is its message in the log channel. Numbers keep counting
  from the log.

How it works: Discord sends every button press and form to the access service
(`https://warchief-access.vercel.app/api/interactions`, the app's "Interactions Endpoint URL"). Each one is
signed by Discord (Ed25519) and refused without a valid signature. Discord wants an answer within 3 seconds,
so the slow work (making the channel, the transcript) runs right after the first answer (Vercel `waitUntil`,
package `@vercel/functions` 3.9.11). New service files: `api\interactions.js`, `api\staff.js`,
`lib\tickets.js`. The ticket settings come from the published addon list (`tickets` block).

The bot needs 2 more permissions for tickets: **Manage Channels** and **Read Message History**, so 6 in total
(View Channels, Send Messages, Manage Channels, Embed Links, Attach Files, Read Message History = 117776).
It also needs **Message Content** turned on (Discord Developer Portal > Bot, or the Connect button does it),
so transcripts include what people wrote. No other privileged intents.

**Admin: Tickets page** (`admin\staff.js`, `admin\public\tickets.js`, `tickets.css`)
- Staff log in with Discord (same login as the launcher; the browser comes back to http://127.0.0.1:5179/auth).
  The pass is kept in `admin\data\staff.json` on this PC only. People without a staff role are told so.
- Tickets tab: open tickets (who opened, claimed, when) and the newest 50 closed ones (closed by, reason,
  transcript link). Open a ticket to read the whole conversation, reply (posted in the ticket with your name
  and a "Warchief staff" footer), Claim, or Close with a reason.
- Setup tab: checklist (bot permissions with an "Update bot" link, Connect, Message Content, category, log
  channel), the ticket category and log channel (pick one or press "Make a private Tickets category" /
  "Make a staff-only ticket-logs channel"), staff roles, ping on/off, the ticket buttons editor (name, emoji,
  color, welcome message, questions), and the panel (title, text, channel, Post / Update).
- Changes reach the bot with **Publish**. Publish also updates the posted panel when the buttons changed.
  Which messages the bot posted is kept in `admin\data\staff-posts.json`.

**2. To-do list** (`admin\public\todo.js`; launcher To-do tab)
- Admin To-do page: add / edit / reorder / delete items with a title, notes, status (Planned, In progress,
  Done) and optionally the addon it's about. Publish sends it to the launchers (`todo` in the addon list).
- Launcher: a **To-do** tab between News and Help, grouped In progress / Planned / Done.
- Discord: the bot posts the list as one message in a channel you pick ("Post in Discord"), and every
  Publish updates that same message.

**3. Discord panel next to the launcher** (`widget.js`, `widget-preload.js`, `src\discord.html`,
`src\js\discord-window.js`, `src\css\discord-window.css`; hooks in main.js, preload.js, app.js)
- Its **own small window** (350 wide, same height as the launcher), stuck to the launcher's right edge, side by
  side, not inside the launcher (the owner's choice, Oct 27). If there's no room on the right it sits on the left.
  It moves with the launcher, matches its height, hides when the launcher is minimized or sent to the tray, and
  comes back with it. It can't be dragged away on its own, has no taskbar button, and uses the launcher theme's
  colors (top line, bar, border).
- Inside: Discord's own server widget (`https://discord.com/widget?id=1564085762755002508&theme=dark`, light
  for light launcher themes), with the iframe settings from Discord's embed code. Who's online, voice channels,
  Join button. Links open in the browser / Discord app. Needs "Enable Server Widget" on (it is).
- On by default. Hide it with the button at its top right, Help > Hide the Discord panel, or Options > General.
  Bring it back with Help > Show the Discord panel or Options > General. Remembered.
- The launcher and the panel open centered together; the launcher keeps its 1120 x 680 size.
- The addon list can name another server with `access.serverId`.
- It reloads itself every 5 minutes while visible, when it comes back after being hidden, and with its refresh
  button. Discord itself only updates the online list every 5 minutes (widget.json is cached for 300 seconds),
  so someone who just came online can take up to 5 minutes to show.
- "0 Members Online" is Discord's own count: the widget only lists people who are online (Invisible counts as
  offline), and the Warchief bot never shows online because it has no chat connection (it only answers buttons).
- Tested in real Electron, from the folder and as a built app: 24 checks (position, follows moves/resizes,
  left side when no room, hides with tray/minimize, hide button, Help and Options switches, light theme, restart).

**Opening tickets from the launcher**: left out on purpose (the owner is doing that part).

**Tested** (here, against a pretend Discord that checks signatures, permissions, message limits and the
Message Content rule): service tickets 69 checks, Admin Tickets + To-do pages in a browser 42, launcher To-do
tab + Discord panel 26, and all earlier tests still pass (service 44, Admin 23, launcher screens 26, launcher
login in Electron 47, installs 36, Electron start 8).
Also fixed: Publish now saves the page first, so a change made a split second before Publish is included.
Backup of the changed files: `_backup/2026-10-27_before-tickets/`, and for the side window
`_backup/2026-10-27_before-side-window/` (the old in-launcher panel styles, `widget.css`, are in there too).

## Bug reports go to the #🪲bug-reports forum (added Oct 27, 2026)

The bug channel (1564351649034535012) is a **Forum**, so Discord refuses plain messages there (that was the
"Discord said 400"). Now each report from Help > Report a bug becomes its own **forum post**:
- Title from the report: `<addon> <version>: <first line of What happened>` (100 letters max).
- Tag: **Addon** for the main addon, **Plugin** for plugins. Launcher reports get a tag named "Launcher" if the
  forum has one, otherwise **Addon** (the forum requires a tag). Moderated tags are never used.
- First message: the reporter is tagged (only them), so they follow the post and see the team's answers;
  a bug-report box with **What happened**, **Steps to make it happen**, **What should have happened**, and
  fields Addon/Plugin, Version, How often, Launcher, Reported by; plus support-info.txt when ticked.
- Uses Discord's "Start Thread in Forum or Media Channel" (POST /channels/{id}/threads). A text channel still
  gets a single message with the same layout. The service remembers the channel type and tags for 10 minutes.
- Launcher form: What is it about? / How often? (dropdowns), What happened?, How can we make it happen?
  (optional), What should have happened? (optional), Attach my support info. After sending, "See it on
  Discord" opens the post.
- Bot permissions in the forum: View Channel, Send Messages (= Create Posts), Embed Links, Attach Files.
- Tested: service 49 checks (forum post, tags, layout, file, mentions, text-channel fallback), launcher in
  Electron 48. Backup: `_backup/2026-10-27_before-forum-reports/`.

## Tickets: Publish and the panel, made foolproof (added Oct 27, 2026)

First real test: the bot answered "Tickets aren't set up yet" because the Tickets settings were never
published, and the panel had been posted in #ticket-logs (staff-only). Fixed:
- **Post the panel** publishes first when the ticket settings aren't published ("Publish and post the panel",
  showing what goes out), so the buttons work straight away.
- The log channel and anything inside the ticket category are refused for the panel (members can't see them).
  A channel named like support/help is picked by default. Moving the panel deletes the old one.
- Setup checklist and the Tickets tab say "chosen but not published yet" with a Publish button, and re-check
  themselves after every Publish.
- The access service reads the addon list through GitHub's API with its read-only key (raw.githubusercontent.com
  keeps the old file for 5 minutes, even with ?t=), keeps it 30 seconds, and the Admin asks it to read the list
  again right after Publish (`/api/staff?do=refresh`, staff only). So a Publish reaches the bot at once.
- Tested: service tickets 75 checks, Admin Tickets/To-do 48, service 49, Admin 23.
  Backup: `_backup/2026-10-27_before-publish-flow/`.

## To-do is a development board now, like GitHub Projects (added Oct 27, 2026)

The owner wanted a real dev-style to-do: a board like GitHub's Projects page, in the launcher and in Discord.
The earlier list of items with 3 fixed statuses is gone (draft `todo` became `roadmap`; old items would turn
into cards).
- **Admin > To-do** (`admin\public\todo.js`, `board.css`): columns side by side, each with a name, emoji and
  color (Gray, Blue, Green, Yellow, Orange, Red, Pink, Purple). Cards have a bold title, an optional description
  and an optional addon label. Drag cards between columns and up/down, or use the Column dropdown in the card's
  box. The column's "…" box renames it, moves it left/right or deletes it. Up to 12 columns, 100 cards each.
- **Paste a roadmap**: paste a Discord-style roadmap. `# Title` becomes the board title, each `## 🔧 Section` a
  column (emoji kept, color guessed from the name), each `- **Name**: description` line a card.
- **Launcher To-do tab**: the same board, read-only. Four columns fit the normal window; more scroll sideways.
- **Discord**: the Admin draws the board as a picture (`admin\public\board-image.js`, in the launcher's colors)
  and the bot posts it as one message: `## <board title>`, an "Updated" line, and the picture (with a text copy as
  its description). Every Publish swaps in a new picture on the same message. Moving it to another channel deletes
  the old one. Service: `/api/staff?do=todo` takes the picture (PNG up to 3 MB).
- Catalog: `roadmap: { title, columns: [{ id, name, emoji, color, cards: [{ id, title, text, addon, at }] }] }`.
- Tested: service 77, Admin 54 (with the owner's real roadmap pasted in), launcher 24, plus the older sets.
  Backup: `_backup/2026-10-27_before-todo-board/`.

## Things only the old chat knew (fill these in)

- Plans beyond steps 3 and 4
- Any bug that was being worked on when the chat ended
- Ideas that were tried and turned down
- Anything decided about how installs, backups or beta should behave in step 3

---

## Starting the new project

Best: start the new chat from the Claude desktop app and connect the folder
`E:\Warchief Launcher`, so Claude can read the code itself. Otherwise, add this file and
README.txt to the project's files.

First message idea: "Read PROJECT_NOTES.md and README.txt in E:\Warchief Launcher. We're
picking up at step 3."

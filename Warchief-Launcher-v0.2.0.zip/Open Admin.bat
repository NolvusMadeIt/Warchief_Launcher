@echo off
title Warchief Admin
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js isn't installed yet, and the Admin needs it to run.
  echo  Opening the download page now. Install the LTS version,
  echo  then double-click "Open Admin.bat" again.
  echo.
  start "" "https://nodejs.org/en/download"
  pause
  exit /b
)

set NEEDINSTALL=
if not exist "node_modules\adm-zip" set NEEDINSTALL=1
if not exist "node_modules\marked" set NEEDINSTALL=1
if not exist "node_modules\dompurify" set NEEDINSTALL=1
if defined NEEDINSTALL (
  echo.
  echo  Getting what the Admin needs. This only happens once in a while and takes a minute...
  echo.
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo  Something went wrong while downloading. Check your internet and try again.
    pause
    exit /b
  )
)

rem Start the Admin in the background (no window). It opens in your browser
rem and stops by itself a few minutes after you close the tab.
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "Start-Process -FilePath 'node' -ArgumentList 'admin\server.js' -WorkingDirectory '%~dp0' -WindowStyle Hidden"
exit /b

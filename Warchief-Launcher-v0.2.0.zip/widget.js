// The Discord panel: our own small window with who's online in the Warchief Discord, your account, search and a
// Join button. Docked: stuck to the launcher's right edge, it moves and resizes with it. Popped out: its own window
// you can move anywhere. Closed: hidden (the Discord button in the launcher's title bar brings it back).
// The launcher screens say what to show through 'dw:set'; the panel's buttons come back to them as 'dw:do'.
'use strict';
const { BrowserWindow, ipcMain, screen, shell, clipboard, net } = require('electron');
const path = require('path');
const account = require('./account');

const WIDTH = 320;
let owner = null;
let dw = null;
let want = { mode: 'closed' };
let loaded = false;
let lastMode = '';
let gripFn = null;
let data = null, dataAt = 0, dataFor = '';

const ID = /^\d{5,25}$/;
const COLOR = /^#[0-9a-f]{6}$/i;
const str = (v, n) => String(v == null ? '' : v).slice(0, n);
function clean(o) {
  const x = o && typeof o === 'object' ? o : {};
  const c = x.colors && typeof x.colors === 'object' ? x.colors : {};
  const colors = {};
  for (const k of ['bg', 'bar', 'side', 'line', 'tx', 'tx2', 'frameTop', 'acc', 'ink', 'link', 'sel', 'hover']) if (COLOR.test(c[k] || '')) colors[k] = c[k];
  const a = x.account && typeof x.account === 'object' ? x.account : {};
  const mode = ['docked', 'popped', 'closed'].includes(x.mode) ? x.mode : x.show === true ? 'docked' : 'closed';
  return {
    mode, serverId: ID.test(String(x.serverId || '')) ? String(x.serverId) : '', light: x.light === true, colors,
    invite: /^https:\/\/(discord\.gg|discord\.com\/invite)\/[\w-]+$/.test(x.invite || '') ? x.invite : '',
    account: {
      state: ['loading', 'busy', 'out', 'offline', 'in'].includes(a.state) ? a.state : 'loading',
      id: ID.test(String(a.id || '')) ? String(a.id) : '', name: str(a.name, 64), username: str(a.username, 64),
      avatar: /^https:\/\/cdn\.discordapp\.com\//.test(a.avatar || '') ? a.avatar : '', role: str(a.role, 64),
      roleColor: COLOR.test(a.roleColor || '') ? a.roleColor : '', inServer: a.inServer === true
    }
  };
}

const ownerShown = () => owner && !owner.isDestroyed() && owner.isVisible() && !owner.isMinimized();
// Docked: right of the launcher; on the left when there's no room on the right; inside the screen edge when neither fits.
function place() {
  if (!dw || dw.isDestroyed() || !owner || owner.isDestroyed() || want.mode !== 'docked') return;
  const b = owner.getBounds();
  const area = screen.getDisplayMatching(b).workArea;
  let x = b.x + b.width;
  if (x + WIDTH > area.x + area.width) x = b.x - WIDTH >= area.x ? b.x - WIDTH : area.x + area.width - WIDTH;
  dw.setBounds({ x, y: b.y, width: WIDTH, height: b.height });
}
// Popped out: a little apart from the launcher the first time, then wherever you drag it.
function popOut() {
  const b = owner.getBounds();
  const area = screen.getDisplayMatching(b).workArea;
  const h = Math.max(560, Math.min(b.height - 60, area.height));
  let x = b.x + b.width + 40;
  if (x + WIDTH > area.x + area.width) x = Math.max(area.x, area.x + area.width - WIDTH - 20);
  dw.setBounds({ x, y: Math.min(b.y + 36, area.y + area.height - h), width: WIDTH, height: h });
}

function create() {
  dw = new BrowserWindow({
    parent: owner, width: WIDTH, height: owner.getBounds().height,
    frame: false, show: false, resizable: false, movable: false, minimizable: false, maximizable: false, fullscreenable: false,
    skipTaskbar: true, backgroundColor: (want.colors && want.colors.bg) || '#0d0b19', title: 'Warchief Discord',
    webPreferences: { preload: path.join(__dirname, 'widget-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  dw.webContents.setWindowOpenHandler(({ url }) => { if (/^https:\/\//i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  dw.webContents.on('will-navigate', e => e.preventDefault());
  dw.webContents.on('did-finish-load', () => { loaded = true; send(); });
  dw.on('closed', () => { dw = null; loaded = false; lastMode = ''; });
  loaded = false;
  dw.loadFile(path.join(__dirname, 'src', 'discord.html'));
}

function send() {
  if (dw && !dw.isDestroyed() && loaded) dw.webContents.send('dw:state', { ...want, data, dataAt });
}

// Who's online: Discord's public server widget data (Discord itself refreshes it about every 5 minutes)
async function fetchData(force) {
  if (!want.serverId || (!force && dataFor === want.serverId && Date.now() - dataAt < 4.5 * 60000)) return;
  try {
    const r = await net.fetch(`https://discord.com/api/guilds/${want.serverId}/widget.json`, { headers: { 'Cache-Control': 'no-cache' } });
    if (r.ok) {
      const j = await r.json();
      data = {
        name: str(j.name, 100), online: Number(j.presence_count) || 0,
        channels: (Array.isArray(j.channels) ? j.channels : []).slice(0, 25).map(c => ({ id: str(c.id, 25), name: str(c.name, 100), position: Number(c.position) || 0 })),
        members: (Array.isArray(j.members) ? j.members : []).slice(0, 100).map(m => ({
          id: str(m.id, 25), name: str(m.username, 64), status: ['online', 'idle', 'dnd'].includes(m.status) ? m.status : 'online',
          avatar: /^https:\/\/cdn\.discordapp\.com\//.test(m.avatar_url || '') ? m.avatar_url : '',
          game: m.activity && m.activity.name ? str(m.activity.name, 80) : m.game && m.game.name ? str(m.game.name, 80) : '',
          channel: m.channel_id ? str(m.channel_id, 25) : ''
        }))
      };
    } else data = { error: r.status === 403 ? 'off' : 'down' };
  } catch { data = data && !data.error ? data : { error: 'down' }; }
  dataAt = Date.now(); dataFor = want.serverId;
  send();
}
setInterval(() => { if (dw && !dw.isDestroyed() && dw.isVisible()) fetchData(false); }, 60000).unref();

function sync() {
  if (!owner || owner.isDestroyed()) return;
  if (want.mode === 'closed' || !want.serverId) { if (dw && !dw.isDestroyed()) dw.hide(); lastMode = want.mode; return; }
  if (!dw || dw.isDestroyed()) create();
  if (lastMode !== want.mode) {
    dw.setMovable(want.mode === 'popped');
    if (want.mode === 'popped') popOut();
    lastMode = want.mode;
  }
  place();
  send();
  fetchData(false);
  if (ownerShown()) { if (!dw.isVisible()) dw.showInactive(); } else dw.hide();
}

function tellOwner(a) { if (owner && !owner.isDestroyed()) owner.webContents.send('dw:do', a); }
function setMode(mode) { want.mode = mode; tellOwner({ do: 'mode', mode }); sync(); }

function setup(win) {
  owner = win;
  win.on('move', place);
  win.on('resize', place);
  const hide = () => { if (dw && !dw.isDestroyed()) dw.hide(); };
  win.on('minimize', hide);
  win.on('hide', hide);
  win.on('restore', () => setTimeout(sync, 60));
  win.on('show', () => setTimeout(sync, 60));
  win.on('closed', () => { if (dw && !dw.isDestroyed()) dw.destroy(); dw = null; owner = null; });
}
ipcMain.handle('dw:set', (_e, o) => { want = clean(o); sync(); return true; });

const fromPanel = e => dw && !dw.isDestroyed() && e.sender === dw.webContents;
ipcMain.on('dw:cmd', (e, a) => {
  if (!fromPanel(e) || !a || typeof a !== 'object') return;
  switch (a.do) {
    case 'close': return setMode('closed');
    case 'pop': return setMode('popped');
    case 'dock': return setMode('docked');
    case 'refresh': return fetchData(true);
    case 'login': if (owner) { owner.show(); owner.focus(); } return tellOwner({ do: 'login' });
    case 'account': if (owner) { owner.show(); owner.focus(); } return tellOwner({ do: 'account' });
    case 'copy': if (want.invite) { clipboard.writeText(want.invite); tellOwner({ do: 'toast', text: 'Invite link copied. Paste it to a friend.' }); } return;
    case 'profile': if (ID.test(String(a.id || ''))) shell.openExternal('https://discord.com/users/' + a.id); return;
    case 'open': if (/^https:\/\/(discord\.com|discord\.gg)\//.test(String(a.url || ''))) shell.openExternal(a.url); return;
  }
});
// Finding someone in the whole server goes through the Warchief bot (needs the Discord login)
ipcMain.handle('dw:search', async (e, q) => {
  if (!fromPanel(e)) return { ok: false };
  return account.community('search', typeof q === 'string' ? q : '');
});
ipcMain.on('dw:grip', (e, phase) => { if (fromPanel(e) && gripFn) gripFn(phase); });

module.exports = { WIDTH, setup, place, onGrip: fn => { gripFn = fn; }, get window() { return dw; } };

WARCHIEF LAUNCHER

TWO THINGS TO DOUBLE-CLICK
  Start Launcher.bat   Opens the launcher. The black window only stays open the first
                       time (or after an update) while it downloads what it needs.
                       After that it closes by itself right away.
  Open Admin.bat       Opens your Admin page in your browser. No black window.
                       It stops by itself a few minutes after you close the tab,
                       or press "Close Admin" in the top right.

Both need Node.js (LTS). If it's missing, the .bat opens the download page.

FIRST TIME IN THE ADMIN
  1. GitHub settings > Create a token > paste it > Connect
  2. GitHub settings > Where to publish > "Create a new repo" (makes Warchief_Launcher)
  3. Publish > Set versions > pick each addon's version from the dropdown
  4. Publish to launcher
  Your launcher then reads the real addon list from GitHub.
  Launcher > "Show my unpublished changes in my launcher" lets you check changes first.

WHAT'S REAL NOW
  - The addon list, versions, changelogs, news and links come from the Admin.
  - Folder picking and "Find my WoW folders".
  - Install / Update / Repair / Roll back / Uninstall still use PRETEND installs.
    Nothing in your AddOns folder is changed yet. That's step 3.

WHAT COMES NEXT
  Step 3: real downloading and installing into AddOns, with backups
  Step 4: the installer and the launcher's self-update (the "Build launcher" button)

YOUR FILES
  admin\data\   Your Admin settings and GitHub token. Only on this PC. Never share it.
  assets\wwd_logo.png              Your original logo (untouched)
  assets\wwd_logo_transparent.png  Cut-out version used in the launcher and Admin
  assets\wwd_logo.ico              Window, taskbar and tray icon

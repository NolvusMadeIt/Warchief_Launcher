// The only things the launcher screens are allowed to ask Windows for.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  isElectron: true,
  minimize: () => ipcRenderer.invoke('win:minimize'),
  toTray: () => ipcRenderer.invoke('win:toTray'),
  exit: () => ipcRenderer.invoke('win:exit'),
  info: () => ipcRenderer.invoke('app:info'),
  openExternal: url => ipcRenderer.invoke('shell:open', url),
  pickFolder: start => ipcRenderer.invoke('dialog:folder', start),
  checkFolder: p => ipcRenderer.invoke('fs:checkFolder', p),
  detectFolders: games => ipcRenderer.invoke('fs:detect', games),
  setLoginItem: on => ipcRenderer.invoke('app:loginItem', on),
  getCatalog: () => ipcRenderer.invoke('catalog:get'),
  // Launcher updates
  updateGet: () => ipcRenderer.invoke('update:get'),
  updateMode: mode => ipcRenderer.invoke('update:mode', mode),
  updateCheck: () => ipcRenderer.invoke('update:check'),
  updateDownload: () => ipcRenderer.invoke('update:download'),
  updateRestart: () => ipcRenderer.invoke('update:restart'),
  updateLatest: () => ipcRenderer.invoke('update:latest'),
  onUpdate: cb => ipcRenderer.on('update:state', (_e, s) => cb(s)),
  // Tray menu
  setTray: info => ipcRenderer.invoke('tray:set', info),
  onTray: cb => ipcRenderer.on('tray:do', (_e, a) => cb(a)),
  // Discord login for downloads
  acctGet: fresh => ipcRenderer.invoke('acct:get', fresh),
  acctLogin: () => ipcRenderer.invoke('acct:login'),
  acctCancel: () => ipcRenderer.invoke('acct:cancel'),
  acctLogout: () => ipcRenderer.invoke('acct:logout'),
  acctDownload: (product, channel) => ipcRenderer.invoke('acct:download', product, channel),
  acctReport: report => ipcRenderer.invoke('acct:report', report),
  // To-do votes and the Discord posts for the bell (the access service)
  community: (act, body) => ipcRenderer.invoke('acct:community', act, body),
  // Installing addons for real
  instCatalog: cat => ipcRenderer.invoke('inst:catalog', cat),
  instScan: (gameId, dir) => ipcRenderer.invoke('inst:scan', gameId, dir),
  instRun: job => ipcRenderer.invoke('inst:run', job),
  instPlay: dir => ipcRenderer.invoke('inst:play', dir),
  instOpenFolder: dir => ipcRenderer.invoke('inst:openFolder', dir),
  onInstProgress: cb => ipcRenderer.on('inst:progress', (_e, p) => cb(p)),
  // The Discord panel next to the launcher (widget.js)
  dwSet: want => ipcRenderer.invoke('dw:set', want),
  onDwDo: cb => ipcRenderer.on('dw:do', (_e, a) => cb(a)),
  // The resize grip in the corner
  grip: phase => ipcRenderer.invoke('win:grip', phase)
});

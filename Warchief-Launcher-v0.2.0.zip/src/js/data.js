// Starting values: game versions, links and themes. Addons and news always come from the published addon list.
window.WL_DATA = {
  launcher: { version: '0.1.0' },

  // Game versions. The Admin page will let you add more later.
  games: [
    { id: 'retail', name: 'Retail', short: 'Retail', title: 'World of Warcraft Retail', folder: '_retail_', badge: 'R' },
    { id: 'forever', name: 'WoW: Forever', short: 'Forever', title: 'World of Warcraft: Forever', folder: '_classic_beta_', badge: 'F' }
  ],

  // Links are set in the Admin page. null = not set yet.
  links: {
    news: null,
    discord: null,
    support: null,
    curseforge: 'https://www.curseforge.com/wow/addons/warchiefs-war-diary',
    github: 'https://github.com/NolvusMadeIt'
  },

  news: [],
  products: [],
  roadmap: { title: '', columns: [] },

  // Themes. "family" sets the shapes and fonts, "c" sets the colors.
  // Expansion themes are original color moods, no Blizzard art or logos.
  defaultTheme: 'midnight',
  themes: [
    { id: 'lasttitan', name: 'The Last Titan', group: 'expansion', family: 'forged', desc: 'Titan bronze and storm blue',
      fonts: { fh: "'Cinzel', serif", 'fs-brand': '18px' },
      c: { bg: '#0c1016', bar: '#070a0e', side: '#121821', line: '#27323f', tx: '#e9eef4', tx2: '#93a1b2', acc: '#e0b25c', ink: '#1a1204', link: '#7fc4ff', frameTop: '#4f9cff', forever: '#7fd0ff' } },
    { id: 'midnight', name: 'Midnight', group: 'expansion', family: 'forged', desc: 'Void and Sunwell light',
      fonts: { fh: "'Cinzel', serif", 'fs-brand': '18px' },
      c: { bg: '#0d0b19', bar: '#07060f', side: '#131026', line: '#2c2650', tx: '#ece8fb', tx2: '#9a93bf', acc: '#f2c75c', ink: '#1c1405', link: '#b39dff', frameTop: '#8f74ff', forever: '#7fd0ff' } },
    { id: 'warwithin', name: 'The War Within', group: 'expansion', family: 'forged', desc: 'Earthen stone and amber',
      fonts: { fh: "'Cinzel', serif", 'fs-brand': '18px' },
      c: { bg: '#12100d', bar: '#0a0907', side: '#1a1712', line: '#3a3226', tx: '#f0e8da', tx2: '#a59a86', acc: '#e3a33b', ink: '#1d1204', link: '#f2c472' } },
    { id: 'dragonflight', name: 'Dragonflight', group: 'expansion', family: 'forged', desc: 'Dragon red and sky teal',
      c: { bg: '#140f11', bar: '#0b0809', side: '#1c1517', line: '#3a2a2c', tx: '#f3e9e6', tx2: '#a8949a', acc: '#e2603e', ink: '#ffffff', link: '#4fc7cf' } },
    { id: 'shadowlands', name: 'Shadowlands', group: 'expansion', family: 'regal', desc: 'Cold silver and shadow',
      c: { bg: '#0f1317', bar: '#090c0f', side: '#151a20', line: '#2a333d', tx: '#e6edf2', tx2: '#8d9aa6', acc: '#a9cfe0', ink: '#0b1418', link: '#c9e3ee' } },
    { id: 'bfa', name: 'Battle for Azeroth', group: 'expansion', family: 'regal', desc: 'Deep sea blue and gold',
      c: { bg: '#0b111d', bar: '#070b13', side: '#101a2b', line: '#23324d', tx: '#e8eef8', tx2: '#8e9bb3', acc: '#dbb65e', ink: '#1a1305', link: '#7fb2ff' } },
    { id: 'legion', name: 'Legion', group: 'expansion', family: 'forged', desc: 'Fel green and demon violet',
      c: { bg: '#0e0b12', bar: '#08060b', side: '#15111b', line: '#2d2537', tx: '#ecf3e6', tx2: '#9b94a6', acc: '#84d936', ink: '#0e1a04', link: '#b88cff' } },
    { id: 'wod', name: 'Warlords of Draenor', group: 'expansion', family: 'forged', desc: 'Rusted iron and fire',
      c: { bg: '#14110f', bar: '#0b0908', side: '#1c1815', line: '#3a3029', tx: '#f1e6dc', tx2: '#a8998c', acc: '#c9702c', ink: '#ffffff', link: '#e49a55' } },
    { id: 'mop', name: 'Mists of Pandaria', group: 'expansion', family: 'regal', desc: 'Jade and temple gold',
      c: { bg: '#0e1513', bar: '#08100e', side: '#13201b', line: '#24392f', tx: '#e8f2ec', tx2: '#8fa69a', acc: '#2fbf8f', ink: '#04221a', link: '#e3b45a' } },
    { id: 'cata', name: 'Cataclysm', group: 'expansion', family: 'forged', desc: 'Molten fire on charcoal',
      c: { bg: '#141110', bar: '#0b0908', side: '#1b1715', line: '#3a2c25', tx: '#f2e8e2', tx2: '#a8968c', acc: '#ff7a1f', ink: '#1a0a00', link: '#ffaa5c' } },
    { id: 'wotlk', name: 'Wrath of the Lich King', group: 'expansion', family: 'regal', desc: 'Frost and ice',
      c: { bg: '#0a1119', bar: '#060b11', side: '#0e1823', line: '#1f3449', tx: '#e6f3fc', tx2: '#8aa3b8', acc: '#7cc8f2', ink: '#04121c', link: '#a8dcff' } },
    { id: 'tbc', name: 'The Burning Crusade', group: 'expansion', family: 'forged', desc: 'Fel green and Outland red',
      c: { bg: '#0f130e', bar: '#080b07', side: '#141a13', line: '#2a3627', tx: '#e8f2e0', tx2: '#93a28b', acc: '#74d93f', ink: '#0b1a03', link: '#ff7a4a' } },
    { id: 'classic', name: 'Classic', group: 'expansion', family: 'regal', desc: 'Old-school gold and stone',
      c: { bg: '#1a1611', bar: '#110e0a', side: '#221d16', line: '#3d3427', tx: '#f2e8d4', tx2: '#a8987c', acc: '#f2c230', ink: '#1d1503', link: '#f5d36a' } },

    { id: 'ember', name: 'Ember', group: 'style', family: 'forged', desc: 'Black iron and Horde red',
      c: { bg: '#111112', bar: '#08080a', side: '#161618', line: '#2a2a2d', tx: '#f1f1f1', tx2: '#8b8b92', acc: '#e0402e', ink: '#ffffff', link: '#ff6a58', forever: '#5fb4ff' },
      extra: { 'acc-soft': '#2a1513', 'acc-text': '#ff8a7a', 'icon-bg': '#232326', 'icon-bg-forever': '#232326', 'tag-bg': '#222225', gsel: '#222225', 'news-bg': '#1d1314', sel: '#1c1c1f', hover: '#18181b', line2: '#1e1e21', 'btn-line': '#444448', ok: '#7fd37f' } },
    { id: 'ledger', name: 'Gold ledger', group: 'style', family: 'regal', desc: 'Dark leather and gold trim',
      c: { bg: '#17120d', bar: '#0f0c09', side: '#1c1610', line: '#3d301d', tx: '#ece2cc', tx2: '#a39276', acc: '#d6a84a', ink: '#1a1206', link: '#c9a456', forever: '#a9c0dc' },
      extra: { 'acc-soft': '#3a2a12', 'acc-text': '#f0d08a', 'icon-bg': '#221a11', 'icon-bg-forever': '#151a20', 'icon-border': '#8c6a2a', frame: '#6b5228', 'btn-line': '#6b5228', gsel: '#2a2016', sel: '#261d13', hover: '#1f1811', 'news-bg': '#1f1811', 'news-line': '#3d301d', line2: '#281f15', ok: '#9cb874', 'brand-tx': '#e9cf8f' } },
    { id: 'slate', name: 'Slate', group: 'style', family: 'clean', desc: 'Clean and modern',
      c: { bg: '#1c1f24', bar: '#15171b', side: '#202429', line: '#2e333a', tx: '#e8eaed', tx2: '#8a919b', acc: '#3cc2a6', ink: '#062a23', link: '#3cc2a6', forever: '#a99cf0' },
      extra: { 'acc-soft': '#1f3a35', 'acc-text': '#5fe0c4', 'icon-bg': '#1f3a35', 'icon-bg-forever': '#2b2944', 'emb-bg': '#1f3a35', 'emb-tx': '#3cc2a6', gsel: '#2a2f36', sel: '#252a31', hover: '#21252a', 'tag-bg': '#2a2f36', 'news-bg': '#1f2b2a', 'news-line': '#2c4743', line2: '#262a30', 'btn-line': '#3a4048', ok: '#6fcf97', 'frame-top': '#2e333a' } },
    { id: 'journal', name: 'Field journal', group: 'style', family: 'parchment', desc: 'Parchment and wax seals', light: true,
      c: { bg: '#f2e8d3', bar: '#e6d8b9', side: '#eadfc5', line: '#c9b48a', tx: '#3a2817', tx2: '#7b6445', acc: '#9b2d24', ink: '#fff1e0', link: '#9b2d24', forever: '#2f4b5a' },
      extra: { 'acc-soft': '#9b2d24', 'acc-text': '#fff1e0', 'icon-bg': '#efe3c8', 'icon-bg-forever': '#e4e6dc', 'icon-tx': '#5a3e22', 'icon-border': '#8a6d45', 'play-bg': '#3a2817', 'play-tx': '#f2e8d3', gsel: '#e2d3b0', sel: '#e9dcbd', hover: '#efe4cc', 'news-bg': '#f7efdd', 'news-line': '#b89c69', line2: '#ddcfae', 'btn-line': '#3a2817', input: '#fbf6ea', panel: '#f6eedc', 'menu-bg': '#f6eedc', ok: '#4f6b2c', warn: '#9a6a12', 'warn-line': '#c9a35a', frame: '#b89c69', 'frame-top': '#b89c69', 'tag-bg': 'transparent', 'tx-strong': '#2a1c0f', dim: '#b3a07f' } }
  ]
};

// Warchief Launcher: screens and behaviour.
// Install, update, repair, roll back, uninstall and Play work on the real AddOns folder (installer.js).
// Layout: title bar (menu, back/forward, tabs, bell), the My Addons bar, the selected addon on the left with the
// big Update / Play button, and Home / News / To-do / Help / Options on the right.
(function () {
  'use strict';

  const D = window.WL_DATA;
  const V = window.WLVersion;
  const LS_SET = 'wl.settings.v1';
  const LS_PREV = 'wl.activity.v1'; // the activity log (the old pretend install data under wl.preview.v1 is no longer used)

  const app = document.getElementById('app');
  const side = document.getElementById('side');
  const main = document.getElementById('main');
  const bar = document.getElementById('addonbar');
  const menuEl = document.getElementById('menu');
  const overlay = document.getElementById('overlay');
  const modalEl = document.getElementById('modal');
  const toastEl = document.getElementById('toast');
  const tbAcct = document.getElementById('tb-acct');
  const bellDot = document.getElementById('bell-dot');
  const grip = document.getElementById('grip');

  // Stand-ins so the screens also open in a normal browser for previews.
  const api = window.api || {
    isElectron: false,
    minimize: async () => toast('Minimize works in the app.'),
    toTray: async () => toast('Minimize to tray works in the app.'),
    exit: async () => toast('Close works in the app.'),
    info: async () => ({ version: D.launcher.version, electron: 'browser preview', os: navigator.platform, arch: '' }),
    openExternal: async (url) => { window.open(url, '_blank', 'noopener'); },
    pickFolder: async () => 'E:\\Blizzard Downloads\\World of Warcraft\\_classic_beta_',
    checkFolder: async (p) => {
      const ok = /^E:\\/.test(p) || p === 'C:\\Program Files (x86)\\World of Warcraft\\_retail_';
      return { path: p, exists: ok, looksLikeWow: ok, addons: p + '\\Interface\\AddOns' };
    },
    detectFolders: async () => ({ retail: ['C:\\Program Files (x86)\\World of Warcraft\\_retail_'] }),
    setLoginItem: async () => {}
  };
  // Launcher updates, the tray, the Discord panel and the community parts only exist in the app; the browser preview
  // gets harmless stand-ins.
  for (const [k, v] of Object.entries({
    updateGet: async () => ({ state: 'idle', packaged: false }), updateMode: async () => {}, updateCheck: async () => ({ state: 'idle', packaged: false }),
    updateDownload: async () => ({ state: 'idle' }), updateRestart: async () => false, updateLatest: async () => ({ error: 'browser' }), onUpdate: () => {}, setTray: async () => {}, onTray: () => {},
    acctGet: async () => ({ service: false, loggedIn: false }), acctLogin: async () => ({ error: 'not-set-up' }), acctCancel: async () => {},
    acctLogout: async () => ({ service: false, loggedIn: false }), acctDownload: async () => ({ ok: true }), acctReport: async () => ({ ok: false, error: 'Bug reports work in the app.' }),
    community: async () => ({ ok: false, status: 0 }),
    instCatalog: async () => {}, instScan: async () => ({ ok: true, items: {} }), onInstProgress: () => {},
    instRun: async () => ({ ok: false, error: 'Installing works in the app.' }), instPlay: async () => ({ ok: false, error: 'Play works in the app.' }), instOpenFolder: async () => false,
    dwSet: async () => true, onDwDo: () => {}, grip: async () => {}
  })) if (!api[k]) api[k] = v;

  // ---------- Settings and the activity log ----------
  function defaultDirs() {
    const o = {};
    D.games.forEach(g => { o[g.id] = ['C:\\Program Files (x86)\\World of Warcraft\\' + g.folder]; });
    return o;
  }
  function defaultSettings() {
    const ug = {};
    D.games.forEach(g => { ug[g.id] = true; });
    return {
      theme: D.defaultTheme, language: 'en', startWithWindows: false, onClose: 'tray', onLaunch: 'tray',
      channel: 'stable', updateGames: ug, addonUpdates: 'auto', launcherUpdates: 'auto',
      keepBackups: true, backupCount: 2,
      notify: { enabled: true, addonUpdates: true, news: true, launcher: true, beta: true },
      dirs: defaultDirs(), firstRun: true, showWidget: true,
      // Discord panel: docked (stuck to the launcher), popped (its own window) or closed
      discordMode: '',
      // What the bell has already shown
      seen: { news: '', feed: '', cards: null, upd: {} },
      lastAddon: '', lastGame: ''
    };
  }
  function defaultActivity() { return { log: [] }; }
  function merge(base, extra) {
    if (Array.isArray(base)) return Array.isArray(extra) ? extra : base;
    if (base && typeof base === 'object') {
      if (!extra || typeof extra !== 'object') return base;
      const out = { ...base };
      for (const k of Object.keys(extra)) out[k] = k in base ? merge(base[k], extra[k]) : extra[k];
      return out;
    }
    return extra === undefined ? base : extra;
  }
  function load(key, fallback) {
    try { const raw = localStorage.getItem(key); return raw ? merge(fallback, JSON.parse(raw)) : fallback; }
    catch { return fallback; }
  }
  function save(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch { /* storage unavailable */ } }

  let S = load(LS_SET, defaultSettings());
  let P = load(LS_PREV, defaultActivity());
  if (!D.themes.some(t => t.id === S.theme)) S.theme = D.defaultTheme;
  if (!['docked', 'popped', 'closed'].includes(S.discordMode)) S.discordMode = S.showWidget === false ? 'closed' : 'docked';
  if (!S.seen || typeof S.seen !== 'object') S.seen = { news: '', feed: '', cards: null, upd: {} };

  const st = {
    view: 'home', game: S.lastGame || '', sel: S.lastAddon || 'wwd', page: 'general', dir: {}, dirsChecked: false, busy: {},
    checkingUpdates: false, inst: {}, scanned: false, hist: [], fut: [], slide: 0, paused: false,
    votes: { counts: {}, mine: {} }, feed: [], voting: {}
  };
  // What's really in each game's AddOns folder (read from the .toc files by installer.js)
  const installedOf = p => { const r = p && st.inst[p.id]; return r && r.installed ? (r.version || '?') : null; };
  const backupsOfP = p => ((p && st.inst[p.id]) || {}).backups || [];
  let modalOk = null;
  let toastTimer = null;

  // ---------- Helpers ----------
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ti = n => `<i class="ti ti-${n}" aria-hidden="true"></i>`;
  const game = id => D.games.find(g => g.id === id);
  const prod = id => D.products.find(p => p.id === id);
  const getPath = (o, path) => path.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
  function setPath(o, path, v) {
    const ks = path.split('.'); const last = ks.pop();
    const t = ks.reduce((a, k) => (a[k] = a[k] || {}), o);
    t[last] = v;
  }
  function fmtTime(t) { return new Date(t).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }); }
  const fmtShort = t => new Date(t).toLocaleDateString([], { month: 'short', day: 'numeric' }).toUpperCase();
  const timeOf = t => { const n = Date.parse(t || ''); return isNaN(n) ? 0 : n; };
  function log(text) { P.log.unshift({ t: Date.now(), text }); P.log = P.log.slice(0, 200); }
  function toast(msg) {
    toastEl.textContent = msg; toastEl.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { toastEl.hidden = true; }, 3400);
  }

  // ---------- Themes ----------
  function hex(c) { const h = c.replace('#', ''); return [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16)); }
  function mix(a, b, w) {
    const A = hex(a), B = hex(b);
    return '#' + A.map((x, i) => Math.round(x * w + B[i] * (1 - w)).toString(16).padStart(2, '0')).join('');
  }
  function themeVars(t) {
    const c = t.c, light = !!t.light;
    const v = {
      bg: c.bg, bar: c.bar, side: c.side, panel: c.side, 'menu-bg': c.side,
      line: c.line, line2: mix(c.line, c.bg, 0.45),
      tx: c.tx, 'tx-strong': light ? c.tx : mix('#ffffff', c.tx, 0.6), tx2: c.tx2, dim: mix(c.tx2, c.bg, 0.5),
      acc: c.acc, 'acc-ink': c.ink, 'acc-soft': mix(c.acc, c.bg, 0.16), 'acc-text': mix(c.acc, '#ffffff', 0.7), link: c.link,
      ok: '#7fd39a', warn: '#f2b84b', 'warn-line': mix('#f2b84b', c.bg, 0.45), danger: '#d9483b', bad: '#c0392b',
      hover: mix(c.tx, c.bg, 0.04), sel: mix(c.tx, c.bg, 0.075), input: mix('#000000', c.bg, 0.3),
      'btn-line': mix(c.tx, c.bg, 0.28), frame: c.line, 'frame-top': c.frameTop || c.acc,
      'emb-bg': c.acc, 'emb-tx': c.ink, 'icon-bg': mix(c.tx, c.bg, 0.08), 'icon-bg-forever': mix(c.tx, c.bg, 0.08),
      'icon-tx': c.acc, 'icon-border': mix(c.acc, c.bg, 0.5), 'play-bg': c.acc, 'play-tx': c.ink,
      gsel: mix(c.tx, c.side, 0.08), 'news-bg': mix(c.acc, c.side, 0.1), 'news-line': c.acc,
      'tag-bg': mix(c.tx, c.bg, 0.09), 'tag-tx': mix(c.tx2, c.tx, 0.8), 'g-forever': c.forever || '#7fb8ff',
      'brand-tx': light ? c.tx : mix('#ffffff', c.tx, 0.6),
      // Home screen: the addon's name under its art, the picture areas, the banner
      'wm-small': light ? c.acc : mix(c.acc, c.tx, 0.55), 'wm-big': light ? c.tx : mix(c.acc, '#ffffff', 0.55),
      tile: mix(c.frameTop || c.acc, c.side, 0.07), dots: c.line,
      banner: light ? mix(c.acc, c.bg, 0.12) : mix(c.frameTop || c.acc, c.bg, 0.22),
      shadow: light ? '0 8px 24px rgba(60,40,20,.18)' : '0 10px 30px rgba(0,0,0,.5)',
      scheme: light ? 'light' : 'dark'
    };
    return Object.assign(v, t.extra || {});
  }
  function applyTheme() {
    const t = D.themes.find(x => x.id === S.theme) || D.themes[0];
    app.removeAttribute('style');
    app.dataset.family = t.family;
    app.dataset.theme = t.id;
    const vars = themeVars(t);
    for (const k of Object.keys(vars)) app.style.setProperty('--' + k, vars[k]);
    for (const k of Object.keys(t.fonts || {})) app.style.setProperty('--' + k, t.fonts[k]);
    document.body.style.background = vars.bg;
  }

  // ---------- Status ----------
  function latestOf(p) { return S.channel === 'beta' && canBeta() && p.beta && V.cmp(p.beta, p.latest) > 0 ? p.beta : p.latest; }
  function isBeta(p) { return latestOf(p) !== p.latest; }
  function dirOk(path) { const r = st.dir[path]; return !!(r && r.exists && r.looksLikeWow); }
  function installDir(gid) { return (S.dirs[gid] || []).find(dirOk) || null; }
  function statusOf(p) {
    if (st.busy[p.id]) return 'busy';
    if (!st.dirsChecked) return 'checking';
    if (!installDir(p.game)) return 'folder';
    if (!st.scanned) return 'checking';
    const inst = installedOf(p);
    const outdated = !inst || V.cmp(inst, latestOf(p)) < 0;
    if (outdated) {
      const lock = lockOf(p, isBeta(p));
      if (lock === 'wait') return 'checking';
      if (lock) return inst ? 'locked-update' : 'locked-install';
    }
    if (!inst) return 'install';
    if (outdated) return 'update';
    return p.type === 'main' ? 'play' : 'ok';
  }

  // ---------- Which game and addon are picked ----------
  function curGame() {
    if (game(st.game)) return st.game;
    const withAddons = D.games.find(g => D.products.some(p => p.game === g.id));
    return (withAddons || D.games[0] || {}).id || '';
  }
  const gameProducts = gid => D.products.filter(p => p.game === gid).sort((a, b) => (a.type === 'main' ? 0 : 1) - (b.type === 'main' ? 0 : 1));
  function curProduct() {
    const list = gameProducts(curGame());
    return list.find(p => p.id === st.sel) || list[0] || null;
  }

  // ---------- Render ----------
  const SCROLLERS = '.home, .page, .newsview';
  function render() {
    const keep = main.querySelector(SCROLLERS);
    const top = keep ? keep.scrollTop : 0;
    applyTheme();
    const p = curProduct();
    if (p) st.sel = p.id;
    for (const [v, a] of [['home', 'go-home'], ['news', 'go-news'], ['todo', 'go-todo'], ['help', 'go-help']]) {
      document.querySelector(`.tab[data-action="${a}"]`).classList.toggle('on', st.view === v);
    }
    document.querySelector('[data-action="nav-back"]').disabled = !st.hist.length;
    document.querySelector('[data-action="nav-fwd"]').disabled = !st.fut.length;
    bar.innerHTML = addonBar();
    side.className = 'side' + (st.view === 'options' ? ' opts' : '');
    side.innerHTML = st.view === 'options' ? sideOptions() : sideArt(p);
    main.innerHTML = st.view === 'home' ? mainHome() : st.view === 'news' ? mainNews() : st.view === 'todo' ? mainTodo() : st.view === 'help' ? mainHelp() : mainOptions();
    tbAcct.innerHTML = titleAccount();
    grip.hidden = S.discordMode === 'docked';
    paintBell();
    syncWidget();
    const again = main.querySelector(SCROLLERS);
    if (again && keep && keep.className === again.className) again.scrollTop = top;
    syncTray();
    tickBanner();
  }

  // Moving between pages, with Back and Forward like a browser
  function go(view, extra) {
    const now = { view: st.view, page: st.page };
    const next = { view, page: (extra && extra.page) || st.page };
    if (now.view !== next.view || (view === 'options' && now.page !== next.page)) { st.hist.push(now); st.hist = st.hist.slice(-30); st.fut = []; }
    st.view = view; st.page = next.page;
    render();
  }
  function navBack() { const h = st.hist.pop(); if (!h) return; st.fut.push({ view: st.view, page: st.page }); st.view = h.view; st.page = h.page; render(); }
  function navFwd() { const h = st.fut.pop(); if (!h) return; st.hist.push({ view: st.view, page: st.page }); st.view = h.view; st.page = h.page; render(); }

  // ---------- My Addons bar: up to 5 icons, the rest behind the + ----------
  const BAR_MAX = 5;
  function iconHtml(p, cls) {
    if (p.iconUrl) return `<span class="${cls} img"><img src="${esc(p.iconUrl)}" alt=""></span>`;
    if (p.icon === 'logo') return `<span class="${cls} img"><img src="../assets/wwd_logo_transparent.png" alt=""></span>`;
    return `<span class="${cls} badge g-${esc(p.game)}">${esc(p.short)}</span>`;
  }
  function addonBar() {
    const gid = curGame();
    const list = gameProducts(gid);
    if (!list.length) {
      const msg = !st.catalogSource ? 'Loading the addon list…' : st.catalogSource === 'none' ? "Couldn't load the addon list" : `No addons for ${(game(gid) || {}).name || 'this game'} yet`;
      return `<span class="ab-label">MY ADDONS</span><span class="ab-empty">${esc(msg)}</span>`;
    }
    const shown = list.slice(0, BAR_MAX);
    const sel = curProduct();
    const items = shown.map(p => {
      const s = statusOf(p), inst = installedOf(p);
      const missing = st.scanned && !inst && s !== 'busy';
      const badge = s === 'busy' ? `<span class="ab-badge busy">${ti('loader-2')}</span>`
        : s === 'update' || s === 'locked-update' ? `<span class="ab-badge">${ti('arrow-down')}</span>` : '';
      const label = `${p.name}${missing ? ' (not installed)' : s === 'update' ? ' (update ready)' : ''}`;
      return `<button class="ab-item ${sel && sel.id === p.id ? 'on' : ''} ${missing ? 'missing' : ''}" data-action="select" data-id="${esc(p.id)}" title="${esc(p.name)}" aria-label="${esc(label)}">${iconHtml(p, 'ab-icon')}${badge}</button>`;
    }).join('');
    const more = list.length > BAR_MAX ? `<button class="ab-plus" data-action="menu" data-menu="plugins" aria-label="More plugins"><span>${ti('plus')}</span></button>` : '';
    return `<span class="ab-label">MY ADDONS</span>${items}${more}`;
  }

  // ---------- Left column: the addon's art, game version, release, and the big button ----------
  function wordmark(p) {
    const name = String(p.name || '');
    const dash = name.split(/\s+-\s+/);
    if (dash.length > 1) return [dash[0], dash.slice(1).join(' - ')];
    const w = name.split(/\s+/);
    return w.length > 2 ? [w[0], w.slice(1).join(' ')] : ['', name];
  }
  function sideArt(p) {
    const gid = curGame();
    const gameSel = `<select class="pb-select" data-action-change="game" aria-label="Game version">${D.games.map(g => `<option value="${esc(g.id)}" ${g.id === gid ? 'selected' : ''}>${esc(g.title)}</option>`).join('')}</select>`;
    if (!p) {
      return `<div class="art"><img class="art-logo" src="../assets/wwd_logo_transparent.png" alt=""><span class="art-big">WAR DIARY</span></div>
        <div class="playbox"><span class="pb-label">GAME VERSION</span>${gameSel}</div>`;
    }
    const [small, big] = wordmark(p);
    const art = p.iconUrl || p.icon === 'logo'
      ? `<img class="art-logo" src="${esc(p.iconUrl || '../assets/wwd_logo_transparent.png')}" alt="${esc(p.name)}">`
      : `<span class="art-badge g-${esc(p.game)}" role="img" aria-label="${esc(p.name)}">${esc(p.short)}</span>`;
    const rel = [`<option value="stable" ${!isBeta(p) ? 'selected' : ''}>${esc(p.latest)} · Latest release</option>`];
    if (p.beta && V.cmp(p.beta, p.latest) > 0) {
      rel.push(canBeta() ? `<option value="beta" ${isBeta(p) ? 'selected' : ''}>${esc(p.beta)} · Beta</option>` : `<option value="beta-locked">${esc(p.beta)} · Beta (for Testers)</option>`);
    }
    return `<img class="art-mark" src="../assets/wwd_logo_transparent.png" alt="">
      <div class="art">${art}${small ? `<span class="art-small">${esc(small.toUpperCase())}</span>` : ''}<span class="art-big">${esc(big.toUpperCase())}</span></div>
      <div class="playbox" id="playbox">
        <span class="pb-label">GAME VERSION &amp; RELEASE</span>
        ${gameSel}
        <select class="pb-select" data-action-change="channel" aria-label="Release">${rel.join('')}</select>
        ${playButton(p)}
      </div>`;
  }
  function playButton(p) {
    const s = statusOf(p), inst = installedOf(p);
    const gear = `<button class="split-gear" data-action="menu" data-menu="gear" aria-label="Addon options: check for updates, repair, roll back, uninstall">${ti('settings')}</button>`;
    let btn, cls = '', note = '';
    switch (s) {
      case 'checking': btn = `<button class="split-main" disabled>${ti('loader-2')} Checking…</button>`; cls = 'quiet'; break;
      case 'busy': {
        const b = st.busy[p.id];
        btn = `<div class="split-main busy" role="progressbar" aria-valuenow="${Math.round(b.pct)}" aria-valuemin="0" aria-valuemax="100"><span class="split-bar" style="width:${Math.round(b.pct)}%"></span><span class="split-txt">${esc(b.label)} ${Math.round(b.pct)}%</span></div>`;
        cls = 'quiet'; break;
      }
      case 'folder': btn = `<button class="split-main" data-action="goto-dirs">${ti('alert-triangle')} Set folder</button>`; cls = 'warn'; note = 'Game folder not found. Set it in Options, Directories.'; break;
      case 'install': btn = `<button class="split-main" data-action="install" data-id="${esc(p.id)}">${ti('download')} Install</button>`; note = `Not installed · Latest ${esc(latestOf(p))}`; break;
      case 'update': btn = `<button class="split-main" data-action="update" data-id="${esc(p.id)}">${ti('download')} Update</button>`; note = `Update ready: ${esc(latestOf(p))} · Installed ${esc(inst)}`; break;
      case 'locked-install': case 'locked-update': {
        const w = lockOf(p, isBeta(p));
        btn = `<button class="split-main" data-action="locked" data-id="${esc(p.id)}" title="${esc(LOCK_TIP[w] || '')}">${ti('lock')} ${s === 'locked-update' ? 'Update' : 'Install'}</button>`;
        cls = 'locked'; note = LOCK_TIP[w] || ''; break;
      }
      default:
        btn = `<button class="split-main" data-action="play" data-id="${esc(p.id)}">${ti('player-play')} Play</button>`;
        note = `Version: ${esc(inst)}${isBeta(p) ? ' (beta)' : ''}`;
    }
    return `<div class="split ${cls}" id="status-${esc(p.id)}">${btn}${gear}</div><span class="pb-status">${note}</span>`;
  }
  function paintStatus(p) {
    const box = document.getElementById('status-' + p.id);
    if (box) {
      const tmp = document.createElement('div'); tmp.innerHTML = playButton(p);
      box.replaceWith(tmp.firstElementChild);
      const n = document.querySelector('#playbox .pb-status'); if (n && tmp.lastElementChild) n.innerHTML = tmp.lastElementChild.innerHTML;
    }
    bar.innerHTML = addonBar();
  }

  // ---------- Home ----------
  const MD = window.WLMarkdown;
  const hasLink = n => n.link && n.link !== 'none';
  const fmtDate = t => new Date(t).toLocaleDateString([], { month: 'long', day: 'numeric', year: 'numeric' });
  function mainHome() {
    return `<div class="home">${linkRow()}${slider()}${banner()}${latest()}</div>`;
  }
  function linkRow() {
    const ext = ti('arrow-up-right');
    const chips = [];
    if (D.access && D.access.bugReports) chips.push(`<button class="chipbtn" data-action="report-bug">${ti('bug')} Report a bug</button>`);
    if (inviteUrl()) chips.push(`<button class="chipbtn" data-action="join-discord">${ti('brand-discord')} Discord <span class="ext">${ext}</span></button>`);
    for (const [k, label] of [['curseforge', 'CurseForge'], ['github', 'GitHub']]) if (D.links[k]) chips.push(`<button class="chipbtn" data-action="open-link" data-link="${k}">${label} <span class="ext">${ext}</span></button>`);
    const p = curProduct();
    if (p) chips.push(`<button class="chipbtn" data-action="changelog" data-id="${esc(p.id)}">${ti('list')} Release notes</button>`);
    chips.push(`<button class="chipbtn icon" data-action="menu" data-menu="more" aria-label="More links">${ti('dots')}</button>`);
    return `<div class="linkrow">${chips.join('')}</div>`;
  }

  // The big news slider: the newest posts, one at a time
  function slides() { return (D.news || []).slice(0, 5); }
  function slider() {
    const list = slides();
    const p = curProduct();
    const [small, big] = p ? wordmark(p) : ['WARCHIEFS', 'WAR DIARY'];
    const art = (title) => `<div class="slide-art"><img src="${esc((p && p.iconUrl) || '../assets/wwd_logo_transparent.png')}" alt="">
      <div class="slide-mark">${small ? `<span class="sm1">${esc(small.toUpperCase())}</span>` : ''}<span class="sm2">${esc(big.toUpperCase())}</span>${title ? `<span class="sm3">${esc(title.toUpperCase())}</span>` : ''}</div></div>`;
    if (!list.length) {
      return `<div class="slider-wrap"><div class="slider">${art('')}<div class="slide-text"><span class="kicker">WELCOME</span><span class="slide-title">Warchief Launcher</span>
        <span class="slide-body">Install, update and play Warchiefs War Diary and its plugins. News from the Warchief team shows up here.</span></div></div></div>`;
    }
    const i = Math.min(st.slide, list.length - 1);
    const n = list[i];
    const body = MD.excerpt(n.body, 260);
    const link = hasLink(n) ? `<button class="sbtn" data-action="open-link" data-link="${esc(n.link)}">${esc(n.linkLabel || 'Open')} ${ti('arrow-up-right')}</button>` : '';
    return `<div class="slider-wrap"><div class="slider" aria-roledescription="slide" aria-label="${i + 1} of ${list.length}">${art(n.title.split(/\s+/).slice(-2).join(' '))}
        <div class="slide-text"><span class="kicker">NEWS${n.date ? ' · ' + esc(fmtShort(n.date)) : ''}</span><span class="slide-title">${esc(n.title)}</span>
          ${body ? `<span class="slide-body">${esc(body)}</span>` : ''}<span class="grow"></span>
          <div class="slide-actions"><button class="pbtn wide" data-action="go-news" data-post="${esc(n.id || '')}">Read more</button>${link}</div></div></div>
      ${list.length > 1 ? `<div class="slide-ctl"><button class="slide-pause" data-action="slide-pause" aria-label="${st.paused ? 'Play the slideshow' : 'Pause the slideshow'}">${ti(st.paused ? 'player-play' : 'player-pause')}</button>
        <div class="slide-dots">${list.map((_, k) => `<button class="sdot ${k === i ? 'on' : ''}" data-action="slide" data-i="${k}" aria-label="Show news ${k + 1}"></button>`).join('')}</div><span class="slide-pad"></span></div>` : ''}</div>`;
  }
  setInterval(() => {
    if (st.paused || st.view !== 'home' || !overlay.hidden || document.hidden) return;
    const n = slides().length; if (n < 2) return;
    if (main.matches(':hover') && document.querySelector('.slider:hover')) return; // reading it
    st.slide = (st.slide + 1) % n;
    const w = main.querySelector('.slider-wrap'); if (!w) return;
    const t = document.createElement('div'); t.innerHTML = slider(); w.replaceWith(t.firstElementChild);
  }, 8000);

  // The banner with a countdown, set on the Admin's Launcher home page
  function bannerInfo() {
    const b = (D.home && D.home.banner) || {};
    if (!b.on || !b.title) return null;
    const until = timeOf(b.until);
    return { ...b, until };
  }
  function countdown(until) {
    let left = Math.max(0, until - Date.now());
    const d = Math.floor(left / 86400000); left -= d * 86400000;
    const h = Math.floor(left / 3600000); left -= h * 3600000;
    const m = Math.floor(left / 60000); left -= m * 60000;
    const s = Math.floor(left / 1000);
    return [d, h, m, s].map(x => String(x).padStart(2, '0'));
  }
  function banner() {
    const b = bannerInfo();
    if (!b) return '';
    const live = b.until > Date.now();
    const cd = live ? countdown(b.until) : null;
    const unit = (v, l, k) => `<span class="cd-unit"><span class="cd-num" data-cd="${k}">${v}</span><span class="cd-lbl">${l}</span></span>`;
    const btn = b.button && b.link ? `<button class="pbtn" data-action="open-link" data-link="${esc(b.link)}">${esc(b.button)}</button>` : '';
    return `<div class="banner"><span class="banner-icon">${ti('calendar-event')}</span>
      <div class="banner-text"><span class="banner-title">${esc(b.title)}</span>${b.text ? `<span class="banner-sub">${esc(b.text)}</span>` : ''}</div>
      ${cd ? `<div class="cd" data-until="${b.until}">${unit(cd[0], 'DAYS', 0)}<span class="cd-sep">:</span>${unit(cd[1], 'HR', 1)}<span class="cd-sep">:</span>${unit(cd[2], 'MIN', 2)}<span class="cd-sep">:</span>${unit(cd[3], 'SEC', 3)}</div>` : ''}
      ${btn}</div>`;
  }
  function tickBanner() {
    const el = main.querySelector('.cd[data-until]'); if (!el) return;
    const until = Number(el.dataset.until);
    if (until <= Date.now()) { if (st.view === 'home') { const w = main.querySelector('.banner'); if (w) { const t = document.createElement('div'); t.innerHTML = banner(); w.replaceWith(t.firstElementChild || document.createTextNode('')); } } return; }
    const v = countdown(until);
    el.querySelectorAll('[data-cd]').forEach(n => { n.textContent = v[Number(n.dataset.cd)]; });
  }
  setInterval(tickBanner, 1000);

  // Latest: up to 6 news posts, to-do cards and Discord posts, newest first
  function latestItems() {
    const items = [];
    for (const n of D.news || []) items.push({ kind: 'news', at: timeOf(n.date), title: n.title, post: n.id || '', date: n.date });
    for (const c of (D.roadmap || { columns: [] }).columns) {
      for (const k of c.cards) items.push({ kind: 'todo', at: timeOf(k.at) || timeOf(D.publishedAt), title: k.title, card: k, col: c });
    }
    for (const f of st.feed) items.push({ kind: 'discord', at: timeOf(f.at), title: f.title, channel: f.channel, url: f.url });
    return items.sort((a, b) => b.at - a.at).slice(0, 6);
  }
  function miniBoard(col) {
    const cols = (D.roadmap || { columns: [] }).columns.slice(0, 5);
    return `<div class="tile board-tile">${cols.map(c => `<div class="mb-col ${c === col ? 'on' : ''}"><span class="mb-dot" style="background:${BOARD_COLOR[c.color] || BOARD_COLOR.gray}"></span>${c.cards.slice(0, 3).map(() => '<span class="mb-card"></span>').join('')}</div>`).join('')}</div>`;
  }
  function latest() {
    const items = latestItems();
    if (!items.length) return '';
    const p = curProduct();
    const cards = items.map(it => {
      if (it.kind === 'news') {
        return `<button class="lcard" data-action="go-news" data-post="${esc(it.post)}"><div class="tile dots"><img src="${esc((p && p.iconUrl) || '../assets/wwd_logo_transparent.png')}" alt=""></div>
          <div class="lcap"><span class="lcap-text"><span class="kicker">NEWS${it.date ? ' · ' + esc(fmtShort(it.date)) : ''}</span><span class="ltitle">${esc(it.title)}</span></span></div></button>`;
      }
      if (it.kind === 'discord') {
        return `<div class="lcard"><button class="lcard-hit" data-action="open-url-keep" data-url="${esc(it.url)}" aria-label="${esc(it.title)} (opens Discord)"></button><div class="tile dots discord">${ti('message-circle')}<span>#${esc(it.channel)}</span></div>
          <div class="lcap"><span class="lcap-text"><span class="kicker">DISCORD · #${esc(String(it.channel).toUpperCase())}</span><span class="ltitle">${esc(it.title)}</span></span><span class="ext big">${ti('arrow-up-right')}</span></div></div>`;
      }
      return `<div class="lcard"><button class="lcard-hit" data-action="go-todo" aria-label="${esc(it.title)} (open the To-do board)"></button>${miniBoard(it.col)}
        <div class="lcap"><span class="lcap-text"><span class="kicker">TO-DO · ${esc(it.col.name.toUpperCase())}</span><span class="ltitle">${esc(it.title)}</span></span>${votePill(it.card.id)}</div></div>`;
    }).join('');
    return `<div class="latest-head"><span class="sect">Latest</span><span class="muted small">News, to-do updates and Discord posts</span></div><div class="latest">${cards}</div>`;
  }

  // ---------- Votes on to-do cards ----------
  function votePill(id) {
    const c = st.votes.counts[id] || { up: 0, down: 0 };
    const mine = st.votes.mine[id] || 0;
    const busy = st.voting[id] ? ' busy' : '';
    return `<span class="vote${busy}" title="${c.up} up · ${c.down} down">
      <button class="vbtn up ${mine === 1 ? 'on' : ''}" data-action="vote" data-card="${esc(id)}" data-v="1" aria-label="Vote up" aria-pressed="${mine === 1}">${ti('caret-up')}</button>
      <span class="vcount">${c.up - c.down}</span>
      <button class="vbtn down ${mine === -1 ? 'on' : ''}" data-action="vote" data-card="${esc(id)}" data-v="-1" aria-label="Vote down" aria-pressed="${mine === -1}">${ti('caret-down')}</button></span>`;
  }
  async function vote(card, v) {
    if (!AC.loggedIn) return showModal(`<h2>Log in to vote</h2><p>Log in with Discord to vote on the To-do board. It's free for members of the Warchief Discord, and one vote per person keeps it fair.</p>
      <div class="actions"><button class="sbtn" data-action="close-modal">Not now</button><button class="pbtn" data-action="login">${ti('brand-discord')} Log in with Discord</button></div>`);
    if (AC.me && !AC.me.inServer) return lockModal(null, 'member');
    if (st.voting[card]) return;
    const want = (st.votes.mine[card] || 0) === v ? 0 : v;
    st.voting[card] = true; render();
    let r = null;
    try { r = await api.community('vote', { card, vote: want }); } catch { r = null; }
    delete st.voting[card];
    if (r && r.ok && r.data) {
      if (r.data.counts) st.votes.counts = r.data.counts;
      if (want) st.votes.mine[card] = want; else delete st.votes.mine[card];
    } else {
      const need = r && r.data && r.data.need;
      if (need === 'login') { await refreshAccount(true); render(); return vote(card, v); }
      if (need === 'member') { render(); return lockModal(null, 'member'); }
      toast((r && r.data && r.data.error) || "Couldn't save your vote right now. Try again in a minute.");
    }
    render();
  }
  async function loadCommunity() {
    const [v, f] = await Promise.all([
      Promise.resolve(api.community('votes')).catch(() => null),
      (D.home && D.home.feed && D.home.feed.length) ? Promise.resolve(api.community('feed')).catch(() => null) : Promise.resolve(null)
    ]);
    if (v && v.ok && v.data) st.votes = { counts: v.data.counts || {}, mine: v.data.mine || {} };
    st.feed = f && f.ok && f.data && Array.isArray(f.data.items) ? f.data.items.filter(x => x && x.title && /^https:\/\/discord\.com\//.test(x.url || '')) : [];
  }
  setInterval(() => { if (!document.hidden) loadCommunity().then(() => { if (overlay.hidden && menuEl.hidden) render(); }); }, 120000);

  // ---------- News ----------
  function mainNews() {
    const posts = D.news || [];
    const more = D.links.news ? `<p><button class="text-link" data-action="open-link" data-link="news">More news on the website ${ti('arrow-up-right')}</button></p>` : '';
    if (!posts.length) return `<div class="newsview"><h1>News</h1><div class="empty"><div class="empty-title">No news yet</div><div>Posts show up here when they're published.</div></div>${more}</div>`;
    return `<div class="newsview"><h1>News</h1>${posts.map(n => `<article class="post" data-post="${esc(n.id || '')}">
        <h2>${esc(n.title)}</h2>
        ${n.date ? `<div class="post-date">${esc(fmtDate(n.date))}${n.updated && n.updated.slice(0, 10) !== n.date.slice(0, 10) ? ` · updated ${esc(fmtDate(n.updated))}` : ''}</div>` : ''}
        <div class="md">${MD.render(n.body)}</div>
        ${hasLink(n) ? `<div class="row-actions"><button class="sbtn" data-action="open-link" data-link="${esc(n.link)}">${esc(n.linkLabel || 'Open')} ${ti('arrow-up-right')}</button></div>` : ''}
      </article>`).join('')}${more}</div>`;
  }
  function showPost(id) {
    if (!id) return;
    const el = [...main.querySelectorAll('.post')].find(x => x.dataset.post === id);
    if (!el) return;
    el.scrollIntoView({ block: 'start' });
    el.classList.add('flash');
  }

  // ---------- To-do: the development board (the Admin's To-do page), read-only, like a GitHub Projects board ----------
  const BOARD_COLOR = { gray: '#8b949e', blue: '#4493f8', green: '#3fb950', yellow: '#d29922', orange: '#db6d28', red: '#f85149', pink: '#db61a2', purple: '#a371f7' };
  function mainTodo() {
    const b = D.roadmap || { title: '', columns: [] };
    const total = b.columns.reduce((a, c) => a + c.cards.length, 0);
    const head = `<div class="board-head"><h1>${esc(b.title || 'To-do')}</h1>
      <p class="todo-lead">What the Warchief team is working on${total ? ` · ${total} item${total === 1 ? '' : 's'}` : ''}. Vote on what matters most to you.</p></div>`;
    if (!b.columns.length) return `<div class="newsview todoview">${head}<div class="empty"><div class="empty-title">Nothing on the board yet</div><div>The team's plans show up here when they're published.</div></div></div>`;
    const cols = b.columns.map(c => `<section class="bcol">
        <header class="bcol-head"><span class="bdot" style="background:${BOARD_COLOR[c.color] || BOARD_COLOR.gray}"></span><span class="bname">${c.emoji ? esc(c.emoji) + ' ' : ''}${esc(c.name)}</span><span class="bcount">${c.cards.length}</span></header>
        <div class="bcards">${c.cards.length ? c.cards.map(k => {
          const p = k.addon ? prod(k.addon) : null;
          return `<div class="bcard"><div class="btitle">${esc(k.title)}</div>${k.text ? `<div class="btext">${esc(k.text)}</div>` : ''}
            <div class="bfoot">${p ? `<span class="tag">${esc(p.name)}</span>` : '<span></span>'}${votePill(k.id)}</div></div>`;
        }).join('') : '<div class="bnone">Nothing here yet</div>'}</div></section>`).join('');
    return `<div class="newsview todoview">${head}<div class="board">${cols}</div></div>`;
  }

  // ---------- Help ----------
  const HELP_DEFAULT = `## Getting started
1. **Find your game folder.** The launcher looks for World of Warcraft by itself. If the big button says **Set folder**, open **Options → Directories** and pick the folder with the game's .exe in it (for example \`_retail_\`).
2. **Log in with Discord.** Members of the Warchief Discord download every addon and plugin for free. Use **Log in with Discord** in the Discord panel or in **Options → Account**.
3. **Install.** Pick an addon in the **My Addons** bar and press **Install**. Plugins need Warchiefs War Diary, and the launcher offers to install both.
4. **Play.** When everything is up to date, the big button says **Play** and starts the game.

## Updates
- The launcher checks for updates when it starts and every so often. Updates install by themselves unless you changed that in **Options → Downloads**.
- The gear next to the big button has **Check for updates**, **Scan and repair**, **Roll back to an older release**, **Show in folder** and **Uninstall**.
- The bell at the top lists updates, news, to-do changes and posts from the Warchief Discord.

## Common problems
**The button says "Set folder".** The launcher can't find your game. Open **Options → Directories** and press **Find my WoW folders**, or pick the folder yourself.

**Install or Update has a lock.** Downloads are for members of the Warchief Discord. Log in with Discord, join the server, and make sure you have the Member role. Beta versions are for Testers.

**An addon doesn't show up in the game.** Check that you picked the right game version (Retail or WoW: Forever) and that AddOns are turned on in the game's character screen. Then use **Scan and repair**.

**Something broke after an update.** Use the gear, then **Roll back to an older release**. Your in-game settings aren't touched.

## Still stuck?
Send a bug report from here, or ask in the Warchief Discord. The support info helps the team a lot.`;
  function mainHelp() {
    const text = (D.home && D.home.help) || HELP_DEFAULT;
    const acts = [];
    if (D.access && D.access.bugReports) acts.push(`<button class="pbtn" data-action="report-bug">${ti('bug')} Report a bug</button>`);
    if (inviteUrl()) acts.push(`<button class="sbtn" data-action="join-discord">${ti('brand-discord')} Open the Warchief Discord</button>`);
    acts.push(`<button class="sbtn" data-action="support-info">${ti('copy')} Copy support info</button>`);
    if (D.links.support) acts.push(`<button class="sbtn" data-action="open-link" data-link="support">${ti('lifebuoy')} Support ${ti('arrow-up-right')}</button>`);
    if (S.discordMode === 'closed') acts.push(`<button class="sbtn" data-action="dw-open">${ti('layout-sidebar-right')} Show the Discord panel</button>`);
    return `<div class="newsview helpview"><h1>Help</h1><div class="row-actions help-actions">${acts.join('')}</div><div class="md help-md">${MD.render(text)}</div></div>`;
  }

  // ---------- Bell: updates, news, to-do changes and Discord posts ----------
  function cardMap() {
    const m = {};
    for (const c of (D.roadmap || { columns: [] }).columns) for (const k of c.cards) m[k.id] = c.id || c.name;
    return m;
  }
  function notifications() {
    const out = [];
    if (UPD_SHOW.includes(UPD.s.state) && UPD.s.state !== 'error') {
      out.push({ key: 'launcher:' + UPD.s.version, at: Date.now(), icon: 'refresh', title: `Warchief Launcher ${UPD.s.version ? 'v' + UPD.s.version + ' ' : ''}is ready`, sub: 'Launcher update', action: 'launcher-update-now', unread: (S.seen.upd || {}).launcher !== UPD.s.version });
    }
    for (const p of D.products) {
      if (statusOf(p) !== 'update' && statusOf(p) !== 'locked-update') continue;
      const v = latestOf(p);
      out.push({ key: 'upd:' + p.id, at: Date.now() - 1, icon: 'download', title: `Update ready: ${p.name} ${v}`, sub: 'Update', action: 'select-update', id: p.id, unread: (S.seen.upd || {})[p.id] !== v });
    }
    for (const n of (D.news || []).slice(0, 5)) {
      out.push({ key: 'news:' + n.id, at: timeOf(n.date), icon: 'news', title: n.title, sub: `News${n.date ? ' · ' + fmtShort(n.date).toLowerCase().replace(/^\w/, c => c.toUpperCase()) : ''}`, action: 'go-news', post: n.id, unread: timeOf(n.date) > timeOf(S.seen.news) });
    }
    const seenCards = S.seen.cards || {};
    for (const c of (D.roadmap || { columns: [] }).columns) {
      for (const k of c.cards) {
        const was = seenCards[k.id];
        if (S.seen.cards && was === (c.id || c.name)) continue;
        if (!S.seen.cards) continue;
        out.push({ key: 'card:' + k.id, at: timeOf(k.at) || timeOf(D.publishedAt), icon: 'layout-kanban', title: was ? `${k.title} moved to ${c.name}` : `${k.title} added to ${c.name}`, sub: 'To-do board', action: 'go-todo', unread: true });
      }
    }
    for (const f of st.feed.slice(0, 6)) {
      out.push({ key: 'feed:' + f.id, at: timeOf(f.at), icon: 'brand-discord', title: f.title, sub: `Discord · #${f.channel}`, url: f.url, unread: timeOf(f.at) > timeOf(S.seen.feed) });
    }
    return out.sort((a, b) => b.at - a.at).slice(0, 12);
  }
  function paintBell() {
    const n = notifications().filter(x => x.unread).length;
    bellDot.hidden = !n;
    const b = document.querySelector('.bell');
    if (b) b.setAttribute('aria-label', n ? `Notifications: ${n} new` : 'Notifications');
  }
  function markAllRead() {
    const newest = (list, f) => list.reduce((a, x) => (timeOf(f(x)) > timeOf(a) ? f(x) : a), '');
    S.seen.news = newest(D.news || [], n => n.date) || S.seen.news;
    S.seen.feed = newest(st.feed, f => f.at) || S.seen.feed;
    S.seen.cards = cardMap();
    S.seen.upd = { ...(S.seen.upd || {}) };
    for (const p of D.products) S.seen.upd[p.id] = latestOf(p);
    if (UPD.s.version) S.seen.upd.launcher = UPD.s.version;
    save(LS_SET, S); paintBell();
  }
  function notifMenu() {
    const list = notifications();
    const rows = list.length ? list.map(x => `<div class="nrow">
        <span class="ndot ${x.unread ? 'on' : ''}"></span>
        <button class="nmain" data-action="${x.url ? 'open-url-keep' : x.action}" ${x.url ? `data-url="${esc(x.url)}"` : ''} ${x.id ? `data-id="${esc(x.id)}"` : ''} ${x.post ? `data-post="${esc(x.post)}"` : ''}>
          <span class="nicon">${ti(x.icon)}</span><span class="ntext"><span class="ntitle">${esc(x.title)}</span><span class="nsub">${esc(x.sub)}</span></span></button>
        ${x.url ? `<button class="next" data-action="open-url-keep" data-url="${esc(x.url)}" aria-label="Open it in Discord">${ti('arrow-up-right')}</button>` : ''}</div>`).join('')
      : '<div class="nempty">Nothing new right now.</div>';
    return `<div class="nhead"><span>NOTIFICATIONS</span><button data-action="notif-read">Mark all read</button></div><div class="nlist">${rows}</div>`;
  }

  // ---------- Discord panel: our own window stuck to the launcher's right edge, popped out, or closed ----------
  // (widget.js in the main program makes the window; this says what to show and who's logged in)
  const DISCORD_SERVER = '1564085762755002508';
  let dwSent = '';
  function panelAccount() {
    if (!accessOn() || !AC.loaded) return { state: 'loading' };
    if (AC.busy) return { state: 'busy' };
    if (!AC.loggedIn) return { state: 'out' };
    if (!AC.me) return { state: 'offline' };
    const role = isMember() ? (AC.me.roles || [])[0] : null;
    return {
      state: 'in', id: String(AC.me.user.id || ''), name: firstName(), username: AC.me.user.username || '', avatar: avatar(),
      role: role ? role.name : isMember() ? 'Warchief Member' : AC.me.inServer ? 'In the server' : 'Not in the server',
      roleColor: role && /^#[0-9a-f]{6}$/i.test(role.color || '') ? role.color : '', inServer: !!AC.me.inServer
    };
  }
  function syncWidget() {
    const t = D.themes.find(x => x.id === S.theme) || D.themes[0];
    const v = themeVars(t);
    const server = /^\d{5,25}$/.test(String((D.access && D.access.serverId) || '')) ? D.access.serverId : DISCORD_SERVER;
    const want = {
      mode: S.discordMode, serverId: server, light: !!t.light, invite: inviteUrl(), account: panelAccount(),
      colors: { bg: v.bg, bar: v.bar, side: v.side, line: v.line, tx: v.tx, tx2: v.tx2, frameTop: v['frame-top'], acc: v.acc, ink: v['acc-ink'], link: v.link, sel: v.sel, hover: v.hover }
    };
    const key = JSON.stringify(want);
    if (key === dwSent) return; // the panel stays as it is while you move around the launcher
    dwSent = key;
    Promise.resolve(api.dwSet(want)).catch(() => { dwSent = ''; });
  }
  function setDiscordMode(mode) { S.discordMode = mode; S.showWidget = mode !== 'closed'; save(LS_SET, S); render(); }
  // The panel's own buttons (pop out, stick back, close, log in, account) come back here through the main program
  api.onDwDo(a => {
    if (!a) return;
    if (a.do === 'mode' && ['docked', 'popped', 'closed'].includes(a.mode)) { S.discordMode = a.mode; S.showWidget = a.mode !== 'closed'; save(LS_SET, S); dwSent = ''; return render(); }
    if (a.do === 'login') return login();
    if (a.do === 'account') { go('options', { page: 'account' }); return; }
    if (a.do === 'toast' && typeof a.text === 'string') return toast(a.text.slice(0, 200));
  });
  // Title bar, right side: when the panel is closed, a button to open it again and the account
  function titleAccount() {
    if (S.discordMode !== 'closed') return '';
    const me = AC.loggedIn ? AC.me : null;
    const av = me ? avatar() : '';
    const name = !accessOn() || !AC.loaded ? '' : !AC.loggedIn ? 'Log in' : (me ? firstName() : 'Discord');
    return `<button class="tb-discord" data-action="dw-open" aria-label="Open the Discord panel">${ti('brand-discord')} Discord ${ti('layout-sidebar-right-expand')}</button>
      ${name ? `<button class="tb-chip" data-action="menu" data-menu="${AC.loggedIn ? 'account' : 'account-out'}" aria-label="Account: ${esc(name)}">${av ? `<img src="${esc(av)}" alt="">` : `<span class="tb-av">${ti('user')}</span>`}<span>${esc(name)}</span></button>` : ''}`;
  }

  // Resize grip in the bottom-right corner (on the Discord panel instead while it's stuck to the launcher)
  grip.addEventListener('pointerdown', e => {
    if (e.button !== 0) return;
    e.preventDefault();
    grip.setPointerCapture(e.pointerId);
    api.grip('start');
    const move = () => api.grip('move');
    const up = () => { api.grip('end'); grip.removeEventListener('pointermove', move); grip.removeEventListener('pointerup', up); grip.removeEventListener('pointercancel', up); };
    grip.addEventListener('pointermove', move);
    grip.addEventListener('pointerup', up);
    grip.addEventListener('pointercancel', up);
  });

  const PAGES = [
    ['general', 'General', 'list-details'], ['directories', 'Directories', 'folder'], ['downloads', 'Downloads', 'download'],
    ['appearance', 'Appearance', 'palette'], ['notifications', 'Notifications', 'bell'], ['support', 'Support', 'lifebuoy'], ['about', 'About', 'info-circle']
  ];
  function sideOptions() {
    const pages = accessOn() ? [['account', 'Account', 'user-circle'], ...PAGES] : PAGES;
    return `<div class="label">OPTIONS</div><div>${pages.map(([id, name, ic]) => `<button class="game ${st.page === id ? 'on' : ''}" data-action="page" data-page="${id}"><span class="opt-item">${ti(ic)} ${name}</span></button>`).join('')}</div>
      <div class="side-spacer"></div>
      <button class="side-btn" data-action="go-home">${ti('arrow-left')} Back</button>`;
  }

  // ---------- Options pages ----------
  const radio = (key, val, label, hint) => `<label class="choice"><input type="radio" name="${key}" data-setting="${key}" value="${val}" ${getPath(S, key) === val ? 'checked' : ''}><span>${label}${hint ? ` <small>${hint}</small>` : ''}</span></label>`;
  const check = (key, label, hint) => `<label class="choice"><input type="checkbox" data-setting="${key}" ${getPath(S, key) ? 'checked' : ''}><span>${label}${hint ? ` <small>${hint}</small>` : ''}</span></label>`;
  const field = (title, inner, hint) => `<div class="field"><div class="field-title">${title}</div>${hint ? `<div class="hint">${hint}</div>` : ''}${inner}</div>`;

  function mainOptions() {
    const pages = { general: pGeneral, directories: pDirectories, downloads: pDownloads, appearance: pAppearance, notifications: pNotifications, support: pSupport, about: pAbout };
    if (accessOn()) pages.account = pAccount;
    return `<div class="page">${(pages[st.page] || pGeneral)()}</div>`;
  }

  function pGeneral() {
    return `<h1>General</h1>
      ${field('Language', `<select class="wide" data-setting="language"><option value="en" selected>English</option></select>`)}
      ${field('Startup', check('startWithWindows', 'Start the launcher when Windows starts'))}
      ${field('Discord panel', radio('discordMode', 'docked', 'Next to the launcher', 'stuck to its right edge') + radio('discordMode', 'popped', 'In its own window', 'move it anywhere') + radio('discordMode', 'closed', 'Hidden', 'the Discord button at the top brings it back'), "Who's online in the Warchief Discord, your account and a Join button.")}
      ${field('When I click the X', radio('onClose', 'taskbar', 'Minimize to the taskbar') + radio('onClose', 'tray', 'Minimize to the system tray') + radio('onClose', 'exit', 'Close the launcher'))}
      ${field('When I launch a game', radio('onLaunch', 'nothing', 'Do nothing') + radio('onLaunch', 'taskbar', 'Minimize to the taskbar') + radio('onLaunch', 'tray', 'Minimize to the system tray') + radio('onLaunch', 'exit', 'Close the launcher'))}`;
  }

  function dirRow(g, d, i, used, count) {
    const r = st.dir[d];
    let cls = '', sub = 'Checking…';
    if (r) {
      if (r.exists && r.looksLikeWow) { cls = 'good'; sub = `Found. Addons go to ${r.addons}`; }
      else if (r.exists) { cls = 'bad'; sub = "This folder doesn't look like a WoW game folder"; }
      else { cls = 'bad'; sub = 'Folder not found'; }
    }
    return `<div class="dir"><span class="dir-n">${i + 1}.</span><span class="dir-bar ${cls}"></span>
      <div class="dir-box"><div class="dir-path"><span>${esc(d)}</span>${used && count > 1 ? '<span class="chip sm">Used for installs</span>' : ''}</div><div class="dir-sub">${esc(sub)}</div></div>
      <div class="dir-actions"><button class="icon-btn" data-action="dir-edit" data-game="${g.id}" data-i="${i}" title="Change folder" aria-label="Change folder">${ti('pencil')}</button>${count > 1 ? `<button class="icon-btn" data-action="dir-remove" data-game="${g.id}" data-i="${i}" title="Remove" aria-label="Remove folder">${ti('x')}</button>` : ''}</div></div>`;
  }

  function pDirectories() {
    return `<div class="page-head"><h1>Directories</h1><button class="sbtn" data-action="detect">${ti('search')} Find my WoW folders</button></div>
      <p class="hint lead">Pick the game folder for each version of WoW, the one with the game's .exe in it. Addons are installed into its Interface\\AddOns folder.</p>
      ${D.games.map(g => {
        const dirs = S.dirs[g.id] || [];
        const used = installDir(g.id);
        return `<div class="game-dirs"><div class="field-title"><span class="picon sm g-${g.id}">${esc(g.badge)}</span>${esc(g.title)} <span class="muted small">${esc(g.folder)}</span></div>
          ${dirs.map((d, i) => dirRow(g, d, i, d === used, dirs.length)).join('')}
          <button class="add-link" data-action="dir-add" data-game="${g.id}">${ti('plus')} Add another install folder</button></div>`;
      }).join('')}
      <button class="text-link" data-action="dir-defaults">Restore defaults</button>`;
  }

  function pDownloads() {
    return `<h1>Downloads</h1>
      ${field('Update channel', radio('channel', 'stable', 'Stable', 'tested releases') + (canBeta() ? radio('channel', 'beta', 'Beta', 'get test versions first and help find bugs')
        : `<label class="choice off"><input type="radio" disabled><span>Beta <small>for Testers on the Warchief Discord</small></span></label>`))}
      ${field('Keep these games updated', D.games.map(g => check('updateGames.' + g.id, g.title)).join(''))}
      ${field('Addon updates', radio('addonUpdates', 'auto', 'Download and install updates automatically') + radio('addonUpdates', 'ask', 'Check for updates, but let me choose when to install'))}
      ${field('Launcher updates', radio('launcherUpdates', 'auto', 'Download and install updates automatically') + radio('launcherUpdates', 'ask', 'Check for updates, but let me choose when to install'))}
      ${field('Backups', check('keepBackups', 'Keep older versions so I can roll back') +
        `<label class="choice inline">Keep <select data-setting="backupCount" data-num="1">${[1, 2, 3, 5].map(n => `<option value="${n}" ${S.backupCount === n ? 'selected' : ''}>${n}</option>`).join('')}</select> older version${S.backupCount === 1 ? '' : 's'} of each addon</label>`)}`;
  }

  function themeCard(t) {
    const v = themeVars(t);
    const font = (t.fonts && t.fonts.fh) || { forged: "'Barlow Condensed', sans-serif", regal: "'Cinzel', serif", clean: "'Inter', sans-serif", parchment: "'IM Fell English', serif" }[t.family];
    const on = S.theme === t.id;
    return `<button class="theme-card ${on ? 'on' : ''}" data-action="theme" data-theme="${t.id}" aria-pressed="${on}">
      <div class="tprev" style="background:${v.bg};border-color:${v.line}">
        <div class="tp-bar" style="background:${v.bar};border-bottom:2px solid ${v['frame-top']}"></div>
        <div style="background:${v.side};border-right:1px solid ${v.line}"></div>
        <div class="tp-main">
          <div class="tp-row"><span class="tp-ic" style="background:${v.acc}"></span><span class="tp-ln" style="background:${v.tx}"></span><span class="tp-bt" style="background:${v['play-bg']}"></span></div>
          <div class="tp-row"><span class="tp-ic" style="background:${v['icon-bg']}"></span><span class="tp-ln" style="background:${v.tx2}"></span><span class="tp-bt" style="border:1px solid ${v.acc}"></span></div>
          <div class="tp-row"><span class="tp-ic" style="background:${v['icon-bg']}"></span><span class="tp-ln" style="background:${v.tx2}"></span><span class="tp-bt" style="border:1px solid ${v['btn-line']}"></span></div>
        </div>
      </div>
      <div class="tname" style="font-family:${font}">${esc(t.name)}${t.id === D.defaultTheme ? ' <span class="chip sm">Default</span>' : ''}${on ? `<span class="tcheck">${ti('check')}</span>` : ''}</div>
      <div class="tdesc">${esc(t.desc)}</div>
    </button>`;
  }

  function pAppearance() {
    const exp = D.themes.filter(t => t.group === 'expansion');
    const sty = D.themes.filter(t => t.group === 'style');
    return `<h1>Appearance</h1>
      <div class="theme-group">${field('Expansion themes', `<div class="themes">${exp.map(themeCard).join('')}</div>`)}</div>
      <div class="theme-group">${field('Launcher styles', `<div class="themes">${sty.map(themeCard).join('')}</div>`)}</div>`;
  }

  function pNotifications() {
    return `<h1>Notifications</h1>
      ${field('Alerts', check('notify.enabled', 'Show notification alerts'))}
      ${field('Tell me when', check('notify.addonUpdates', 'An addon update is available or was installed') + check('notify.news', 'A news post is added') + check('notify.launcher', 'The launcher updated itself') + check('notify.beta', 'A beta version is available', 'beta channel only'))}`;
  }

  function logHtml(n) {
    return P.log.length
      ? `<ul class="log">${P.log.slice(0, n).map(l => `<li><span>${esc(fmtTime(l.t))}</span><span>${esc(l.text)}</span></li>`).join('')}</ul>`
      : `<p class="muted">Nothing here yet.</p>`;
  }

  function pSupport() {
    setTimeout(() => supportText().then(t => { const el = document.getElementById('support-text'); if (el) el.value = t; }), 0);
    return `<h1>Support</h1>
      ${field('Support info', `<textarea class="support" id="support-text" readonly aria-label="Support info"></textarea>
        <div class="row-actions"><button class="pbtn" data-action="copy-support">${ti('copy')} Copy support info</button><button class="sbtn" data-action="open-link" data-link="discord">${ti('brand-discord')} Open Discord</button></div>`, 'Paste this into Discord when you report a bug.')}
      ${field('Activity log', logHtml(30))}`;
  }

  function pAbout() {
    return `<h1>About</h1>
      <p class="about-name">Warchief Launcher <span class="brand-ver">v${esc(D.launcher.version)}</span></p>
      <p class="muted">Installs and updates Warchiefs War Diary and its plugins.<br>© 2026 TankyShrimp</p>
      <p class="muted small">Not made or endorsed by Blizzard Entertainment. World of Warcraft is a trademark or registered trademark of Blizzard Entertainment, Inc.</p>
      ${field('Links', `<div class="links"><button class="text-link" data-action="open-link" data-link="curseforge">CurseForge ${ti('arrow-up-right')}</button><button class="text-link" data-action="open-link" data-link="github">GitHub ${ti('arrow-up-right')}</button></div>`)}`;
  }

  // ---------- Actions ----------
  // Install, update, repair, roll back or uninstall for real. installer.js does the work in the AddOns folder
  // (download, safety checks, backup, then the folders are swapped in one go) and reports progress back here.
  const KIND_VERB = { install: 'install', update: 'update', repair: 'repair', rollback: 'roll back', uninstall: 'uninstall' };
  async function runTask(p, kind, done) {
    if (!p || st.busy[p.id]) return;
    const dir = installDir(p.game);
    if (!dir) return toast('Set the game folder first');
    const from = installedOf(p);
    const beta = ['install', 'update', 'repair'].includes(kind) && isBeta(p);
    st.busy[p.id] = { pct: 0, label: kind === 'uninstall' ? 'Removing' : kind === 'rollback' ? 'Restoring' : 'Starting' };
    paintStatus(p);
    let r = null;
    try {
      r = await api.instRun({ kind, id: p.id, gameId: p.game, dir, channel: beta ? 'beta' : 'stable', keepBackups: !!S.keepBackups, backupCount: Number(S.backupCount) || 1 });
    } catch (e) { r = { ok: false, error: String((e && e.message) || e) }; }
    delete st.busy[p.id];
    await scanAll();
    const n = p.name;
    if (!r || !r.ok) {
      render();
      if (r && r.need) {
        await refreshAccount(true);
        return lockModal(p, lockOf(p, beta) || ({ login: 'login', member: 'member', tester: 'tester' }[r.need] || 'member'));
      }
      const why = (r && r.error) || 'Something went wrong.';
      log(`Couldn't ${KIND_VERB[kind]} ${n}: ${why}`); save(LS_PREV, P);
      return showModal(`<h2>Couldn't ${esc(KIND_VERB[kind])} ${esc(n)}</h2><p>${esc(why)}</p><div class="actions"><button class="pbtn" data-action="close-modal">OK</button></div>`);
    }
    const to = r.version || installedOf(p) || '';
    if (kind === 'update') { log(`Updated ${n} from ${from || '?'} to ${to}`); notify(`${n} updated to ${to}`); }
    else if (kind === 'install') { log(`Installed ${n} ${to}`); notify(`${n} ${to} installed`); }
    else if (kind === 'repair') { log(`Repaired ${n} (${to})`); toast(`${n} repaired`); }
    else if (kind === 'rollback') { log(`Rolled back ${n} from ${from} to ${to}`); toast(`${n} rolled back to ${to}`); }
    else if (kind === 'uninstall') { log(`Uninstalled ${n}`); toast(`${n} uninstalled. Its folders are in the Recycle Bin.`); }
    save(LS_PREV, P); render();
    if (done) done();
  }
  api.onInstProgress(x => {
    if (!x || !st.busy[x.id]) return;
    st.busy[x.id] = { pct: x.pct, label: x.label };
    const p = prod(x.id); if (p) paintStatus(p);
  });
  // Reads every game's AddOns folder: which addons are there, their versions, and the backups kept.
  async function scanAll() {
    const inst = {};
    for (const g of D.games) {
      const dir = installDir(g.id);
      if (!dir) continue;
      let r = null;
      try { r = await api.instScan(g.id, dir); } catch { r = null; }
      if (r && r.ok) Object.assign(inst, r.items);
    }
    st.inst = inst; st.scanned = true;
  }
  // Options > Downloads > "Download and install updates automatically": updates what's installed, never adds new addons.
  function autoUpdate() {
    if (S.addonUpdates !== 'auto') return 0;
    const list = D.products.filter(p => statusOf(p) === 'update' && S.updateGames[p.game] !== false);
    list.forEach(p => task(p, 'update'));
    return list.length;
  }
  function notify(msg) { if (S.notify.enabled && S.notify.addonUpdates) toast(msg); }

  function install(p) {
    const base = p.requires && prod(p.requires);
    if (base && !installedOf(base)) {
      const lock = lockOf(base, isBeta(base)) || lockOf(p, isBeta(p));
      if (lock && lock !== 'wait') return lockModal(lockOf(base, isBeta(base)) ? base : p, lock);
      return confirmModal({
        title: `${p.name} needs ${base.name}`,
        body: `<p>${esc(p.name)} is a plugin, so it only works when ${esc(base.name)} is installed too. Install both?</p>`,
        ok: 'Install both', onOk: () => task(base, 'install', () => task(p, 'install'))
      });
    }
    task(p, 'install');
  }

  function updateAll() {
    const list = D.products.filter(p => statusOf(p) === 'update' && S.updateGames[p.game] !== false);
    const locked = D.products.filter(p => statusOf(p) === 'locked-update' && S.updateGames[p.game] !== false);
    if (!list.length && locked.length) return lockModal(locked[0], lockOf(locked[0], isBeta(locked[0])));
    if (!list.length) return toast('Everything is up to date');
    list.forEach(p => task(p, 'update'));
    if (locked.length) toast(`${locked.length} locked update${locked.length > 1 ? 's were' : ' was'} skipped`);
  }

  async function checkUpdates() {
    if (st.checkingUpdates) return;
    st.checkingUpdates = true; render();
    const started = Date.now();
    const ok = await loadCatalog();
    await checkDirs(allDirs());
    await scanAll();
    await loadCommunity();
    await new Promise(r => setTimeout(r, Math.max(0, 700 - (Date.now() - started))));
    st.checkingUpdates = false;
    await refreshAccount(false);
    const n = D.products.filter(p => statusOf(p) === 'update' || statusOf(p) === 'locked-update').length;
    log('Checked for updates'); save(LS_PREV, P); render();
    if (!ok) return toast("Couldn't reach GitHub. Showing the last saved list.");
    const auto = autoUpdate();
    toast(auto ? `Updating ${auto} addon${auto > 1 ? 's' : ''}…` : n ? `${n} update${n > 1 ? 's' : ''} available` : 'Everything is up to date');
  }

  // ---------- Catalog (published by the Admin page) ----------
  const LS_CAT = 'wl.catalog.v1';
  function applyCatalog(cat) {
    if (!cat || typeof cat !== 'object' || !Array.isArray(cat.products)) return false;
    if (Array.isArray(cat.games) && cat.games.length) {
      D.games = cat.games.filter(g => g && g.id && g.folder && /^[\w.-]+$/.test(g.folder))
        .map(g => ({ id: String(g.id).replace(/[^\w-]/g, ''), name: g.name || g.id, short: g.short || g.name || g.id, title: g.title || g.name || g.id, folder: g.folder, badge: g.badge || String(g.name || g.id).charAt(0) }));
    }
    D.links = Object.assign({}, D.links, cat.links || {});
    // Discord login for downloads: always on (settings from the Admin's Members & access page).
    const ac = cat.access || {};
    D.access = {
      invite: /^https:\/\/(discord\.gg|discord\.com\/invite)\/[\w-]+$/.test(ac.invite || '') ? ac.invite : (D.links.discord || 'https://discord.gg/pCjPx2c5s6'),
      bugReports: ac.bugReports !== false,
      serverId: /^\d{5,25}$/.test(String(ac.serverId || '')) ? String(ac.serverId) : ''
    };
    D.news = Array.isArray(cat.news) ? cat.news : [];
    // To-do board from the Admin's To-do page
    const rm = cat.roadmap && typeof cat.roadmap === 'object' ? cat.roadmap : {};
    D.roadmap = {
      title: String(rm.title || ''),
      columns: (Array.isArray(rm.columns) ? rm.columns : []).filter(c => c && c.name).map((c, ci) => ({
        id: /^[\w-]{1,40}$/.test(c.id || '') ? c.id : 'col' + ci,
        name: String(c.name), emoji: String(c.emoji || ''), color: BOARD_COLOR[c.color] ? c.color : 'gray',
        cards: (Array.isArray(c.cards) ? c.cards : []).filter(k => k && k.title).map((k, ki) => ({
          id: /^[\w-]{1,40}$/.test(k.id || '') ? k.id : `card${ci}-${ki}`, title: String(k.title), text: String(k.text || ''), addon: String(k.addon || ''), at: typeof k.at === 'string' ? k.at : ''
        }))
      }))
    };
    // Launcher home page settings from the Admin: the banner, the Help page, which Discord channels feed the bell
    const h = cat.home && typeof cat.home === 'object' ? cat.home : {};
    const b = h.banner && typeof h.banner === 'object' ? h.banner : {};
    D.home = {
      banner: { on: b.on === true, title: String(b.title || '').slice(0, 120), text: String(b.text || '').slice(0, 200), until: String(b.until || ''), button: String(b.button || '').slice(0, 30), link: String(b.link || '') },
      help: typeof h.help === 'string' ? h.help.slice(0, 20000) : '',
      feed: Array.isArray(h.feed) ? h.feed.map(String).filter(x => /^\d{5,25}$/.test(x)).slice(0, 3) : []
    };
    D.products = cat.products
      .filter(p => p && p.id && p.enabled !== false && p.release && p.release.version)
      .map(p => ({
        id: String(p.id).replace(/[^\w-]/g, ''), name: p.name || p.id, short: p.short || String(p.name || p.id).slice(0, 2).toUpperCase(),
        icon: p.icon || 'badge', iconUrl: /^https:\/\/[\w.-]+\//i.test(p.iconUrl || '') ? p.iconUrl : '',
        type: p.type === 'plugin' ? 'plugin' : 'main', requires: p.requires || null,
        game: p.game, repo: p.repo, latest: p.release.version, beta: p.beta && p.beta.version ? p.beta.version : null,
        access: ['everyone', 'members', 'testers'].includes(p.access) ? p.access : 'members',
        folders: p.release.folders || [], notes: p.release.notes || '', betaNotes: (p.beta && p.beta.notes) || '',
        changelogUrl: /^https:\/\//i.test(p.changelogUrl || '') ? p.changelogUrl : null,
        url: p.release.url || null, betaUrl: p.beta ? p.beta.url : null
      }))
      .filter(p => D.games.some(g => g.id === p.game));
    D.publishedAt = cat.publishedAt || null;
    // Make sure every game in the catalog has folder settings.
    for (const g of D.games) {
      if (!S.dirs[g.id]) S.dirs[g.id] = ['C:\\Program Files (x86)\\World of Warcraft\\' + g.folder];
      if (S.updateGames[g.id] === undefined) S.updateGames[g.id] = true;
    }
    if (!D.products.some(p => p.id === st.sel)) st.sel = D.products[0] ? D.products[0].id : null;
    // The bell starts counting to-do changes from the first board this launcher sees
    if (!S.seen.cards) S.seen.cards = cardMap();
    Promise.resolve(api.instCatalog(cat)).catch(() => {});
    return true;
  }
  async function loadCatalog() {
    let res = null;
    try { res = api.getCatalog ? await api.getCatalog() : null; } catch { res = null; }
    if (res && res.catalog && applyCatalog(res.catalog)) {
      st.catalogSource = res.source === 'preview' ? 'preview' : 'online';
      if (res.source !== 'preview') { try { localStorage.setItem(LS_CAT, JSON.stringify(res.catalog)); } catch { /* ignore */ } }
      save(LS_SET, S);
      return true;
    }
    let cached = null;
    try { cached = JSON.parse(localStorage.getItem(LS_CAT) || 'null'); } catch { cached = null; }
    if (cached && applyCatalog(cached)) { st.catalogSource = 'cached'; return false; }
    st.catalogSource = 'none';
    return !(res && res.error && res.error !== 'no-catalog-url');
  }

  function selected() {
    const p = curProduct();
    if (!p) toast('Pick an addon first');
    return p;
  }
  function repair() {
    const p = selected(); if (!p) return;
    if (!installedOf(p)) return toast(`${p.name} isn't installed`);
    if (!installDir(p.game)) return toast('Set the game folder first');
    task(p, 'repair');
  }
  function rollback() {
    const p = selected(); if (!p) return;
    const b = backupsOfP(p).slice(-1)[0];
    if (!installedOf(p) || !b) return toast(`No older version of ${p.name} is backed up yet`);
    confirmModal({
      title: 'Roll back?',
      body: `<p>Go back from ${esc(installedOf(p))} to ${esc(b)} for ${esc(p.name)}?</p><p class="muted">Your in-game settings aren't touched.</p>`,
      ok: 'Roll back', onOk: () => runTask(p, 'rollback')
    });
  }
  function uninstall() {
    const p = selected(); if (!p) return;
    if (!installedOf(p)) return toast(`${p.name} isn't installed`);
    const deps = D.products.filter(d => d.requires === p.id && installedOf(d));
    const folders = p.folders && p.folders.length ? `<p>These folders are removed from AddOns:</p><ul class="mono">${p.folders.map(f => `<li>${esc(f)}</li>`).join('')}</ul>` : '';
    const warn = deps.length ? `<p class="warn-text">${ti('alert-triangle')}<span>${deps.map(d => esc(d.name)).join(', ')} need${deps.length === 1 ? 's' : ''} it and won't work until it's back.</span></p>` : '';
    confirmModal({
      title: `Uninstall ${p.name}?`,
      body: folders + warn + `<p class="muted">The folders go to the Recycle Bin. Your saved settings in the WTF folder are kept.</p>`,
      ok: 'Uninstall', danger: true,
      onOk: () => runTask(p, 'uninstall')
    });
  }
  async function showFolder() {
    const p = selected(); if (!p) return;
    const dir = installDir(p.game);
    if (!dir) return toast('Set the game folder first');
    let ok = false;
    try { ok = await api.instOpenFolder(dir); } catch { ok = false; }
    if (!ok) toast("Couldn't open the AddOns folder.");
  }
  async function play(p) {
    const g = game(p.game);
    const dir = installDir(p.game);
    if (!dir) return toast('Set the game folder first');
    let r = null;
    try { r = await api.instPlay(dir); } catch { r = null; }
    if (!r || !r.ok) return toast((r && r.error) || "Couldn't start World of Warcraft.");
    log(`Launched World of Warcraft (${g.name})`); save(LS_PREV, P);
    if (S.onLaunch === 'taskbar') api.minimize();
    else if (S.onLaunch === 'tray') api.toTray();
    else if (S.onLaunch === 'exit') setTimeout(() => api.exit(), 400);
    else toast(`Starting World of Warcraft ${g.name}…`);
  }
  function changelog(p) {
    if (!p) return;
    if (p.changelogUrl) { api.openExternal(p.changelogUrl); toast('Opening the changelog on CurseForge'); return; }
    const beta = isBeta(p);
    showModal(`<h2>${esc(p.name)} ${esc(latestOf(p))}</h2>
      <div class="notes md">${MD.render(beta ? p.betaNotes : p.notes) || '<p class="muted">No release notes were written for this version.</p>'}</div>
      <p class="muted small">From the GitHub release notes.</p>
      <div class="actions"><button class="sbtn" data-action="close-modal">Close</button></div>`);
  }
  function openLink(key) {
    const url = /^https:\/\//i.test(key || '') ? key : D.links[key] || (key === 'discord' ? inviteUrl() : null);
    if (!url) return toast('This link gets set in the Admin page.');
    api.openExternal(url);
  }
  function closeWindow() {
    if (S.onClose === 'taskbar') return api.minimize();
    if (S.onClose === 'tray') return api.toTray();
    return api.exit();
  }

  // Folders
  async function checkDirs(paths) {
    await Promise.all(paths.map(async p => {
      try { st.dir[p] = await api.checkFolder(p); } catch { st.dir[p] = { exists: false }; }
    }));
  }
  const allDirs = () => D.games.flatMap(g => S.dirs[g.id] || []);
  async function dirEdit(gid, i) {
    const p = await api.pickFolder(S.dirs[gid][i]); if (!p) return;
    S.dirs[gid][i] = p; save(LS_SET, S); await checkDirs([p]); await scanAll(); render();
  }
  async function dirAdd(gid) {
    const p = await api.pickFolder(); if (!p) return;
    S.dirs[gid] = S.dirs[gid] || [];
    if (!S.dirs[gid].includes(p)) S.dirs[gid].push(p);
    save(LS_SET, S); await checkDirs([p]); await scanAll(); render();
  }
  async function dirRemove(gid, i) { S.dirs[gid].splice(i, 1); save(LS_SET, S); await scanAll(); render(); }
  async function dirDefaults() { S.dirs = defaultDirs(); save(LS_SET, S); await checkDirs(allDirs()); await scanAll(); render(); toast('Folders set back to the defaults'); }
  async function detect(quiet) {
    let found = {};
    try { found = await api.detectFolders(D.games.map(g => ({ id: g.id, folder: g.folder }))) || {}; } catch { found = {}; }
    let added = 0;
    for (const g of D.games) {
      const list = found[g.id] || [];
      if (!list.length) continue;
      await checkDirs(list);
      const good = (S.dirs[g.id] || []).filter(dirOk);
      const extra = list.filter(d => !good.some(x => x.toLowerCase() === d.toLowerCase()));
      added += extra.length;
      S.dirs[g.id] = [...good, ...extra];
    }
    save(LS_SET, S); await checkDirs(allDirs()); await scanAll(); render();
    if (!quiet || added) toast(added ? `Found ${added} WoW folder${added > 1 ? 's' : ''}` : "Didn't find any new WoW folders. Pick them with the pencil button.");
  }

  // Modals and menus
  function showModal(html) { closeMenu(); modalEl.innerHTML = html; overlay.hidden = false; const b = modalEl.querySelector('.pbtn, .dbtn, .sbtn'); if (b) b.focus(); }
  function closeModal() { overlay.hidden = true; modalEl.innerHTML = ''; modalOk = null; }
  function confirmModal({ title, body, ok, danger, onOk }) {
    modalOk = onOk;
    showModal(`<h2>${esc(title)}</h2>${body}<div class="actions"><button class="sbtn" data-action="close-modal">Cancel</button><button class="${danger ? 'dbtn' : 'pbtn'}" data-action="modal-ok">${esc(ok)}</button></div>`);
  }
  function activity() {
    showModal(`<h2>Activity log</h2>${logHtml(50)}<div class="actions"><button class="sbtn" data-action="close-modal">Close</button></div>`);
  }
  async function supportText() {
    const i = await api.info();
    const lines = [
      `Warchief Launcher ${D.launcher.version}`,
      `System: ${i.os || ''} ${i.arch || ''}`.trim(),
      `App: ${i.electron === 'browser preview' ? 'browser preview' : 'Electron ' + i.electron}`,
      `Theme: ${S.theme}`,
      `Update channel: ${S.channel === 'beta' && canBeta() ? 'Beta' : 'Stable'}`,
      ...(accessOn() ? [`Discord login: ${!AC.loggedIn ? 'logged out' : !AC.me ? 'logged in (offline)' : isMember() ? 'member' + (isTester() ? ', tester' : '') : AC.me.inServer ? 'in the server, no member role yet' : 'not in the server'}`] : []),
      `Addon list: ${{ online: 'online', preview: 'unpublished preview', cached: 'offline (saved copy)', none: 'not loaded' }[st.catalogSource] || 'loading'}${D.publishedAt ? ', published ' + fmtTime(D.publishedAt) : ''}`, ''
    ];
    D.games.forEach(g => (S.dirs[g.id] || []).forEach((d, k) => lines.push(`${g.name} folder ${k + 1}: ${d} (${dirOk(d) ? 'found' : 'not found'})`)));
    lines.push('', 'Addons:');
    D.products.forEach(p => lines.push(`  ${p.name} [${game(p.game).name}]: installed ${installedOf(p) || 'no'}, latest ${latestOf(p)}`));
    lines.push('', 'Recent activity:');
    P.log.slice(0, 8).forEach(l => lines.push(`  ${fmtTime(l.t)}  ${l.text}`));
    return lines.join('\n');
  }
  async function supportModal() {
    const txt = await supportText();
    showModal(`<h2>Support info</h2><p class="muted">Paste this into Discord when you report a bug.</p><textarea class="support" id="support-text" readonly aria-label="Support info">${esc(txt)}</textarea>
      <div class="actions"><button class="sbtn" data-action="close-modal">Close</button><button class="pbtn" data-action="copy-support">${ti('copy')} Copy</button></div>`);
  }
  async function copySupport() {
    const el = document.getElementById('support-text'); if (!el) return;
    try { await navigator.clipboard.writeText(el.value); }
    catch { el.select(); document.execCommand('copy'); }
    toast('Copied. Paste it into Discord.');
  }

  // A few steps that show where everything is
  const TOUR = [
    ['My Addons', 'The bar at the top holds Warchiefs War Diary and its plugins. Click one to pick it. A small arrow on an icon means an update is ready; a faded icon isn\'t installed yet. More plugins hide behind the +.'],
    ['The big button', 'On the left, under the addon\'s picture: pick the game version and the release, then press Install, Update or Play. The gear next to it checks for updates, repairs, rolls back, opens the folder or uninstalls.'],
    ['Home', 'News from the Warchief team, the countdown banner, and the latest news, to-do cards and Discord posts. The buttons at the top open Discord, CurseForge, GitHub and the release notes.'],
    ['To-do', 'See what the team is working on, and vote on what matters most to you.'],
    ['The bell and Discord', 'The bell lists updates, news, to-do changes and Discord posts. The Discord panel on the right shows who\'s online. Pop it out into its own window, or close it and bring it back with the Discord button.']
  ];
  function tour(i) {
    const k = Math.max(0, Math.min(TOUR.length - 1, i));
    const [title, text] = TOUR[k];
    showModal(`<span class="kicker">TOUR · ${k + 1} OF ${TOUR.length}</span><h2>${esc(title)}</h2><p>${esc(text)}</p>
      <div class="actions">${k ? `<button class="sbtn" data-action="tour" data-i="${k - 1}">Back</button>` : '<button class="sbtn" data-action="close-modal">Close</button>'}
      ${k < TOUR.length - 1 ? `<button class="pbtn" data-action="tour" data-i="${k + 1}">Next</button>` : '<button class="pbtn" data-action="close-modal">Done</button>'}</div>`);
  }

  // Menus: the logo menu, the account, the plugins behind the +, the gear by the big button, more links, the bell
  const EXT = 'ext';
  function menuItems(which) {
    const loggedIn = AC.loggedIn;
    switch (which) {
      case 'main': return [
        ['go-options', 'Options', 'settings'], ['launcher-update', 'Launcher updates', 'file-description'], '-',
        loggedIn && AC.me ? ['discord-profile', 'My Discord profile', 'user-circle', EXT] : ['login', 'Log in with Discord', 'brand-discord'],
        ...(D.links.support ? [['open-link:support', 'Support', 'help-circle', EXT]] : []),
        ['join-discord', 'Discord server', 'brand-discord', EXT],
        ...(D.links.curseforge ? [['open-link:curseforge', 'CurseForge page', 'box', EXT]] : []), '-',
        ...(D.access && D.access.bugReports ? [['report-bug', 'Report a bug', 'bug']] : []),
        ['activity', 'Activity log', 'list'], ['tour', 'Take the tour', 'flag'], '-',
        ...(loggedIn ? [['logout', 'Log out', 'logout']] : []), ['exit', 'Exit', 'x'], 'social'
      ];
      case 'account': return [['go-account', 'My account', 'user-circle'], ['discord-profile', 'My Discord profile', 'id-badge-2', EXT], ['join-discord', 'Open the Warchief Discord', 'brand-discord', EXT], ['acct-recheck', 'Check my membership', 'refresh'], '-', ['logout', 'Log out', 'logout']];
      case 'account-out': return [['login', 'Log in with Discord', 'brand-discord'], ['join-discord', 'Join our Discord', 'users', EXT]];
      case 'gear': {
        const ups = D.products.filter(p => statusOf(p) === 'update').length;
        return [['check-updates', 'Check for updates', 'refresh'], ...(ups > 1 ? [['update-all', `Update all (${ups})`, 'download']] : []),
          ['repair', 'Scan and repair', 'tool'], ['rollback', 'Roll back to an older release', 'history'], ['show-folder', 'Show in folder', 'folder'],
          ['changelog-sel', 'Release notes', 'list'], '-', ['uninstall', 'Uninstall', 'trash', 'danger']];
      }
      case 'more': return [
        ...(D.links.support ? [['open-link:support', 'Support', 'lifebuoy', EXT]] : []),
        ...(D.links.news ? [['open-link:news', 'News on the website', 'news', EXT]] : []),
        ['support-info', 'Copy support info', 'copy'], ['activity', 'Activity log', 'list'], '-',
        ['check-updates', 'Check for updates', 'refresh'], ['update-all', 'Update all', 'download']
      ];
      default: return [];
    }
  }
  function itemHtml(m) {
    if (m === '-') return '<hr>';
    if (m === 'social') {
      const s = [];
      if (inviteUrl()) s.push(`<button class="soc" data-action="join-discord" aria-label="Discord">${ti('brand-discord')}</button>`);
      if (D.links.curseforge) s.push(`<button class="soc" data-action="open-link" data-link="curseforge" aria-label="CurseForge">${ti('box')}</button>`);
      if (D.links.github) s.push(`<button class="soc" data-action="open-link" data-link="github" aria-label="GitHub">${ti('brand-github')}</button>`);
      return s.length ? `<hr><div class="socrow">${s.join('')}</div>` : '';
    }
    const [a, label, ic, flag] = m; const [act, arg] = a.split(':');
    return `<button class="${flag === 'danger' ? 'danger' : ''}" data-action="${act}"${arg ? ` data-link="${arg}"` : ''}>${ti(ic)}<span>${esc(label)}</span>${flag === EXT ? `<span class="mx">${ti('arrow-up-right')}</span>` : ''}</button>`;
  }
  function openMenu(btn, which) {
    if (!menuEl.hidden && menuEl.dataset.which === which) return closeMenu();
    if (!menuEl.hidden && menuEl.dataset.which === 'notif') markAllRead();
    menuEl.className = 'menu' + (which === 'notif' ? ' notif' : which === 'plugins' ? ' plugins' : '');
    if (which === 'notif') menuEl.innerHTML = notifMenu();
    else if (which === 'plugins') {
      const rest = gameProducts(curGame()).slice(BAR_MAX);
      menuEl.innerHTML = `<div class="mhead">MORE PLUGINS</div>${rest.map(p => `<button data-action="select" data-id="${esc(p.id)}">${iconHtml(p, 'mp-icon')}<span class="mp-name">${esc(p.name)}${st.scanned && !installedOf(p) ? '<small>Not installed</small>' : ''}</span></button>`).join('')}`;
    } else menuEl.innerHTML = menuItems(which).map(itemHtml).join('');
    const r = btn.getBoundingClientRect(), ar = app.getBoundingClientRect();
    menuEl.dataset.which = which; menuEl.hidden = false;
    if (which === 'gear') {
      // Opens above the big button, as wide as the left column
      const box = btn.closest('.split').getBoundingClientRect();
      menuEl.style.left = (box.left - ar.left) + 'px';
      menuEl.style.minWidth = box.width + 'px';
      menuEl.style.top = Math.max(4, box.top - ar.top - menuEl.offsetHeight - 6) + 'px';
      btn.setAttribute('aria-expanded', 'true');
      return;
    }
    menuEl.style.minWidth = '';
    menuEl.style.left = (r.left - ar.left) + 'px';
    menuEl.style.top = (r.bottom - ar.top + 4) + 'px';
    const maxLeft = ar.width - menuEl.offsetWidth - 6; // menus opened near the right edge stay inside the window
    if (parseFloat(menuEl.style.left) > maxLeft) menuEl.style.left = Math.max(0, maxLeft) + 'px';
  }
  function closeMenu() {
    if (menuEl.hidden) return;
    if (menuEl.dataset.which === 'notif') markAllRead();
    menuEl.hidden = true; menuEl.dataset.which = '';
    const g = document.querySelector('.split-gear[aria-expanded]'); if (g) g.removeAttribute('aria-expanded');
  }

  // ---------- Discord login for downloads ----------
  // Members of the Warchief Discord download every addon and plugin for free. Without logging in you can still look
  // around and update the launcher, but downloads stay locked, with a reminder. Switched on in the Admin
  // (Members & access). The login itself happens in account.js; these screens never see the login pass.
  const AC = { service: false, loggedIn: false, me: null, offline: false, busy: false, loaded: false, lastCheck: 0, checkedAt: null };
  const accessOn = () => !!D.access;
  const isMember = () => !!(AC.me && AC.me.member);
  const isTester = () => !!(AC.me && AC.me.tester);
  const canBeta = () => !accessOn() || isTester();
  const firstName = () => (AC.me && AC.me.user ? AC.me.user.name : '');
  const avatar = () => (AC.me && AC.me.user && /^https:\/\/cdn\.discordapp\.com\//.test(AC.me.user.avatar || '') ? AC.me.user.avatar : '');
  // Why a download is locked: '' when it isn't, else wait (still checking), login, member (not in the server),
  // role (in the server, no member role yet), tester or offline.
  function lockOf(p, beta) {
    if (!accessOn() || !p) return '';
    const level = beta ? 'testers' : p.access || 'members';
    if (level === 'everyone') return '';
    if (!AC.loaded) return 'wait';
    if (!AC.loggedIn) return 'login';
    if (!AC.me) return 'offline';
    if (!AC.me.inServer) return 'member';
    if (!AC.me.member) return 'role';
    if (level === 'testers' && !AC.me.tester) return 'tester';
    return '';
  }
  const LOCK_TIP = {
    login: 'Log in with Discord to download', member: 'Join the Warchief Discord to download', role: 'Get the Member role in the Warchief Discord to download',
    tester: 'For Testers on the Warchief Discord', offline: "Can't check your Discord membership right now"
  };

  async function refreshAccount(fresh) {
    if (!accessOn()) { AC.loaded = true; return false; }
    let r = null;
    try { r = await api.acctGet(!!fresh); } catch { r = null; }
    const was = isMember();
    Object.assign(AC, {
      service: !!(r && r.service), loggedIn: !!(r && r.loggedIn), me: (r && r.me) || null, offline: !!(r && r.offline),
      checkedAt: (r && r.checkedAt) || null, loaded: true, lastCheck: Date.now()
    });
    if (r && r.expired) toast('Your Discord login ran out. Log in again to download.');
    render();
    return !was && isMember();
  }
  async function login() {
    if (AC.busy) { api.acctLogin(); return toast('The login page is open in your browser.'); }
    AC.busy = true; render();
    toast('Finish logging in in your browser.');
    let r = null;
    try { r = await api.acctLogin(); } catch { r = { error: 'discord' }; }
    AC.busy = false;
    if (r && r.ok) {
      await refreshAccount(true);
      await loadCommunity();
      log(`Logged in with Discord as ${firstName() || 'you'}`); save(LS_PREV, P); render();
      return toast(isMember() ? `Welcome, ${firstName()}! Your downloads are unlocked.` : `Logged in as ${firstName() || 'you'}.`);
    }
    render();
    toast({ cancelled: 'Login cancelled.', timeout: 'The login took too long. Press Log in with Discord to try again.', 'not-set-up': "Discord login isn't set up yet." }[r && r.error]
      || "Couldn't log in right now. Try again in a minute.");
  }
  function logout() {
    confirmModal({
      title: 'Log out of Discord?', body: '<p>Your addons stay installed. You need to log in again to download updates.</p>', ok: 'Log out',
      onOk: async () => {
        try { await api.acctLogout(); } catch { /* already gone */ }
        Object.assign(AC, { loggedIn: false, me: null, offline: false, checkedAt: null });
        st.votes.mine = {};
        log('Logged out of Discord'); save(LS_PREV, P); render(); toast('Logged out');
      }
    });
  }
  async function recheck() {
    const became = await refreshAccount(true);
    if (became) toast('You\'re a member now. Your downloads are unlocked!');
    else if (isMember()) toast('All good. Your downloads are unlocked.');
    else if (!AC.loggedIn) toast('Log in with Discord first.');
    else if (!AC.me) toast("Couldn't reach the login service. Try again in a minute.");
    else toast(AC.me.inServer ? "You don't have the Member role yet." : "You're not in the Warchief Discord yet.");
  }
  const inviteUrl = () => (AC.me && AC.me.invite) || (D.access && D.access.invite) || D.links.discord || '';
  function joinDiscord() {
    const u = inviteUrl();
    if (!u) return toast('The Discord invite gets set in the Admin page.');
    api.openExternal(u);
    if (AC.loggedIn && !isMember()) toast('After joining, come back here. The launcher checks again by itself.');
  }
  function discordProfile() {
    const id = AC.me && AC.me.user && String(AC.me.user.id || '');
    if (!/^\d{5,25}$/.test(id || '')) return toast('Log in with Discord first.');
    api.openExternal('https://discord.com/users/' + id);
  }

  // What a locked button says when it's clicked.
  function lockModal(p, why) {
    const name = p ? esc(p.name) : 'addons';
    const join = `<button class="sbtn" data-action="join-discord">${ti('brand-discord')} Join our Discord</button>`;
    const again = `<button class="pbtn" data-action="acct-recheck-modal">${ti('refresh')} Check again</button>`;
    const M = {
      login: ['Log in to download', `<p>Log in with Discord to download ${name}. It's free for members of the Warchief Discord.</p><p class="muted">The launcher only sees your Discord name, picture and server roles.</p>`,
        `${join}<button class="pbtn" data-action="login">${ti('brand-discord')} Log in with Discord</button>`],
      member: ['Join the Warchief Discord', `<p>You're logged in as <b>${esc(firstName())}</b>, but you're not in the Warchief Discord yet. Joining is free, and members download every addon and plugin.</p><p class="muted">Joined already? Press Check again.</p>`, join + again],
      role: ['Almost there', '<p>You\'re in the Warchief Discord, but you don\'t have the Member role yet. Finish joining the server (read and accept the rules), then press Check again.</p>',
        `<button class="sbtn" data-action="join-discord">${ti('brand-discord')} Open Discord</button>${again}`],
      tester: ['For Testers', `<p>${name} is for Testers on the Warchief Discord right now. Ask in the Discord if you'd like to help test.</p>`,
        `<button class="sbtn" data-action="join-discord">${ti('brand-discord')} Open Discord</button><button class="pbtn" data-action="close-modal">OK</button>`],
      offline: ["Can't check right now", "<p>The launcher couldn't reach the login service to check your Discord membership. Check your internet connection and try again.</p>",
        `<button class="sbtn" data-action="close-modal">Close</button>${again}`]
    }[why];
    if (!M) return;
    showModal(`<h2>${M[0]}</h2>${M[1]}<div class="actions">${M[2]}</div>`);
  }

  // Downloads that need the Discord login are stopped here with an explanation; installer.js asks the login
  // service for the actual download link.
  function task(p, kind, done) {
    if (!accessOn() || kind === 'rollback' || kind === 'uninstall' || st.busy[p.id]) return runTask(p, kind, done);
    const why = lockOf(p, isBeta(p));
    if (why === 'wait') return toast('Checking your Discord login…');
    if (why) return lockModal(p, why);
    return runTask(p, kind, done);
  }

  // Options > Account
  function pAccount() {
    const join = `<button class="sbtn" data-action="join-discord">${ti('brand-discord')} Join our Discord</button>`;
    if (!AC.loggedIn) {
      return `<h1>Account</h1>
        <p class="lead">Log in with your Discord account. Members of the Warchief Discord download every addon and plugin for free.</p>
        <div class="row-actions"><button class="pbtn" data-action="login">${ti('brand-discord')} ${AC.busy ? 'Logging in…' : 'Log in with Discord'}</button>${join}</div>
        <p class="hint acct-note">The launcher only learns your Discord name, picture and server roles. It can't read your messages or post as you.</p>`;
    }
    const me = AC.me;
    if (!me) {
      return `<h1>Account</h1><p class="lead">You're logged in, but the launcher couldn't reach the login service to check your membership.</p>
        <div class="row-actions"><button class="pbtn" data-action="acct-recheck">${ti('refresh')} Try again</button><button class="sbtn" data-action="logout">${ti('logout')} Log out</button></div>`;
    }
    const av = avatar();
    const plan = isMember() ? `<span class="acct-plan ok">${ti('circle-check')} Warchief Member</span> <span class="muted">free with the Warchief Discord</span>`
      : me.inServer ? 'Guest. Finish joining the Warchief Discord to get the Member role.' : 'Guest. Join the Warchief Discord to become a member.';
    const badge = r => `<span class="role-badge" style="--rc:${/^#[0-9a-f]{6}$/i.test(r.color || '') ? r.color : 'var(--tx2)'}">${esc(r.name)}</span>`;
    return `<h1>Account</h1>
      <div class="acct-head">${av ? `<img class="acct-av big" src="${esc(av)}" alt="">` : `<span class="acct-av big none">${ti('user')}</span>`}
        <div><div class="acct-big">${esc(me.user.name)}</div>${me.user.username && me.user.username !== me.user.name ? `<div class="muted">@${esc(me.user.username)}</div>` : ''}</div></div>
      <dl class="acct-facts">
        <dt>Plan</dt><dd>${plan}</dd>
        <dt>Member since</dt><dd>${me.inServer && me.joinedAt ? esc(fmtDate(me.joinedAt)) : '—'}</dd>
        <dt>Roles</dt><dd>${me.roles.length ? me.roles.map(badge).join('') : '<span class="muted">None yet</span>'}</dd>
        <dt>Beta versions</dt><dd>${isTester() ? 'Yes. Switch to the beta channel in Downloads.' : '<span class="muted">For Testers</span>'}</dd>
        <dt>Last checked</dt><dd>${AC.checkedAt ? esc(fmtTime(AC.checkedAt)) : '—'}${AC.offline ? ` <span class="chip sm dashed">${ti('cloud-off')} Offline</span>` : ''}</dd>
      </dl>
      <div class="row-actions">${isMember() ? '' : join}<button class="sbtn" data-action="discord-profile">${ti('id-badge-2')} My Discord profile ${ti('arrow-up-right')}</button><button class="sbtn" data-action="acct-recheck">${ti('refresh')} Check again</button><button class="sbtn" data-action="logout">${ti('logout')} Log out</button></div>`;
  }

  // Report a bug: posted in the bug reports channel on Discord by the Warchief bot.
  function reportBug() {
    if (!AC.loggedIn) {
      return showModal(`<h2>Report a bug</h2><p>Log in with Discord to send a bug report. It's posted in the bug reports channel on the Warchief Discord, so we can ask you about it.</p>
        <div class="actions"><button class="sbtn" data-action="close-modal">Not now</button><button class="pbtn" data-action="login">${ti('brand-discord')} Log in with Discord</button></div>`);
    }
    if (AC.me && !AC.me.inServer) return lockModal(null, 'member');
    const opts = [['launcher', 'Warchief Launcher itself'], ...D.products.map(p => [p.id, p.name])];
    showModal(`<h2>Report a bug</h2>
      <div class="bug-row">
        <div class="field"><div class="field-title">What is it about?</div><select class="wide" id="bug-product" aria-label="What is it about?">${opts.map(([v, l]) => `<option value="${esc(v)}" ${v === st.sel ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></div>
        <div class="field"><div class="field-title">How often?</div><select class="wide" id="bug-often" aria-label="How often does it happen?"><option value="always">Every time</option><option value="sometimes" selected>Sometimes</option><option value="once">It happened once</option></select></div>
      </div>
      <div class="field"><div class="field-title">What happened?</div><textarea class="bug-text" id="bug-text" maxlength="3500" aria-label="What happened?" placeholder="The first line becomes the title of the post on Discord."></textarea></div>
      <div class="field"><div class="field-title">How can we make it happen? <small>optional</small></div><textarea class="bug-text short" id="bug-steps" maxlength="1500" aria-label="How can we make it happen?" placeholder="1. Open the Compass&#10;2. Reload the UI&#10;3. …"></textarea></div>
      <div class="field"><div class="field-title">What should have happened? <small>optional</small></div><input class="bug-text line" id="bug-expected" maxlength="500" aria-label="What should have happened?"></div>
      <label class="choice"><input type="checkbox" id="bug-info" checked><span>Attach my support info <small>versions, game folders and recent activity</small></span></label>
      <p class="hint">It's posted in #bug-reports on the Warchief Discord, and you're tagged so you see the team's answers.</p>
      <p class="bug-err" id="bug-err" hidden></p>
      <div class="actions"><button class="sbtn" data-action="close-modal">Cancel</button><button class="pbtn" data-action="report-send">${ti('send')} Send report</button></div>`);
    document.getElementById('bug-text').focus();
  }
  async function sendReport(btn) {
    const box = document.getElementById('bug-text'), err = document.getElementById('bug-err');
    if (!box || btn.disabled) return;
    const text = box.value.trim(), product = document.getElementById('bug-product').value;
    if (text.length < 10) { err.textContent = 'Tell us a little more about what happened.'; err.hidden = false; return; }
    btn.disabled = true; btn.innerHTML = `${ti('loader-2')} Sending…`;
    const info = document.getElementById('bug-info').checked ? await supportText() : '';
    let r = null;
    const val = id => ((document.getElementById(id) || {}).value || '').trim();
    try { r = await api.acctReport({ product, text, info, steps: val('bug-steps'), expected: val('bug-expected'), often: val('bug-often'), installed: installedOf(prod(product)) || '' }); } catch { r = null; }
    if (r && r.ok) {
      box.value = ''; closeModal(); log('Sent a bug report'); save(LS_PREV, P);
      toast('Thanks! Your report was posted in the bug reports channel on Discord.');
      if (r.url) showModal(`<h2>Report sent</h2><p>Thanks! It's posted in #bug-reports on the Warchief Discord. You're tagged in it, so you'll see when the team answers.</p>
        <div class="actions"><button class="sbtn" data-action="close-modal">Close</button><button class="pbtn" data-action="open-url" data-url="${esc(r.url)}">${ti('brand-discord')} See it on Discord</button></div>`);
      return;
    }
    btn.disabled = false; btn.innerHTML = `${ti('send')} Send report`;
    err.textContent = (r && r.error) || "Couldn't send the report right now. Try again in a minute."; err.hidden = false;
  }

  document.addEventListener('input', e => { if (e.target.id === 'bug-text') { const er = document.getElementById('bug-err'); if (er) er.hidden = true; } });

  // Joined the Discord in another window? Coming back to the launcher checks again (at most every 15 seconds).
  window.addEventListener('focus', () => {
    if (!accessOn() || !AC.loaded || !AC.loggedIn || AC.busy || isMember() || Date.now() - AC.lastCheck < 15000) return;
    refreshAccount(true).then(became => { if (became) toast(`Welcome to the Warchief Discord, ${firstName()}! Your downloads are unlocked.`); });
  });
  setInterval(() => { if (accessOn() && AC.loggedIn && !AC.busy) refreshAccount(false); }, 30 * 60000);

  // ---------- Launcher updates: the green arrow, its tooltip, and the loader while it updates ----------
  // The installed launcher gets its updates from GitHub (main.js). Run from the folder it can't replace itself,
  // so "Launcher updates" asks GitHub for the newest version and says so.
  const updWrap = document.getElementById('upd-wrap'), updTip = document.getElementById('upd-tip'), skel = document.getElementById('upd-skel');
  const UPD = { s: { state: 'idle' }, packaged: false, busy: false, t0: 0, minMs: 0, restarting: false };
  const UPD_SHOW = ['available', 'downloading', 'ready', 'error'];
  function showUpdate(s) {
    if (s) UPD.s = s;
    const state = UPD.s.state, v = UPD.s.version ? ` (v${UPD.s.version})` : '';
    updWrap.hidden = UPD.busy || !UPD_SHOW.includes(state);
    updTip.textContent = state === 'error'
      ? "The last launcher update didn't finish. Click to try again."
      : state === 'ready' ? `A new version of Warchief Launcher${v} is ready. Click to update now.`
        : `A new version of Warchief Launcher${v} is out. Click to update now.`;
    if (UPD.busy) updateProgress();
    paintBell();
  }
  async function launcherCheck(quiet) {
    if (UPD.busy) return false;
    if (!UPD.packaged) {
      let r = null;
      try { r = await api.updateLatest(); } catch { r = null; }
      if (r && r.version && V.cmp(r.version, D.launcher.version) > 0) {
        showModal(`<h2>Warchief Launcher v${esc(r.version)} is out</h2>
          <p>This copy runs from its folder (v${esc(D.launcher.version)}), so it can't update itself. The installed launcher updates by itself.</p>
          <div class="actions"><button class="sbtn" data-action="close-modal">Close</button>${r.url ? `<button class="pbtn" data-action="open-url" data-url="${esc(r.url)}">${ti('external-link')} Open the release page</button>` : ''}</div>`);
        return true;
      }
      if (!quiet) {
        toast(r && r.none ? 'There is no launcher release on GitHub yet. Build one in the Admin, Launcher page.'
          : r && r.version ? `The launcher is up to date (v${D.launcher.version})` : "Couldn't reach GitHub to check for a launcher update. Try again later.");
      }
      return false;
    }
    let s = null;
    try { s = await api.updateCheck(); } catch { s = null; }
    if (s) showUpdate(s);
    const found = !!(s && UPD_SHOW.includes(s.state) && s.state !== 'error');
    if (found) toast(`A new version of the launcher is out${s.version ? ` (v${s.version})` : ''}. Click the green arrow to update.`);
    else if (!quiet) toast(s && s.state === 'error' ? "Couldn't check for a launcher update right now. Try again later." : `The launcher is up to date (v${D.launcher.version})`);
    return found;
  }
  // The loader: the launcher's own layout as grey shapes, with the message on top
  function skelHtml() {
    return `<div class="sk-addons"><span class="sk sk-label"></span><span class="sk sk-ab"></span><span class="sk sk-ab"></span><span class="sk sk-ab"></span><span class="sk sk-ab"></span></div>
      <div class="sk-body"><div class="sk-left"><span class="sk sk-art"></span><span class="sk sk-name"></span><span class="sk-grow"></span><span class="sk sk-sel"></span><span class="sk sk-sel"></span><span class="sk sk-play"></span></div>
        <div class="sk-right"><div class="sk-chips"><span class="sk sk-chip"></span><span class="sk sk-chip"></span><span class="sk sk-chip"></span></div><span class="sk sk-slider"></span><span class="sk sk-banner"></span>
          <div class="sk-cards"><span class="sk sk-card"></span><span class="sk sk-card"></span><span class="sk sk-card"></span></div></div></div>
      <div class="sk-msg" role="status"><img class="sk-logo" src="../assets/wwd_logo_transparent.png" alt="">
        <div class="sk-title">Hang tight while we update your launcher for you</div><div class="sk-status" id="sk-status">Getting the new version…</div></div>`;
  }
  function updateProgress(text) {
    const el = document.getElementById('sk-status'); if (!el) return;
    if (text) { el.textContent = text; return; }
    const state = UPD.s.state;
    el.textContent = state === 'downloading' || state === 'available' ? `Getting the new version… ${UPD.s.percent || 0}%`
      : state === 'ready' ? 'Almost done…' : state === 'installing' ? 'Restarting the launcher…' : el.textContent;
  }
  async function startUpdate() {
    if (UPD.busy) return;
    UPD.busy = true; UPD.restarting = false; UPD.t0 = Date.now(); UPD.minMs = 5000 + Math.floor(Math.random() * 3001); // at least 5 to 8 seconds
    closeMenu(); closeModal();
    updWrap.hidden = true; toastEl.hidden = true;
    skel.innerHTML = skelHtml(); skel.hidden = false;
    let s = null;
    try { s = await api.updateDownload(); } catch { s = null; }
    if (s) showUpdate(s);
    updateWatch();
  }
  // Runs on every update message while the loader is up: waits for the download and the 5 to 8 seconds, then restarts.
  function updateWatch() {
    if (!UPD.busy) return;
    const state = UPD.s.state;
    if (state === 'error') return updateFailed(UPD.s.error);
    if (state !== 'ready' || UPD.restarting) return;
    UPD.restarting = true;
    setTimeout(async () => {
      updateProgress('Restarting the launcher…');
      let ok = false;
      try { ok = await api.updateRestart(); } catch { ok = false; }
      if (!ok) updateFailed("The new version wasn't ready to install.");
      else restartGuard(45000);
    }, Math.max(0, UPD.t0 + UPD.minMs - Date.now()));
  }
  // The launcher should be gone by now. If it isn't, the loader must not stay up forever.
  function restartGuard(ms) {
    setTimeout(() => {
      if (!UPD.busy) return;
      updateFailed("The launcher didn't restart by itself. Close it (right-click the tray icon, then Exit) and open it again to finish.");
    }, ms);
  }
  function updateFailed(why) {
    UPD.busy = false; UPD.restarting = false;
    skel.hidden = true; skel.innerHTML = '';
    showUpdate();
    showModal(`<h2>The launcher couldn't update</h2><p>${esc(why || 'Something went wrong while getting the new version.')}</p>
      <p class="muted">Your launcher still works as it is. Try again from the green arrow, or later.</p>
      <div class="actions"><button class="pbtn" data-action="close-modal">OK</button></div>`);
  }
  api.onUpdate(s => { showUpdate(s); updateWatch(); });

  // ---------- Tray menu: News, Play for each WoW version found, Options, Check for updates ----------
  let traySent = '';
  function syncTray() {
    const games = st.dirsChecked ? D.games.filter(g => installDir(g.id)).map(g => ({ id: g.id, label: `Play ${/^wow\b/i.test(g.name) ? g.name : 'WoW ' + g.name}` })) : [];
    const json = JSON.stringify(games);
    if (json === traySent) return;
    traySent = json;
    Promise.resolve(api.setTray({ games })).catch(() => { traySent = ''; });
  }
  api.onTray(async a => {
    if (!a) return;
    closeMenu();
    if (a.do === 'news') return go('news');
    if (a.do === 'options') return go('options');
    if (a.do === 'play') {
      const p = D.products.find(x => x.game === a.game && x.type === 'main') || D.products.find(x => x.game === a.game) || { game: a.game };
      if (game(p.game)) play(p);
      return;
    }
    if (a.do === 'check') { go('home'); await checkUpdates(); await launcherCheck(true); }
  });

  // ---------- Events ----------
  function pick(id) {
    const p = prod(id); if (!p) return;
    st.sel = id; st.game = p.game; S.lastAddon = id; S.lastGame = p.game; save(LS_SET, S);
    if (st.view !== 'home' && st.view !== 'news' && st.view !== 'todo' && st.view !== 'help') go('home'); else render();
  }
  document.addEventListener('click', e => {
    // Links inside news posts and release notes open in the normal browser.
    const mdLink = e.target.closest('.md a');
    if (mdLink) {
      e.preventDefault();
      const href = mdLink.getAttribute('href') || '';
      if (/^https:\/\//i.test(href)) api.openExternal(href);
      return;
    }
    const el = e.target.closest('[data-action]');
    if (!el || el.disabled) {
      if (!e.target.closest('#menu')) closeMenu();
      if (e.target === overlay && !(document.getElementById('bug-text') || {}).value) closeModal();
      return;
    }
    const a = el.dataset.action, id = el.dataset.id, p = id ? prod(id) : null;
    if (a !== 'menu' && !(a === 'notif-read')) closeMenu();
    switch (a) {
      case 'menu': return openMenu(el, el.dataset.menu);
      case 'nav-back': return navBack();
      case 'nav-fwd': return navFwd();
      case 'go-home': return go('home');
      case 'go-news': go('news'); return showPost(el.dataset.post);
      case 'go-todo': return go('todo');
      case 'go-help': return go('help');
      case 'go-options': return go('options');
      case 'page': st.page = el.dataset.page; return go('options', { page: el.dataset.page });
      case 'goto-dirs': return go('options', { page: 'directories' });
      case 'go-account': return go('options', { page: 'account' });
      case 'select': return pick(id);
      case 'select-update': pick(id); return p && task(p, 'update');
      case 'install': st.sel = id; return install(p);
      case 'update': st.sel = id; return task(p, 'update');
      case 'locked': { st.sel = id; const w = lockOf(p, isBeta(p)); return w === 'wait' ? toast('Checking your Discord login…') : lockModal(p, w); }
      case 'slide': st.slide = Number(el.dataset.i) || 0; return render();
      case 'slide-pause': st.paused = !st.paused; return render();
      case 'vote': return vote(el.dataset.card, Number(el.dataset.v));
      case 'notif-read': markAllRead(); return openMenu(document.querySelector('.bell'), 'notif-refresh');
      case 'dw-open': return setDiscordMode('docked');
      case 'tour': return tour(Number(el.dataset.i) || 0);
      case 'login': closeModal(); return login();
      case 'login-cancel': return api.acctCancel();
      case 'logout': return logout();
      case 'join-discord': return joinDiscord();
      case 'discord-profile': return discordProfile();
      case 'acct-recheck': return recheck();
      case 'acct-recheck-modal': closeModal(); return recheck();
      case 'report-bug': return reportBug();
      case 'report-send': return sendReport(el);
      case 'play': return play(p);
      case 'changelog': return changelog(p);
      case 'changelog-sel': return changelog(curProduct());
      case 'check-updates': return checkUpdates();
      case 'update-all': return updateAll();
      case 'repair': return repair();
      case 'rollback': return rollback();
      case 'uninstall': return uninstall();
      case 'show-folder': return showFolder();
      case 'open-link': return openLink(el.dataset.link);
      case 'activity': return activity();
      case 'support-info': return supportModal();
      case 'copy-support': return copySupport();
      case 'launcher-update': return launcherCheck(false);
      case 'launcher-update-now': return UPD.packaged && UPD_SHOW.includes(UPD.s.state) ? startUpdate() : launcherCheck(false);
      case 'open-url': { const u = el.dataset.url || ''; if (/^https:\/\//.test(u)) api.openExternal(u); return closeModal(); }
      case 'open-url-keep': { const u = el.dataset.url || ''; if (/^https:\/\//.test(u)) api.openExternal(u); return; }
      case 'exit': return api.exit();
      case 'win-min': return api.minimize();
      case 'win-close': return closeWindow();
      case 'close-modal': return closeModal();
      case 'modal-ok': { const f = modalOk; closeModal(); if (f) f(); return; }
      case 'theme': S.theme = el.dataset.theme; save(LS_SET, S); return render();
      case 'detect': return detect(false);
      case 'dir-edit': return dirEdit(el.dataset.game, Number(el.dataset.i));
      case 'dir-add': return dirAdd(el.dataset.game);
      case 'dir-remove': return dirRemove(el.dataset.game, Number(el.dataset.i));
      case 'dir-defaults': return dirDefaults();
    }
  });

  document.addEventListener('change', e => {
    const t = e.target;
    // The two dropdowns in the left column
    const ch = t.dataset && t.dataset.actionChange;
    if (ch === 'game') {
      st.game = t.value; S.lastGame = t.value;
      const first = gameProducts(t.value)[0]; if (first) { st.sel = first.id; S.lastAddon = first.id; }
      save(LS_SET, S); return render();
    }
    if (ch === 'channel') {
      if (t.value === 'beta-locked') { render(); return lockModal(curProduct(), AC.loggedIn ? 'tester' : 'login'); }
      const v = t.value === 'beta' ? 'beta' : 'stable';
      if (v !== S.channel) { S.channel = v; log(`Switched to the ${v === 'beta' ? 'beta' : 'stable'} channel`); save(LS_PREV, P); save(LS_SET, S); }
      return render();
    }
    const key = t.dataset && t.dataset.setting;
    if (!key) return;
    let v = t.type === 'checkbox' ? t.checked : t.value;
    if (t.dataset.num) v = Number(v);
    setPath(S, key, v); save(LS_SET, S);
    if (key === 'startWithWindows') api.setLoginItem(v);
    if (key === 'launcherUpdates') api.updateMode(v);
    if (key === 'discordMode') S.showWidget = v !== 'closed';
    if (key === 'channel') { log(`Switched to the ${v === 'beta' ? 'beta' : 'stable'} channel`); save(LS_PREV, P); }
    render();
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { closeMenu(); if (!overlay.hidden) closeModal(); }
    if (e.altKey && e.key === 'ArrowLeft') navBack();
    if (e.altKey && e.key === 'ArrowRight') navFwd();
  });
  // The mouse's back and forward buttons
  window.addEventListener('mouseup', e => { if (e.button === 3) navBack(); if (e.button === 4) navFwd(); });
  window.addEventListener('resize', () => { if (!menuEl.hidden) closeMenu(); });

  // ---------- Start ----------
  async function start() {
    try {
      const info = await api.info();
      if (info && info.version) D.launcher.version = info.version;
      UPD.packaged = !!(info && info.packaged);
    } catch { /* keep the starting version */ }
    try { localStorage.removeItem('wl.updPreview'); localStorage.removeItem('wl.preview.v1'); } catch { /* old leftovers */ }
    api.updateMode(S.launcherUpdates);
    try { showUpdate(await api.updateGet()); } catch { /* no updates in this build */ }
    render();
    await loadCatalog();
    await refreshAccount(false);
    await checkDirs(allDirs());
    st.dirsChecked = true;
    if (S.firstRun) {
      S.firstRun = false; save(LS_SET, S);
      if (D.games.some(g => !installDir(g.id))) await detect(true);
    }
    await scanAll();
    await loadCommunity();
    render();
    autoUpdate();
  }
  start();
})();

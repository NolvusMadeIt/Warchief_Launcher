// The Discord panel: your account, who's online in the Warchief Discord (voice channels and members), search,
// and Join. Everything it shows comes from the main program (widget.js) as 'dw:state'.
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ti = n => `<i class="ti ti-${n}" aria-hidden="true"></i>`;
  const api = window.dw || { cmd: () => {}, search: async () => ({ ok: false }), grip: () => {}, onState: () => {} };
  let S = { mode: 'docked', account: { state: 'loading' }, data: null };
  let sel = '';          // the member picked in the list
  let found = null;      // people found in the whole server: null = no search yet
  let searching = false, lastQ = '';

  const STATUS = { online: 'Online', idle: 'Idle', dnd: 'Do not disturb' };
  function applyColors(c) {
    const r = document.documentElement.style;
    const map = { bg: '--bg', bar: '--bar', side: '--side', line: '--line', tx: '--tx', tx2: '--tx2', frameTop: '--frame-top', acc: '--acc', ink: '--ink', link: '--link', sel: '--sel', hover: '--hover' };
    for (const [k, v] of Object.entries(map)) if (c && /^#[0-9a-f]{6}$/i.test(c[k] || '')) r.setProperty(v, c[k]);
  }
  const av = (url, name, cls) => url ? `<img class="${cls}" src="${esc(url)}" alt="">` : `<span class="${cls} none">${esc(String(name || '?').slice(0, 2).toUpperCase())}</span>`;

  function renderAcct() {
    const a = S.account || {};
    if (a.state === 'in') {
      return `<button class="me" id="me" aria-label="Your account">${av(a.avatar, a.name, 'me-av')}<span class="me-dot"></span>
          <span class="me-who"><span class="me-name">${esc(a.name)} ${ti('chevron-down')}</span><span class="me-role" ${a.roleColor ? `style="color:${a.roleColor}"` : ''}>${esc(a.role)}</span></span></button>
        <button class="dbtn-ic" id="profile" aria-label="Open your Discord profile">${ti('external-link')}</button>`;
    }
    const msg = { loading: 'Checking your Discord login…', busy: 'Finish logging in in your browser…', offline: "Can't reach Discord right now" }[a.state];
    if (msg) return `<span class="me-av none">${ti('brand-discord')}</span><span class="me-who"><span class="me-name">Discord</span><span class="me-role">${esc(msg)}</span></span>`;
    return `<span class="me-av none">${ti('user')}</span><span class="me-who"><span class="me-name">Guest</span><span class="me-role">Not logged in</span></span>
      <button class="login" id="login">${ti('brand-discord')} Log in</button>`;
  }

  function memberRow(m, real) {
    const on = sel === (real ? 'u:' : 'm:') + m.id;
    const sub = real ? (m.username && m.username !== m.name ? '@' + m.username : 'In the server') : m.game ? 'Playing ' + m.game : STATUS[m.status] || 'Online';
    return `<div class="mem ${on ? 'on' : ''}" data-pick="${real ? 'u:' : 'm:'}${esc(m.id)}" role="button" tabindex="0">
      <span class="mem-av">${av(m.avatar, m.name, 'mav')}${real ? '' : `<span class="sdot ${esc(m.status)}"></span>`}</span>
      <span class="mem-who"><span class="mem-name">${esc(m.name)}</span><span class="mem-sub">${esc(sub)}</span></span>
      ${on ? `<button class="msg" data-msg="${real ? 'u:' : 'm:'}${esc(m.id)}">Message ${ti('arrow-up-right')}</button>` : ''}</div>`;
  }

  function renderList() {
    const d = S.data;
    if (!d) return '<div class="note">Loading who\'s online…</div>';
    if (d.error === 'off') return '<div class="note">The server widget is turned off in Discord (Server Settings → Widget).</div>';
    if (d.error) return `<div class="note">Can't reach Discord right now. <button class="link" id="retry">Try again</button></div>`;
    const q = $('q').value.trim().toLowerCase();
    const members = (d.members || []).filter(m => !q || m.name.toLowerCase().includes(q));
    let out = `<div class="srv"><img src="../assets/wwd_logo_transparent.png" alt=""><span class="srv-name">${esc(d.name || 'Warchief Discord')}</span><span class="srv-on"><span class="sdot online"></span>${d.online} online</span></div>`;
    const chans = (d.channels || []).slice().sort((a, b) => a.position - b.position);
    if (chans.length && !q) {
      out += `<div class="grp">${ti('chevron-down')} Voice channels · ${chans.length}</div>`;
      out += chans.map(c => {
        const inside = (d.members || []).filter(m => m.channel === c.id);
        return `<div class="voice">${ti('volume')} ${esc(c.name)}</div>${inside.map(m => `<div class="voice-mem">${av(m.avatar, m.name, 'vav')} ${esc(m.name)}</div>`).join('')}`;
      }).join('');
    }
    out += `<div class="grp">${ti('chevron-down')} ${q ? 'Online matches' : 'Online'} · ${members.length}</div>`;
    out += members.length ? members.map(m => memberRow(m, false)).join('') : `<div class="note">${q ? 'Nobody online by that name.' : 'Nobody is online right now.'}</div>`;
    if (q) {
      if (S.account.state !== 'in') out += '<div class="note">Log in with Discord to search everyone in the server.</div>';
      else if (searching) out += '<div class="note">Searching the whole server…</div>';
      else if (found && found.length) out += `<div class="grp">${ti('chevron-down')} In the server · ${found.length}</div>` + found.map(m => memberRow(m, true)).join('');
      else if (found) out += '<div class="note">Nobody else in the server by that name.</div>';
    }
    return out;
  }

  function render() {
    document.body.classList.toggle('popped', S.mode === 'popped');
    $('pop').innerHTML = S.mode === 'popped' ? ti('layout-sidebar-right-collapse') : ti('picture-in-picture');
    $('pop').setAttribute('aria-label', S.mode === 'popped' ? 'Stick it back to the launcher' : 'Pop out into its own window');
    $('acct').innerHTML = renderAcct();
    $('list').innerHTML = renderList();
    $('grip').hidden = S.mode !== 'docked';
    $('join').disabled = !S.invite;
  }

  // Message: the server widget hides people's real account, so the bot finds them by name first.
  async function message(key) {
    const [kind, id] = [key.slice(0, 1), key.slice(2)];
    if (kind === 'u') return api.cmd({ do: 'profile', id });
    if (S.account.state !== 'in') return api.cmd({ do: 'login' });
    const m = ((S.data || {}).members || []).find(x => x.id === id);
    if (!m) return;
    const r = await api.search(m.name);
    const list = r && r.ok && r.data && Array.isArray(r.data.people) ? r.data.people : [];
    const n = m.name.toLowerCase();
    const hit = list.find(p => [p.name, p.username].some(x => String(x || '').toLowerCase() === n)) || list[0];
    if (hit) api.cmd({ do: 'profile', id: hit.id });
    else api.cmd({ do: 'open', url: S.invite || 'https://discord.com/app' });
  }

  let timer = null;
  $('q').addEventListener('input', () => {
    found = null; sel = '';
    $('list').innerHTML = renderList();
    clearTimeout(timer);
    const q = $('q').value.trim();
    if (q.length < 2 || S.account.state !== 'in') return;
    timer = setTimeout(async () => {
      lastQ = q; searching = true; $('list').innerHTML = renderList();
      const r = await api.search(q);
      if (lastQ !== $('q').value.trim()) return;
      searching = false;
      const online = new Set(((S.data || {}).members || []).map(m => m.name.toLowerCase()));
      found = r && r.ok && r.data && Array.isArray(r.data.people) ? r.data.people.filter(p => !online.has(String(p.name).toLowerCase())) : [];
      $('list').innerHTML = renderList();
    }, 350);
  });
  document.addEventListener('click', e => {
    const t = e.target.closest('button, [data-pick]');
    if (!t) return;
    if (t.dataset.msg) { e.stopPropagation(); return message(t.dataset.msg); }
    if (t.dataset.pick) { sel = sel === t.dataset.pick ? '' : t.dataset.pick; return ($('list').innerHTML = renderList()); }
    switch (t.id) {
      case 'pop': return api.cmd({ do: S.mode === 'popped' ? 'dock' : 'pop' });
      case 'close': return api.cmd({ do: 'close' });
      case 'invite': return api.cmd({ do: 'copy' });
      case 'join': return S.invite && api.cmd({ do: 'open', url: S.invite });
      case 'login': return api.cmd({ do: 'login' });
      case 'me': return api.cmd({ do: 'account' });
      case 'profile': return S.account.id && api.cmd({ do: 'profile', id: S.account.id });
      case 'retry': return api.cmd({ do: 'refresh' });
    }
  });
  document.addEventListener('keydown', e => {
    const t = e.target.closest && e.target.closest('[data-pick]');
    if (t && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); t.click(); }
  });
  // Resize grip: resizes the launcher (the panel follows)
  $('grip').addEventListener('pointerdown', e => {
    if (e.button !== 0) return;
    e.preventDefault(); $('grip').setPointerCapture(e.pointerId);
    api.grip('start');
    const move = () => api.grip('move');
    const up = () => { api.grip('end'); $('grip').removeEventListener('pointermove', move); $('grip').removeEventListener('pointerup', up); };
    $('grip').addEventListener('pointermove', move); $('grip').addEventListener('pointerup', up);
  });
  api.onState(s => {
    const prevServer = S.serverId;
    S = { ...S, ...s };
    if (prevServer && prevServer !== S.serverId) { sel = ''; found = null; }
    applyColors(S.colors);
    document.body.classList.toggle('light', !!S.light);
    render();
  });
  render();
})();

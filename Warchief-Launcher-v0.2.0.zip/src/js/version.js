// Compares addon version strings like 1.5.7, 1.5.7b, v1.4.9e and 1.5.8-beta1.
// Order: 1.5.7 < 1.5.7a < 1.5.7b < 1.5.8-beta1 < 1.5.8
(function () {
  'use strict';
  const PRE = { alpha: 1, beta: 2, rc: 3 };

  function parse(v) {
    const s = String(v || '').trim().replace(/^v/i, '');
    const m = s.match(/^(\d+(?:\.\d+)*)([a-z](?![a-z]))?(?:[-. ]?(alpha|beta|rc)[-. ]?(\d+)?)?/i);
    if (!m) return { nums: [0], letter: '', pre: null, preN: 0 };
    return {
      nums: m[1].split('.').map(Number),
      letter: (m[2] || '').toLowerCase(),
      pre: m[3] ? m[3].toLowerCase() : null,
      preN: m[4] ? Number(m[4]) : 0
    };
  }

  function cmp(a, b) {
    const A = parse(a), B = parse(b);
    const n = Math.max(A.nums.length, B.nums.length);
    for (let i = 0; i < n; i++) {
      const x = A.nums[i] || 0, y = B.nums[i] || 0;
      if (x !== y) return x < y ? -1 : 1;
    }
    if (A.letter !== B.letter) return A.letter < B.letter ? -1 : 1;
    if (A.pre !== B.pre) {
      if (!A.pre) return 1;
      if (!B.pre) return -1;
      return PRE[A.pre] < PRE[B.pre] ? -1 : 1;
    }
    if (A.preN !== B.preN) return A.preN < B.preN ? -1 : 1;
    return 0;
  }

  const api = { parse, cmp };
  if (typeof window !== 'undefined') window.WLVersion = api;
  if (typeof module !== 'undefined') module.exports = api;
})();

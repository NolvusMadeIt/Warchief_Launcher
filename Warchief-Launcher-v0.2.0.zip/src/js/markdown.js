// Turns Markdown (news posts, release notes) into safe HTML.
// Used by the launcher and by the Admin's live preview, so both look the same.
(function () {
  'use strict';
  const escape = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function render(md) {
    const src = String(md || '');
    if (!src.trim()) return '';
    if (!window.marked || !window.DOMPurify) return '<p>' + escape(src).replace(/\n/g, '<br>') + '</p>';
    const html = window.marked.parse(src, { gfm: true, breaks: true, async: false });
    return window.DOMPurify.sanitize(html, {
      ALLOWED_URI_REGEXP: /^(?:https:|mailto:|#)/i,
      FORBID_TAGS: ['style', 'script', 'iframe', 'object', 'embed', 'form', 'input', 'button', 'textarea', 'select', 'video', 'audio', 'svg', 'math'],
      FORBID_ATTR: ['style', 'class', 'id', 'srcset']
    });
  }

  // Plain-text start of a post, for small cards.
  function excerpt(md, max) {
    const limit = max || 140;
    const t = String(md || '')
      .replace(/```[\s\S]*?```/g, ' ')
      .replace(/^\s{0,3}#{1,6}\s+(.+?)[\s#]*$/gm, (m, t) => (/[.!?:]$/.test(t) ? t : t + ':'))
      .replace(/<[^>]*>/g, ' ')
      .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
      .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
      .replace(/^\s{0,3}(#{1,6}|>|[-*+]|\d+\.)\s+/gm, '')
      .replace(/^\s*([-*_]\s*){3,}$/gm, ' ')
      .replace(/(\*\*|__|~~|`)/g, '')
      .replace(/(^|\s)[*_]([^*_]+)[*_](?=\s|$|[.,!?])/g, '$1$2')
      .replace(/\s+/g, ' ').trim();
    return t.length > limit ? t.slice(0, limit).replace(/\s+\S*$/, '') + '…' : t;
  }

  window.WLMarkdown = { render, excerpt };
})();

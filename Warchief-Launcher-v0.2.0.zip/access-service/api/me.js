// Who is logged in, and what are they allowed to download? The launcher asks when it starts and every so often.
'use strict';
const { send, session, newSession, whoIs, avatarUrl, query, DAY, bad, handle } = require('../lib/core');

module.exports = handle(async (req, res) => {
  const s = session(req);
  if (!s) throw bad(401, 'Log in with Discord again.', { need: 'login' });
  const who = await whoIs(s, query(req).get('fresh') === '1');
  send(res, 200, {
    user: { id: s.sub, name: who.nick || s.name, username: s.name, avatar: avatarUrl(s.sub, s.avatar) },
    inServer: who.inServer, member: who.member, tester: who.tester,
    joinedAt: who.joinedAt, roles: who.roles, invite: who.invite,
    plan: who.member ? 'Warchief Member' : null,
    checkedAt: new Date().toISOString(),
    // Keeps people logged in while they keep using the launcher.
    token: Date.now() - (s.iat || 0) > DAY ? newSession(s) : undefined
  });
});

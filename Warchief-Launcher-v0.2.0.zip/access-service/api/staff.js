// For the Admin's Tickets and To-do pages: only people with a staff role (set on the Tickets page) get in.
// ?do=me | guild | status | tickets | ticket | reply | claim | close | panel | todo | setup | connect
'use strict';
const { C, send, query, body, session, whoIs, avatarUrl, dj, discord, cached, forget, catalog, publicUrl, bad, handle } = require('../lib/core');
const tk = require('../lib/tickets');

const B = tk.B;
const NEED = B.VIEW | B.SEND | B.EMBED | B.ATTACH | B.HISTORY | B.MANAGE_CHANNELS;
const idOk = v => /^\d{5,25}$/.test(String(v || ''));

// The server owner and anyone with an Administrator role always count as staff.
async function bossOf(userId, roleIds) {
  const [g, roles] = await Promise.all([
    cached('guild', 600000, async () => { const r = await dj('GET', `/guilds/${C.guildId()}`); if (r.status !== 200) throw new Error('guild ' + r.status); return { owner: r.data.owner_id }; }).catch(() => ({ owner: '' })),
    cached('roleperms', 60000, async () => { const r = await dj('GET', `/guilds/${C.guildId()}/roles`); if (r.status !== 200) throw new Error('roles ' + r.status); return r.data.map(x => ({ id: x.id, p: x.permissions || '0' })); }).catch(() => [])
  ]);
  if (g.owner && g.owner === userId) return true;
  return roles.some(r => (roleIds || []).includes(r.id) && (BigInt(r.p) & B.ADMIN) === B.ADMIN);
}
async function staffOnly(req) {
  const s = session(req);
  if (!s) throw bad(401, 'Log in with Discord first.', { need: 'login' });
  const who = await whoIs(s, true);
  const T = await tk.settings();
  if (!who.inServer || !(tk.isStaff(T, who.roleIds) || await bossOf(s.sub, who.roleIds))) throw bad(403, 'Only the Warchief team (the staff roles on the Tickets page) can use this.', { need: 'staff' });
  return { s, who, T, me: { id: s.sub, name: who.nick || s.name, avatar: avatarUrl(s.sub, s.avatar) } };
}
// What the bot is allowed to do in the server (from its roles).
async function botPerms() {
  const [m, r] = await Promise.all([dj('GET', `/guilds/${C.guildId()}/members/${C.clientId()}`), dj('GET', `/guilds/${C.guildId()}/roles`)]);
  if (m.status !== 200 || r.status !== 200) return 0n;
  const mine = new Set([C.guildId(), ...(m.data.roles || [])]);
  return r.data.filter(x => mine.has(x.id)).reduce((a, x) => a | BigInt(x.permissions || '0'), 0n);
}
async function upsertMessage(channelId, messageId, payload) {
  if (!idOk(channelId)) throw bad(400, 'Pick a channel first.');
  if (idOk(messageId)) {
    const r = await dj('PATCH', `/channels/${channelId}/messages/${messageId}`, payload);
    if (r.status === 200) return { channelId, messageId: r.data.id, updated: true };
  }
  const r = await dj('POST', `/channels/${channelId}/messages`, payload);
  if (r.status !== 200) throw bad(502, r.status === 403 ? "The bot isn't allowed to post in that channel." : `Discord said ${r.status} when posting.`);
  return { channelId, messageId: r.data.id, updated: false };
}
const names = async ids => Object.fromEntries(await Promise.all([...new Set(ids.filter(Boolean))].map(async id => [id, await tk.memberName(id)])));

const ACTIONS = {
  async me(req) { const { me, who } = await staffOnly(req); return { staff: true, user: me, roles: who.roles }; },

  // Channels and roles for the setup dropdowns
  async guild(req) {
    await staffOnly(req);
    const [chs, r] = await Promise.all([tk.guildChannels(), dj('GET', `/guilds/${C.guildId()}/roles`)]);
    const pick = c => ({ id: c.id, name: c.name, parent: c.parent_id || '', position: c.position });
    return {
      categories: chs.filter(c => c.type === 4).sort((a, b) => a.position - b.position).map(pick),
      channels: chs.filter(c => c.type === 0 || c.type === 5).sort((a, b) => a.position - b.position).map(pick),
      roles: r.status === 200 ? r.data.filter(x => !x.managed && x.id !== C.guildId()).sort((a, b) => b.position - a.position).map(x => ({ id: x.id, name: x.name, color: x.color ? '#' + x.color.toString(16).padStart(6, '0') : '' })) : []
    };
  },

  // Setup checklist: is Discord sending button clicks here, can the bot read messages and make channels?
  async status(req) {
    const { T } = await staffOnly(req);
    const app = await dj('GET', '/applications/@me');
    const perms = await botPerms();
    const want = publicUrl(req) + '/api/interactions';
    const admin = (perms & B.ADMIN) === B.ADMIN;
    return {
      interactionsUrl: app.status === 200 ? app.data.interactions_endpoint_url || '' : '', wantUrl: want,
      connected: app.status === 200 && app.data.interactions_endpoint_url === want,
      messageContent: app.status === 200 ? ((app.data.flags || 0) & ((1 << 18) | (1 << 19))) !== 0 : false,
      botCanManage: admin || (perms & NEED) === NEED,
      categoryOk: !!T.categoryId, logOk: !!T.logChannelId, published: { types: T.types.length, categoryId: T.categoryId, logChannelId: T.logChannelId, staffRoles: T.staffRoles }
    };
  },

  // Points the Discord app's Interactions Endpoint URL here and switches on Message Content (for transcripts).
  async connect(req) {
    await staffOnly(req);
    const app = await dj('GET', '/applications/@me');
    if (app.status !== 200) throw bad(502, `Discord said ${app.status} when reading the app.`);
    const want = publicUrl(req) + '/api/interactions';
    const why = r => String((r.data && ((r.data.errors && JSON.stringify(r.data.errors)) || r.data.message)) || '').slice(0, 240);
    let cur = app.data;
    // 1. The address. Discord checks it first by sending this service a signed PING.
    if (cur.interactions_endpoint_url !== want) {
      const r = await dj('PATCH', '/applications/@me', { interactions_endpoint_url: want });
      if (r.status !== 200) throw bad(502, `Discord didn't accept the address (${r.status}). ${why(r)}`);
      cur = r.data;
    }
    // 2. Message Content, so transcripts have what people wrote. Only the "limited" intent flags can be changed.
    const MC = (1 << 18) | (1 << 19), LIMITED = (1 << 13) | (1 << 15) | (1 << 19);
    let note = '';
    if (((cur.flags || 0) & MC) === 0) {
      let r = await dj('PATCH', '/applications/@me', { flags: (cur.flags || 0) | (1 << 19) });
      if (r.status !== 200) r = await dj('PATCH', '/applications/@me', { flags: ((cur.flags || 0) & LIMITED) | (1 << 19) });
      if (r.status === 200) cur = r.data;
      else note = 'Turn on Message Content Intent on the Bot page of the Discord Developer Portal, so transcripts include what people wrote.';
    }
    return { ok: true, interactionsUrl: cur.interactions_endpoint_url, messageContent: ((cur.flags || 0) & MC) !== 0, note };
  },

  // Makes a private "Tickets" category and/or a staff-only log channel.
  async setup(req) {
    const { T } = await staffOnly(req);
    const b = await body(req);
    const staffRoles = (Array.isArray(b.staffRoles) && b.staffRoles.filter(idOk).length ? b.staffRoles.filter(idOk) : T.staffRoles).map(String);
    const hidden = [{ id: C.guildId(), type: 0, deny: B.VIEW.toString() }, { id: C.clientId(), type: 1, allow: (B.VIEW | B.SEND | B.EMBED | B.ATTACH | B.HISTORY | B.MANAGE_CHANNELS).toString() },
      ...staffRoles.map(id => ({ id, type: 0, allow: (B.VIEW | B.SEND | B.HISTORY | B.EMBED | B.ATTACH).toString() }))];
    const out = {};
    if (b.category) {
      const r = await dj('POST', `/guilds/${C.guildId()}/channels`, { name: 'Tickets', type: 4, permission_overwrites: hidden });
      if (r.status !== 200 && r.status !== 201) throw bad(502, r.status === 403 ? "The bot isn't allowed to make channels yet. Give it the new permissions first." : `Discord said ${r.status}.`);
      out.categoryId = r.data.id;
    }
    if (b.log) {
      const r = await dj('POST', `/guilds/${C.guildId()}/channels`, { name: 'ticket-logs', type: 0, topic: 'Closed tickets and their transcripts (Warchief bot).', permission_overwrites: hidden, ...(out.categoryId || T.categoryId ? { parent_id: out.categoryId || T.categoryId } : {}) });
      if (r.status !== 200 && r.status !== 201) throw bad(502, r.status === 403 ? "The bot isn't allowed to make channels yet. Give it the new permissions first." : `Discord said ${r.status}.`);
      out.logChannelId = r.data.id;
    }
    return out;
  },

  async tickets(req) {
    const { T } = await staffOnly(req);
    const [open, closed] = await Promise.all([tk.openTickets(T), tk.closedTickets(T, 50)]);
    const who = await names([...open.flatMap(t => [t.opener, t.claimer]), ...closed.flatMap(t => [t.opener, t.closer, t.claimer])]);
    const named = t => ({ ...t, openerName: who[t.opener] || '', claimerName: who[t.claimer] || '', closerName: who[t.closer] || '' });
    return { open: open.map(named), closed: closed.map(named), setup: { categoryOk: !!T.categoryId, logOk: !!T.logChannelId } };
  },

  async ticket(req) {
    const { T } = await staffOnly(req);
    const id = query(req).get('id');
    if (!idOk(id)) throw bad(400, 'Which ticket?');
    const t = await tk.ticketChannel(T, id);
    const msgs = await tk.readable(tk.simpleMessages(await tk.allMessages(id, 500)));
    const who = await names([t.opener, t.claimer]);
    return { ticket: { ...t, openerName: who[t.opener] || '', claimerName: who[t.claimer] || '' }, messages: msgs };
  },

  async reply(req) {
    const { me } = await staffOnly(req);
    const b = await body(req);
    if (!idOk(b.id)) throw bad(400, 'Which ticket?');
    const text = String(b.text || '').trim();
    if (!text) throw bad(400, 'Write a reply first.');
    return tk.staffReply({ channelId: b.id, staff: me, text });
  },
  async claim(req) { const { me } = await staffOnly(req); const b = await body(req); return tk.claimTicket({ channelId: String(b.id), staffId: me.id }); },
  async close(req) { const { me } = await staffOnly(req); const b = await body(req); return tk.closeTicket({ channelId: String(b.id), closerId: me.id, reason: String(b.reason || '').slice(0, 1000) }); },

  // Posts (or updates) the "Open a ticket" panel. The buttons come from the published settings.
  // The Admin sends the settings it shows, so the panel is right even while GitHub still hands out the old list.
  // Moving the panel to another channel takes the old one away.
  async panel(req) {
    const { T } = await staffOnly(req);
    const b = await body(req);
    const use = b.tickets && typeof b.tickets === 'object' ? tk.normalize(b.tickets) : T;
    if (!use.types.length) throw bad(400, 'Add at least one ticket button first.');
    const out = await upsertMessage(b.channelId, b.messageId, tk.panelMessage(use));
    if (idOk(b.removeChannelId) && idOk(b.removeMessageId) && !(b.removeChannelId === out.channelId && b.removeMessageId === out.messageId)) {
      const old = await dj('GET', `/channels/${b.removeChannelId}/messages/${b.removeMessageId}`);
      if (old.status === 200 && old.data.author && old.data.author.id === C.clientId()) { await dj('DELETE', `/channels/${b.removeChannelId}/messages/${b.removeMessageId}`); out.removedOld = true; }
    }
    return out;
  },

  // Right after a Publish: read the addon list again now (ticket settings, staff roles), and say what the bot sees.
  async refresh(req) {
    const s = await staffOnly(req);
    forget('catalog');
    const T = await tk.settings();
    let publishedAt = '';
    try { publishedAt = (await catalog()).publishedAt || ''; } catch { publishedAt = ''; }
    return { ok: true, publishedAt, ready: !!T.categoryId, categoryId: T.categoryId, logChannelId: T.logChannelId, types: T.types.map(t => t.label), staff: !!s };
  },

  // Posts (or updates) the To-do board in Discord: one message with a picture of the board, which the Admin draws.
  // Updating swaps the picture on the same message. Moving it to another channel takes the old one away.
  async todo(req) {
    await staffOnly(req);
    const b = await body(req, 4000000); // the picture is sent along (up to about 3 MB)
    if (!idOk(b.channelId)) throw bad(400, 'Pick a channel first.');
    const png = Buffer.from(String(b.image || ''), 'base64');
    if (png.length < 100 || png.length > 3000000 || png.readUInt32BE(0) !== 0x89504e47) throw bad(400, "The board picture didn't come through. Try again.");
    const title = String(b.title || '').replace(/[\r\n]+/g, ' ').replace(/@(everyone|here)/gi, '@\u200b$1').trim().slice(0, 200) || 'Warchief To-do';
    const payload = {
      content: `## ${title}\n-# Updated <t:${Math.floor(Date.now() / 1000)}:f> · The Warchief team keeps this board up to date.`,
      embeds: [], components: [], allowed_mentions: { parse: [] },
      attachments: [{ id: 0, filename: 'warchief-todo.png', description: String(b.alt || title).slice(0, 1024) }]
    };
    const form = () => { const f = new FormData(); f.append('payload_json', JSON.stringify(payload)); f.append('files[0]', new Blob([png], { type: 'image/png' }), 'warchief-todo.png'); return f; };
    let r = null, updated = false;
    if (idOk(b.messageId)) {
      r = await discord(`/channels/${b.channelId}/messages/${b.messageId}`, { method: 'PATCH', body: form() });
      updated = r.status === 200;
    }
    if (!updated) {
      r = await discord(`/channels/${b.channelId}/messages`, { method: 'POST', body: form() });
      if (r.status !== 200) throw bad(502, r.status === 403 ? "The bot isn't allowed to post in that channel. It needs View Channel, Send Messages and Attach Files there." : `Discord said ${r.status} when posting.`);
    }
    const out = { channelId: b.channelId, messageId: r.data.id, updated };
    if (idOk(b.removeChannelId) && idOk(b.removeMessageId) && !(b.removeChannelId === out.channelId && b.removeMessageId === out.messageId)) {
      const old = await dj('GET', `/channels/${b.removeChannelId}/messages/${b.removeMessageId}`);
      if (old.status === 200 && old.data.author && old.data.author.id === C.clientId()) { await dj('DELETE', `/channels/${b.removeChannelId}/messages/${b.removeMessageId}`); out.removedOld = true; }
    }
    return out;
  }
};
const POST_ONLY = new Set(['connect', 'setup', 'reply', 'claim', 'close', 'panel', 'todo', 'refresh']);

module.exports = handle(async (req, res) => {
  const act = query(req).get('do') || '';
  const fn = ACTIONS[act];
  if (!fn) throw bad(404, 'Unknown action.');
  if (POST_ONLY.has(act) && req.method !== 'POST') throw bad(405, 'Use POST.');
  send(res, 200, await fn(req));
});

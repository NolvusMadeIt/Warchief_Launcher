// The launcher's community parts: votes on the To-do board, Discord announcements for the bell, and finding
// people in the Warchief Discord so the launcher can open their profile.
//   GET  /api/community?do=votes            vote counts per to-do card (+ your own votes when logged in)
//   POST /api/community?do=vote             { card, vote: 1 | -1 | 0 }   logged in and in the server
//   GET  /api/community?do=feed             the newest posts in the channels picked on the Admin's Launcher home page
//   GET  /api/community?do=search&q=name    people in the server whose name starts with q   logged in and in the server
'use strict';
const crypto = require('crypto');
const { C, send, query, body, session, whoIs, discord, dj, cached, forget, catalog, avatarUrl, bad, handle } = require('../lib/core');

// ---------- Votes ----------
// There is no database: the votes live in a private channel only the bot can see (#launcher-votes), one message per
// person holding that person's votes. Two people voting at the same moment never overwrite each other.
const VOTE_CHANNEL = 'launcher-votes';
// The bot can only hand out permissions it has itself, and it can always delete its own messages.
const P = { VIEW: 1n << 10n, SEND: 1n << 11n, HISTORY: 1n << 16n };
const LINE = /^v1 ([a-f0-9]{16}) (\{.*\})$/s;

// People are stored as a scrambled code, never their Discord name or ID.
const voterKey = id => crypto.createHmac('sha256', C.clientSecret() + ':launcher-votes').update(String(id)).digest('hex').slice(0, 16);

async function voteChannel() {
  return cached('vote-channel', 10 * 60000, async () => {
    const g = C.guildId();
    const r = await discord(`/guilds/${g}/channels`);
    if (r.status !== 200) throw bad(502, `Discord said ${r.status} when reading the channels.`);
    const found = r.data.find(c => c.type === 0 && c.name === VOTE_CHANNEL);
    if (found) return found.id;
    const made = await dj('POST', `/guilds/${g}/channels`, {
      name: VOTE_CHANNEL, type: 0, position: 999,
      topic: 'Warchief Launcher keeps the To-do votes here. Please leave this channel and its messages alone.',
      permission_overwrites: [
        { id: g, type: 0, allow: '0', deny: String(P.VIEW) },
        { id: C.clientId(), type: 1, allow: String(P.VIEW | P.SEND | P.HISTORY), deny: '0' }
      ]
    });
    if (made.status !== 200 && made.status !== 201) {
      throw bad(502, made.status === 403 ? 'The Warchief bot needs the Manage Channels permission to keep the votes.' : `Discord said ${made.status} when making the votes channel.`);
    }
    return made.data.id;
  });
}

// Everyone's votes: Map voterKey -> { id (the message), votes: { cardId: 1 | -1 } }
async function allVotes(fresh) {
  if (fresh) forget('votes');
  return cached('votes', 20000, async () => {
    const ch = await voteChannel();
    const byVoter = new Map();
    const extra = []; // a second message for the same person (two first votes at once): cleaned up on their next vote
    let before = '';
    for (let page = 0; page < 40; page++) {
      const r = await discord(`/channels/${ch}/messages?limit=100${before ? '&before=' + before : ''}`);
      if (r.status !== 200) throw bad(502, `Discord said ${r.status} when reading the votes.`);
      for (const m of r.data) {
        if (!m.author || String(m.author.id) !== C.clientId()) continue;
        const mm = LINE.exec(m.content || '');
        if (!mm) continue;
        if (byVoter.has(mm[1])) { extra.push({ key: mm[1], id: m.id }); continue; } // newest first: the newest one counts
        let votes = {};
        try { votes = JSON.parse(mm[2]); } catch { votes = {}; }
        byVoter.set(mm[1], { id: m.id, votes: votes && typeof votes === 'object' ? votes : {} });
      }
      if (r.data.length < 100) break;
      before = r.data[r.data.length - 1].id;
    }
    byVoter.extra = extra;
    return byVoter;
  });
}

function tally(byVoter) {
  const counts = {};
  for (const { votes } of byVoter.values()) {
    for (const [card, v] of Object.entries(votes)) {
      const c = counts[card] || (counts[card] = { up: 0, down: 0 });
      if (v === 1) c.up++; else if (v === -1) c.down++;
    }
  }
  return counts;
}

async function boardCards() {
  const cat = await catalog();
  const cols = cat && cat.roadmap && Array.isArray(cat.roadmap.columns) ? cat.roadmap.columns : [];
  return new Set(cols.flatMap(c => (Array.isArray(c.cards) ? c.cards : []).map(k => String(k.id || ''))).filter(Boolean));
}

async function signedInMember(req) {
  const s = session(req);
  if (!s) throw bad(401, 'Log in with Discord to do this.', { need: 'login' });
  const who = await whoIs(s, false);
  if (!who.inServer) throw bad(403, 'Join the Warchief Discord to do this.', { need: 'member', invite: who.invite });
  return s;
}

async function getVotes(req) {
  const byVoter = await allVotes(false);
  const s = session(req);
  const mine = s ? ((byVoter.get(voterKey(s.sub)) || {}).votes || {}) : {};
  return { counts: tally(byVoter), mine };
}

async function castVote(req) {
  const s = await signedInMember(req);
  const b = await body(req, 2000);
  const card = String(b.card || '');
  const vote = Number(b.vote);
  if (!/^[\w-]{1,40}$/.test(card) || ![1, -1, 0].includes(vote)) throw bad(400, 'That vote looks wrong.');
  const cards = await boardCards();
  if (!cards.has(card)) throw bad(404, "That card isn't on the To-do board anymore.");
  const ch = await voteChannel();
  const byVoter = await allVotes(true);
  const key = voterKey(s.sub);
  const mine = byVoter.get(key);
  const votes = { ...(mine ? mine.votes : {}) };
  if (vote) votes[card] = vote; else delete votes[card];
  for (const k of Object.keys(votes)) if (!cards.has(k)) delete votes[k]; // cards taken off the board
  const content = `v1 ${key} ${JSON.stringify(votes)}`;
  if (content.length > 1990) throw bad(400, 'You have voted on too many cards.');
  let r;
  if (mine) r = await dj('PATCH', `/channels/${ch}/messages/${mine.id}`, { content });
  else r = await dj('POST', `/channels/${ch}/messages`, { content, allowed_mentions: { parse: [] } });
  if (r.status !== 200) throw bad(502, `Discord said ${r.status} when saving the vote.`);
  byVoter.set(key, { id: mine ? mine.id : r.data.id, votes });
  // Leftover second messages for this person go away
  for (const x of (byVoter.extra || []).filter(x => x.key === key)) await dj('DELETE', `/channels/${ch}/messages/${x.id}`);
  byVoter.extra = (byVoter.extra || []).filter(x => x.key !== key);
  const counts = tally(byVoter);
  return { ok: true, card, mine: vote, count: counts[card] || { up: 0, down: 0 }, counts };
}

// ---------- Announcements for the launcher's bell ----------
function firstLine(text) {
  return String(text || '').replace(/<a?:(\w+):\d+>/g, ':$1:').replace(/<[@#][!&]?\d+>/g, '').replace(/[*_~`>#|]/g, '')
    .split('\n').map(x => x.trim()).filter(Boolean)[0] || '';
}
async function feed() {
  const cat = await catalog();
  const home = cat && cat.home && typeof cat.home === 'object' ? cat.home : {};
  const ids = (Array.isArray(home.feed) ? home.feed : []).map(String).filter(x => /^\d{5,25}$/.test(x)).slice(0, 3);
  if (!ids.length) return { items: [] };
  return cached('feed:' + ids.join(','), Number(process.env.FEED_TTL_MS) || 120000, async () => { // the TTL is only changed by the tests
    const items = [];
    for (const id of ids) {
      const [ch, msgs] = await Promise.all([
        cached('chan:' + id, 10 * 60000, async () => { const r = await discord(`/channels/${id}`); return r.status === 200 ? r.data : null; }),
        discord(`/channels/${id}/messages?limit=10`)
      ]);
      if (!ch || msgs.status !== 200 || !Array.isArray(msgs.data)) continue;
      for (const m of msgs.data) {
        if (m.type != null && m.type !== 0 && m.type !== 19) continue; // normal messages and replies only
        const e = (m.embeds || [])[0] || {};
        const title = firstLine(e.title) || firstLine(m.content) || firstLine(e.description);
        if (!title) continue;
        items.push({
          id: m.id, channel: ch.name, title: title.slice(0, 140),
          at: m.timestamp, url: `https://discord.com/channels/${C.guildId()}/${id}/${m.id}`
        });
      }
    }
    items.sort((a, b) => String(b.at).localeCompare(String(a.at)));
    return { items: items.slice(0, 12) };
  });
}

// ---------- Finding people in the server ----------
async function search(req) {
  await signedInMember(req);
  const q = String(query(req).get('q') || '').trim().slice(0, 32);
  if (q.length < 2) return { people: [] };
  return cached('search:' + q.toLowerCase(), 60000, async () => {
    const r = await discord(`/guilds/${C.guildId()}/members/search?query=${encodeURIComponent(q)}&limit=10`);
    if (r.status !== 200 || !Array.isArray(r.data)) throw bad(502, `Discord said ${r.status} when searching the server.`);
    return {
      people: r.data.filter(m => m.user && !m.user.bot).map(m => ({
        id: m.user.id, name: m.nick || m.user.global_name || m.user.username, username: m.user.username,
        avatar: avatarUrl(m.user.id, m.user.avatar)
      }))
    };
  });
}

module.exports = handle(async (req, res) => {
  const act = query(req).get('do');
  if (req.method === 'POST' && act === 'vote') return send(res, 200, await castVote(req));
  if (req.method !== 'GET') throw bad(405, 'Use GET.');
  if (act === 'votes') return send(res, 200, await getVotes(req));
  if (act === 'feed') return send(res, 200, await feed());
  if (act === 'search') return send(res, 200, await search(req));
  throw bad(404, 'Unknown action.');
});
module.exports.voteChannel = voteChannel;

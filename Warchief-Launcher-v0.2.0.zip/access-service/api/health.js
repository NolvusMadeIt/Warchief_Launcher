// Is everything set up? The Admin's "Test" button reads this. It never shows any secret, only yes or no.
'use strict';
const { C, VERSION, send, query, publicUrl, catalog, discord, github, handle } = require('../lib/core');

async function check(label, fix, fn) {
  try { const r = await fn(); return { label, ok: r === true, note: typeof r === 'string' ? r : '', fix: r === true ? '' : fix }; }
  catch (e) { return { label, ok: false, note: String(e.message || e).slice(0, 200), fix }; }
}

module.exports = handle(async (req, res) => {
  const out = {
    ok: true, version: VERSION, callbackUrl: publicUrl(req) + '/api/callback',
    configured: {
      clientId: !!C.clientId(), clientSecret: !!C.clientSecret(), botToken: !!C.botToken(), guildId: !!C.guildId(),
      bugChannel: !!C.bugChannel(), githubToken: !!C.githubToken(), catalogUrl: !!C.catalogUrl()
    }
  };
  if (query(req).get('deep') !== '1') return send(res, 200, out);

  const checks = [];
  checks.push(await check('Discord Client Secret', 'In Vercel, add DISCORD_CLIENT_SECRET (Discord Developer Portal > OAuth2 > Client Secret), then redeploy.', async () => {
    if (!C.clientId() || !C.clientSecret()) return 'missing';
    const r = await fetch(C.discordApi() + '/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Authorization: 'Basic ' + Buffer.from(`${C.clientId()}:${C.clientSecret()}`).toString('base64') },
      body: new URLSearchParams({ grant_type: 'client_credentials', scope: 'identify' })
    });
    return r.ok ? true : r.status === 401 ? "Discord doesn't accept it" : `Discord said ${r.status}`;
  }));
  checks.push(await check('Discord bot key', 'In Vercel, add DISCORD_BOT_TOKEN (Discord Developer Portal > Bot > Reset Token), then redeploy.', async () => {
    if (!C.botToken()) return 'missing';
    const r = await discord('/users/@me');
    return r.status === 200 ? true : r.status === 401 ? "Discord doesn't accept it" : `Discord said ${r.status}`;
  }));
  const botOk = checks[1].ok;
  checks.push(await check('Bot is in your Discord server', 'Add the bot to your server with the link on the Admin page.', async () => {
    if (!botOk) return 'needs the bot key first';
    const r = await discord(`/guilds/${C.guildId()}`);
    return r.status === 200 ? true : 'not in the server yet';
  }));
  checks.push(await check('Bot can see the bug channel', 'Give the bot View Channel and Send Messages in the bug channel.', async () => {
    if (!botOk) return 'needs the bot key first';
    if (!C.bugChannel()) return 'no bug channel set';
    const r = await discord(`/channels/${C.bugChannel()}`);
    return r.status === 200 ? true : "can't see it";
  }));
  let cat = null;
  checks.push(await check('Addon list', 'Publish from the Admin once, and check CATALOG_URL in Vercel.', async () => {
    cat = await catalog();
    return Array.isArray(cat.products) ? true : 'empty';
  }));
  const repos = cat ? [...new Map((cat.products || []).filter(p => p.repo && p.release && p.release.tag).map(p => [p.repo, p])).values()] : [];
  checks.push(await check('GitHub key can read the addon downloads', 'In Vercel, add GITHUB_TOKEN (a read-only key for the addon repos), then redeploy.', async () => {
    if (!repos.length) return 'no addons with versions yet';
    if (!C.githubToken()) return 'missing (downloads only work while the addon repos are public)';
    const bad = [];
    for (const p of repos) {
      const r = await github(`/repos/${p.repo}/releases/tags/${encodeURIComponent(p.release.tag)}`);
      if (!r.ok) bad.push(`${p.repo.split('/')[1]} (${r.status})`);
    }
    return bad.length ? "can't read " + bad.join(', ') + (C.githubToken() ? '' : '. GITHUB_TOKEN is missing') : true;
  }));
  checks.push(await check('To-do votes channel', 'Give the Warchief bot the Manage Channels permission in your server.', async () => {
    if (!botOk) return 'needs the bot key first';
    await require('./community').voteChannel();
    return true;
  }));
  checks.push(await check('Finding people in the server', 'Turn on Server Members Intent for the bot in the Discord Developer Portal (Bot page).', async () => {
    if (!botOk) return 'needs the bot key first';
    const r = await discord(`/guilds/${C.guildId()}/members/search?query=a&limit=1`);
    return r.status === 200 ? true : `Discord said ${r.status}`;
  }));
  out.checks = checks;
  out.ok = checks.every(c => c.ok);
  send(res, 200, out);
});

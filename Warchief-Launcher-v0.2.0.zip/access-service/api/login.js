// Step 1 of "Log in with Discord": the launcher opens this in the browser, we send the player on to Discord.
'use strict';
const { C, query, redirect, page, sign, publicUrl, handle } = require('../lib/core');

module.exports = handle(async (req, res) => {
  const q = query(req);
  const port = Number(q.get('port'));
  const nonce = String(q.get('nonce') || '');
  if (!Number.isInteger(port) || port < 1024 || port > 65535 || !/^[\w-]{16,80}$/.test(nonce)) {
    return page(res, 400, 'Open this from the launcher', 'Press "Log in with Discord" in Warchief Launcher to log in.');
  }
  if (!C.clientId() || !C.clientSecret()) return page(res, 503, 'Not set up yet', "Discord login for Warchief Launcher isn't switched on yet. Try again later.");
  const state = sign({ typ: 'state', port, nonce, exp: Date.now() + 10 * 60000 });
  const u = new URL(C.discordWeb() + '/oauth2/authorize');
  u.searchParams.set('client_id', C.clientId());
  u.searchParams.set('response_type', 'code');
  u.searchParams.set('redirect_uri', publicUrl(req) + '/api/callback');
  u.searchParams.set('scope', 'identify');
  u.searchParams.set('state', state);
  u.searchParams.set('prompt', 'none');
  redirect(res, u.toString());
});

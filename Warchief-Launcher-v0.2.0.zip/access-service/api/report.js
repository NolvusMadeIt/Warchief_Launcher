// Help > Report a bug: the Warchief bot posts the report in the bug channel.
// The Warchief bug channel is a Forum: each report becomes its own post, with a title made from the report,
// the Addon or Plugin tag, the report laid out like a bug report, and the support info file. The person who
// reported it is mentioned, so they follow the post and see the team's answers. A text channel gets one message.
'use strict';
const { C, send, body, session, whoIs, discord, cached, catalog, bad, handle } = require('../lib/core');

const recent = new Map(); // a little memory to stop accidental double sends and spam
const clean = (s, n) => String(s || '').replace(/\r/g, '').replace(/@(everyone|here)/gi, '@​$1').trim().slice(0, n);
const plain = s => s.replace(/[*_`~|>#]/g, '');
const OFTEN = { always: 'Every time', sometimes: 'Sometimes', once: 'It happened once' };
const FORUM = new Set([15, 16]);
const REQUIRE_TAG = 1 << 4;

// The bug channel: is it a forum, and which tags does it have? (kept 10 minutes)
const channelInfo = () => cached('bugchan:' + C.bugChannel(), 600000, async () => {
  const r = await discord(`/channels/${C.bugChannel()}`);
  if (r.status !== 200) throw bad(502, r.status === 403 || r.status === 404 ? "The Warchief bot can't see the bug channel. Give it View Channel there." : `Discord said ${r.status} when reading the bug channel.`);
  return { type: r.data.type, flags: r.data.flags || 0, tags: (r.data.available_tags || []).map(t => ({ id: t.id, name: String(t.name || ''), moderated: !!t.moderated })) };
});
// Addon -> "Addon" tag, plugin -> "Plugin" tag, the launcher -> a "Launcher" tag if there is one.
function tagsFor(ch, kind) {
  const free = ch.tags.filter(t => !t.moderated); // moderated tags need Manage Threads
  const named = (...names) => free.find(t => names.includes(t.name.trim().toLowerCase()));
  const pick = kind === 'plugin' ? named('plugin', 'plugins') : kind === 'launcher' ? named('launcher', 'warchief launcher') : named('addon', 'addons');
  if (pick) return [pick.id];
  if (ch.flags & REQUIRE_TAG) { const any = (kind === 'launcher' && named('addon', 'addons')) || free[0]; return any ? [any.id] : []; }
  return [];
}
const why = r => {
  const d = r.data && typeof r.data === 'object' ? r.data : {};
  if (r.status === 403) return "The Warchief bot isn't allowed to post in the bug channel. Give it View Channel, Send Messages (Create Posts), Embed Links and Attach Files there.";
  if (d.code === 40067) return 'The bug channel needs a tag on every post, and the bot could not find one it may use. Add an "Addon" and a "Plugin" tag to the forum.';
  return `Discord said ${r.status}${d.message ? ` (${String(d.message).slice(0, 120)})` : ''}. Try again in a minute.`;
};

module.exports = handle(async (req, res) => {
  if (req.method !== 'POST') throw bad(405, 'Send a report from the launcher.');
  const s = session(req);
  if (!s) throw bad(401, 'Log in with Discord to send a bug report.', { need: 'login' });
  if (!C.bugChannel()) throw bad(503, "Bug reports aren't switched on yet.");
  const who = await whoIs(s);
  if (!who.inServer) throw bad(403, 'Join the Warchief Discord to send bug reports.', { need: 'member', invite: who.invite });

  const b = await body(req);
  const text = clean(b.text, 3500);
  const steps = clean(b.steps, 1500);
  const expected = clean(b.expected, 500);
  if (text.length < 10) throw bad(400, 'Tell us a little more about what happened.');
  const last = recent.get(s.sub) || [];
  const now = Date.now();
  const lately = last.filter(t => now - t < 10 * 60000);
  if (lately.length >= 3) throw bad(429, "You've sent a few reports already. Give it a few minutes, or post in the bug channel on Discord.");
  recent.set(s.sub, [...lately, now]);

  // What it's about
  let addon = 'Warchief Launcher', kind = 'launcher';
  if (b.product && b.product !== 'launcher') {
    let p = null;
    try { p = ((await catalog()).products || []).find(x => x.id === b.product) || null; } catch { p = null; }
    addon = p ? p.name : clean(b.product, 60);
    kind = p && p.type === 'plugin' ? 'plugin' : 'main';
  }
  const version = kind === 'launcher' ? clean(b.launcher, 40) : clean(b.installed, 40);
  const often = OFTEN[b.often] || '';

  // The report, laid out like a bug report
  const sections = [['What happened', text], ['Steps to make it happen', steps], ['What should have happened', expected]].filter(x => x[1]);
  let description = sections.map(([h, t]) => `**${h}**\n${t}`).join('\n\n');
  if (description.length > 4000) description = description.slice(0, 3990) + '…';
  const fields = [
    { name: kind === 'plugin' ? 'Plugin' : kind === 'launcher' ? 'Program' : 'Addon', value: plain(addon).slice(0, 100), inline: true },
    { name: 'Version', value: version || (kind === 'launcher' ? 'unknown' : 'not installed'), inline: true },
    ...(often ? [{ name: 'How often', value: often, inline: true }] : []),
    { name: 'Launcher', value: clean(b.launcher, 40) || 'unknown', inline: true },
    { name: 'Reported by', value: `<@${s.sub}>`, inline: true }
  ];
  const message = {
    content: `<@${s.sub}> reported a bug in **${plain(addon)}**. The Warchief team will answer here.`,
    allowed_mentions: { users: [s.sub] }, // they follow the post and see the answers
    embeds: [{ title: `🪲 ${plain(addon)}${version ? ' ' + version : ''}`.slice(0, 250), description, color: 0xe0a33a, fields, footer: { text: 'Sent from Warchief Launcher' }, timestamp: new Date().toISOString() }]
  };
  const info = clean(b.info, 20000);
  if (info) message.attachments = [{ id: 0, filename: 'support-info.txt', description: 'Launcher support info' }];

  // Forum: a new post. Text channel: a message.
  let ch;
  try { ch = await channelInfo(); } catch (e) { recent.set(s.sub, lately); throw e; }
  const forum = FORUM.has(ch.type);
  const summary = plain(text.split('\n').find(l => l.trim()) || text).replace(/\s+/g, ' ').trim();
  const head = `${plain(addon)}${version ? ' ' + version : ''}: `;
  const title = (head + summary).length <= 100 ? head + summary : (head + summary).slice(0, 99).replace(/\s+\S*$/, '') + '…';
  const payload = forum ? { name: title, auto_archive_duration: 10080, applied_tags: tagsFor(ch, kind), message } : message;
  const path = forum ? `/channels/${C.bugChannel()}/threads` : `/channels/${C.bugChannel()}/messages`;
  let init;
  if (info) {
    const form = new FormData();
    form.append('payload_json', JSON.stringify(payload));
    form.append('files[0]', new Blob([info], { type: 'text/plain' }), 'support-info.txt');
    init = { method: 'POST', body: form };
  } else init = { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) };
  const r = await discord(path, init);
  if (r.status !== 200 && r.status !== 201) { recent.set(s.sub, lately); throw bad(502, why(r)); }
  const where = forum ? r.data.id : C.bugChannel();
  send(res, 200, { ok: true, forum, url: `https://discord.com/channels/${C.guildId()}/${where}${forum ? '' : '/' + r.data.id}` });
});

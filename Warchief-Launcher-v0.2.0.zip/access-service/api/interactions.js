// Discord sends every ticket button click and form here (the app's "Interactions Endpoint URL").
// Each request is signed by Discord; anything without a valid signature is refused.
// Discord wants an answer within 3 seconds, so slow work (making channels, transcripts) runs after the first answer.
'use strict';
const crypto = require('crypto');
const { C, cached, dj, VERSION } = require('../lib/core');
const tk = require('../lib/tickets');
let waitUntil = p => p; // outside Vercel the work simply keeps running
try { waitUntil = require('@vercel/functions').waitUntil; } catch { /* not installed (tests) */ }

const EPHEMERAL = 64;
const SPKI = Buffer.from('302a300506032b6570032100', 'hex');

async function publicKey() {
  if (/^[0-9a-f]{64}$/i.test(process.env.DISCORD_PUBLIC_KEY || '')) return process.env.DISCORD_PUBLIC_KEY;
  return cached('verify_key', 6 * 3600000, async () => {
    const r = await dj('GET', '/applications/@me');
    if (r.status !== 200 || !r.data.verify_key) throw new Error('no verify key');
    return r.data.verify_key;
  });
}
async function verified(raw, sig, ts) {
  if (!/^[0-9a-f]{128}$/i.test(sig || '') || !/^\d+$/.test(ts || '')) return false;
  try {
    const key = crypto.createPublicKey({ key: Buffer.concat([SPKI, Buffer.from(await publicKey(), 'hex')]), format: 'der', type: 'spki' });
    return crypto.verify(null, Buffer.concat([Buffer.from(ts), raw]), key, Buffer.from(sig, 'hex'));
  } catch { return false; }
}
async function rawBody(req) {
  const chunks = []; let size = 0;
  for await (const c of req) { size += c.length; if (size > 1e6) break; chunks.push(c); }
  return Buffer.concat(chunks);
}
function reply(res, obj) {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(obj));
}
const say = (content, components) => ({ type: 4, data: { content, flags: EPHEMERAL, allowed_mentions: { parse: [] }, ...(components ? { components } : {}) } });
// Changes the first answer after the slow work is done (the token is good for 15 minutes; no bot key needed).
async function editOriginal(i, content, components) {
  await fetch(`${C.discordApi()}/webhooks/${i.application_id}/${i.token}/messages/@original`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json', 'User-Agent': `DiscordBot (warchief-access, ${VERSION})` },
    body: JSON.stringify({ content, components: components || [], allowed_mentions: { parse: [] } })
  }).catch(() => {});
}
const friendly = e => (e && e.status ? e.message : 'Something went wrong. Try again in a minute.');

// Form answers (Label components wrapping text inputs; older action rows also understood)
function answers(i, type) {
  const vals = {};
  for (const c of i.data.components || []) {
    if (c.type === 18 && c.component) vals[c.component.custom_id] = c.component.value;
    if (c.type === 1) for (const x of c.components || []) vals[x.custom_id] = x.value;
  }
  return type.questions.map(q => ({ label: q.label, value: String(vals[q.id] || '').trim() }));
}
function modalFor(type) {
  return {
    type: 9,
    data: {
      custom_id: 'tk:form:' + type.id, title: type.label.slice(0, 45),
      components: type.questions.map(q => ({ type: 18, label: q.label, component: { type: 4, custom_id: q.id, style: q.style, required: q.required, max_length: q.style === 1 ? 200 : 2000, ...(q.placeholder ? { placeholder: q.placeholder } : {}) } }))
    }
  };
}
function openLater(res, i, userId, typeId, ans) {
  reply(res, { type: 5, data: { flags: EPHEMERAL } }); // "thinking…" only the member sees
  return waitUntil((async () => {
    try {
      const r = await tk.createTicket({ userId, typeId, answers: ans });
      await editOriginal(i, r.existing ? `You already have an open ticket for this: <#${r.channelId}>` : `Your ticket is ready: <#${r.channelId}>`);
    } catch (e) { await editOriginal(i, friendly(e)); }
  })());
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') { res.statusCode = 405; return res.end(); }
  const raw = await rawBody(req);
  if (!(await verified(raw, req.headers['x-signature-ed25519'], req.headers['x-signature-timestamp']))) {
    res.statusCode = 401; return res.end('invalid request signature');
  }
  let i;
  try { i = JSON.parse(raw.toString('utf8')); } catch { res.statusCode = 400; return res.end(); }
  if (i.type === 1) return reply(res, { type: 1 }); // PING
  const member = i.member || {};
  const userId = (member.user && member.user.id) || (i.user && i.user.id);
  if (!i.guild_id || i.guild_id !== C.guildId()) return reply(res, say('Tickets only work inside the Warchief Discord.'));
  const id = (i.data && i.data.custom_id) || '';

  try {
    // A panel button: show the form, or open the ticket straight away when there are no questions
    if (i.type === 3 && id.startsWith('tk:open:')) {
      const T = await tk.settings();
      const type = T.types.find(t => t.id === id.slice(8));
      if (!T.categoryId) return reply(res, say("Tickets aren't set up yet. Ask the Warchief team."));
      if (!type) return reply(res, say('This button is out of date. Ask the Warchief team to update the ticket panel.'));
      if (type.questions.length) return reply(res, modalFor(type));
      return openLater(res, i, userId, type.id, []);
    }
    if (i.type === 5 && id.startsWith('tk:form:')) {
      const T = await tk.settings();
      const type = T.types.find(t => t.id === id.slice(8));
      if (!type) return reply(res, say('This form is out of date. Ask the Warchief team to update the ticket panel.'));
      return openLater(res, i, userId, type.id, answers(i, type));
    }
    if (i.type === 3 && id === 'tk:claim') {
      const T = await tk.settings();
      if (!tk.isStaff(T, member.roles, member.permissions)) return reply(res, say('Only the Warchief team can claim tickets.'));
      reply(res, { type: 5, data: { flags: EPHEMERAL } });
      return waitUntil((async () => {
        try {
          const r = await tk.claimTicket({ channelId: i.channel_id, staffId: userId });
          await editOriginal(i, r.already ? 'You already claimed this ticket.' : r.taken ? `<@${r.taken}> already claimed this ticket.` : 'You claimed this ticket.');
        } catch (e) { await editOriginal(i, friendly(e)); }
      })());
    }
    if (i.type === 3 && id === 'tk:close') {
      const T = await tk.settings();
      const t = await tk.ticketChannel(T, i.channel_id);
      if (t.opener !== userId && !tk.isStaff(T, member.roles, member.permissions)) return reply(res, say('Only the person who opened this ticket or the Warchief team can close it.'));
      return reply(res, say('Close this ticket? A copy of the conversation is saved and sent to the person who opened it.', [{ type: 1, components: [
        { type: 2, style: 4, custom_id: 'tk:close-yes', label: 'Close ticket', emoji: { name: '🔒' } }, { type: 2, style: 2, custom_id: 'tk:close-no', label: 'Cancel' }] }]));
    }
    if (i.type === 3 && id === 'tk:close-no') return reply(res, { type: 7, data: { content: 'Okay, the ticket stays open.', components: [] } });
    if (i.type === 3 && id === 'tk:close-yes') {
      reply(res, { type: 7, data: { content: 'Closing… saving the conversation first.', components: [] } });
      return waitUntil((async () => {
        try { await tk.closeTicket({ channelId: i.channel_id, closerId: userId, reason: '' }); }
        catch (e) { await editOriginal(i, friendly(e)); }
      })());
    }
    return reply(res, say("That button isn't used anymore."));
  } catch (e) {
    if (!res.headersSent) return reply(res, say(friendly(e)));
  }
};

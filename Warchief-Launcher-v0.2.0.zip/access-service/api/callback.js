// Step 2: Discord sends the player back here. We find out who they are and hand the launcher a signed pass.
'use strict';
const { C, query, redirect, page, verify, newSession, publicUrl, handle } = require('../lib/core');

module.exports = handle(async (req, res) => {
  const q = query(req);
  const st = verify(q.get('state'), 'state');
  if (!st) return page(res, 400, 'That login link expired', 'Go back to Warchief Launcher and press "Log in with Discord" again.');
  const back = params => redirect(res, `http://127.0.0.1:${st.port}/auth?` + new URLSearchParams({ nonce: st.nonce, ...params }).toString());

  if (q.get('error')) return back({ error: q.get('error') === 'access_denied' ? 'cancelled' : 'discord' });
  const code = q.get('code');
  if (!code) return back({ error: 'discord' });

  const tok = await fetch(C.discordApi() + '/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: C.clientId(), client_secret: C.clientSecret(), grant_type: 'authorization_code',
      code, redirect_uri: publicUrl(req) + '/api/callback'
    })
  });
  if (!tok.ok) { console.error('token exchange', tok.status, (await tok.text()).slice(0, 300)); return back({ error: 'discord' }); }
  const { access_token: at, token_type: tt } = await tok.json();
  const me = await fetch(C.discordApi() + '/users/@me', { headers: { Authorization: `${tt || 'Bearer'} ${at}` } });
  if (!me.ok) return back({ error: 'discord' });
  const u = await me.json();
  // We only needed the Discord key to learn who this is. It isn't kept anywhere.
  const token = newSession({ sub: String(u.id), name: u.global_name || u.username, avatar: u.avatar || '' });
  back({ token });
});

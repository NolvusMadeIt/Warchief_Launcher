// The server's roles, for the Admin's "Members & access" page.
'use strict';
const { send, roles, handle } = require('../lib/core');

module.exports = handle(async (_req, res) => {
  send(res, 200, { roles: await roles() });
});

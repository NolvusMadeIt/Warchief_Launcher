// A short-lived download link for one addon, only for players who are allowed to have it.
'use strict';
const { send, query, session, catalog, whoIs, need, assetLink, bad, handle } = require('../lib/core');

const WHY = {
  login: 'Log in with Discord to download this.',
  member: 'Join the Warchief Discord to download this. It is free.',
  tester: 'Beta versions are for Testers on the Warchief Discord.'
};

module.exports = handle(async (req, res) => {
  const q = query(req);
  const id = String(q.get('product') || '');
  const beta = q.get('channel') === 'beta';
  const cat = await catalog();
  const p = (cat.products || []).find(x => x && x.id === id && x.enabled !== false);
  if (!p) throw bad(404, "That addon isn't in the launcher's list.");
  const rel = beta ? p.beta : p.release;
  if (!rel || !rel.tag) throw bad(404, beta ? `${p.name} has no beta right now.` : `${p.name} has no version picked yet.`);

  // Who can download: set per addon in the Admin. Betas are always for Testers.
  const level = beta ? 'testers' : ['everyone', 'members', 'testers'].includes(p.access) ? p.access : 'members';
  const s = session(req);
  if (!s && level !== 'everyone') throw bad(401, WHY.login, { need: 'login' });
  const who = s && level !== 'everyone' ? await whoIs(s) : null;
  const why = need(who, level);
  if (why) throw bad(why === 'login' ? 401 : 403, WHY[why], { need: why, invite: who && who.invite });

  const link = await assetLink(p.repo, rel.tag, rel.asset);
  send(res, 200, { product: p.id, version: rel.version, channel: beta ? 'beta' : 'stable', ...link });
});

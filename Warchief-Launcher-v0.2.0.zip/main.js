// Warchief Launcher: the desktop window and the few things the screens need from Windows.
const { app, BrowserWindow, ipcMain, dialog, shell, Tray, Menu, nativeImage, screen } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { execFile } = require('child_process');
// Discord login for downloads (account.js)
const account = require('./account');
// Real installs into the AddOns folder (installer.js)
const installer = require('./installer');
// The Discord panel: its own window stuck to the launcher's right edge (widget.js)
const widget = require('./widget');

let win = null;
let tray = null;
const MIN_W = 1040, MIN_H = 660;

const ICON = path.join(__dirname, 'assets', process.platform === 'win32' ? 'wwd_logo.ico' : 'wwd_logo_transparent.png');
const CONFIG_FILE = path.join(__dirname, 'launcher.config.json');
// Same as "appId" in package.json's build settings; Windows uses it to group the taskbar and tray icon.
if (process.platform === 'win32') app.setAppUserModelId('com.nolvusmadeit.warchieflauncher');

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', showWindow);
  app.whenReady().then(createWindow);
  app.on('window-all-closed', () => app.quit());
}

function createWindow() {
  // Never bigger than the screen; the launcher and the Discord panel next to it (widget.js) are centered together
  const area = screen.getPrimaryDisplay().workArea;
  const w = Math.max(1040, Math.min(1280, area.width - 40 - widget.WIDTH)), h = Math.max(660, Math.min(800, area.height - 40));
  const pairW = w + widget.WIDTH;
  const at = pairW + 20 <= area.width ? { x: area.x + Math.round((area.width - pairW) / 2), y: area.y + Math.round((area.height - h) / 2) } : {};
  win = new BrowserWindow({
    ...at, width: w, height: h, minWidth: MIN_W, minHeight: MIN_H,
    frame: false, show: false, backgroundColor: '#0d0b19',
    title: 'Warchief Launcher',
    icon: ICON,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: true
    }
  });
  win.loadFile(path.join(__dirname, 'src', 'index.html'));
  widget.setup(win);
  win.once('ready-to-show', () => win.show());
  // Links never open inside the launcher; https links go to the normal browser.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', e => e.preventDefault());
  // The tray icon is there the whole time the launcher runs, like Discord's.
  ensureTray();
  setupUpdater();
}

function showWindow() {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
}

function ensureTray() {
  if (tray) return;
  let img = nativeImage.createFromPath(ICON);
  if (process.platform !== 'win32') img = img.resize({ width: 22, height: 22 });
  tray = new Tray(img);
  tray.setToolTip('Warchief Launcher');
  tray.setContextMenu(trayMenu());
  tray.on('click', showWindow);
}

// ---- Tray menu: News, a Play item for each WoW version found on this PC, Options, Check for updates
let trayGames = [];
function trayMenu() {
  return Menu.buildFromTemplate([
    { label: 'Open Warchief Launcher', click: showWindow },
    { type: 'separator' },
    { label: 'News', click: () => trayDo({ do: 'news' }) },
    ...trayGames.map(g => ({ label: g.label, click: () => trayDo({ do: 'play', game: g.id }) })),
    { label: 'Options', click: () => trayDo({ do: 'options' }) },
    { label: 'Check for updates', click: () => trayDo({ do: 'check' }) },
    { type: 'separator' },
    { label: 'Exit', click: () => app.quit() }
  ]);
}
function trayDo(action) {
  showWindow();
  if (win) win.webContents.send('tray:do', action);
}
// The screens tell the tray which WoW versions were found (they own the folder settings).
ipcMain.handle('tray:set', (_e, info) => {
  const games = info && Array.isArray(info.games) ? info.games : [];
  trayGames = games.filter(g => g && /^[\w-]{1,40}$/.test(String(g.id)) && typeof g.label === 'string')
    .slice(0, 10).map(g => ({ id: String(g.id), label: g.label.slice(0, 60) }));
  if (tray) tray.setContextMenu(trayMenu());
});

// ---- Launcher updates (only in the installed launcher; electron-updater reads the releases on GitHub)
// The arrow shows when a newer version is out. "auto" downloads it right away in the background and installs it
// when the launcher closes; "ask" waits for the click. The screens keep the loader up and then ask for the restart.
let updater = null;
const upd = { state: 'idle', version: '', percent: 0, error: '', mode: 'auto' };
const sendUpd = () => { if (win && !win.isDestroyed()) win.webContents.send('update:state', { ...upd }); };
function setupUpdater() {
  if (updater || !app.isPackaged) return;
  try { updater = require('electron-updater').autoUpdater; } catch { updater = null; return; }
  updater.autoDownload = false;
  updater.autoInstallOnAppQuit = false;
  updater.on('update-available', info => {
    Object.assign(upd, { state: 'available', version: info.version, percent: 0, error: '' });
    sendUpd();
    if (upd.mode === 'auto') downloadUpdate();
  });
  updater.on('update-not-available', () => { if (upd.state === 'checking') upd.state = 'idle'; sendUpd(); });
  updater.on('download-progress', p => { upd.percent = Math.max(0, Math.min(100, Math.round(p.percent || 0))); sendUpd(); });
  updater.on('update-downloaded', info => {
    Object.assign(upd, { state: 'ready', version: info.version, percent: 100 });
    updater.autoInstallOnAppQuit = upd.mode === 'auto';
    sendUpd();
  });
  updater.on('error', e => {
    upd.error = String((e && e.message) || e).split('\n')[0].slice(0, 300);
    upd.state = upd.version ? 'error' : 'idle';
    sendUpd();
  });
  setTimeout(checkUpdate, 3000);
  setInterval(checkUpdate, 30 * 60 * 1000).unref();
}
async function checkUpdate() {
  if (!updater || ['downloading', 'ready', 'installing'].includes(upd.state)) return;
  upd.state = 'checking'; sendUpd();
  try { await updater.checkForUpdates(); } catch { /* the error event says why */ }
  if (upd.state === 'checking') { upd.state = 'idle'; sendUpd(); }
}
function downloadUpdate() {
  if (!updater || upd.state === 'downloading' || upd.state === 'ready') return;
  upd.state = 'downloading'; upd.error = ''; sendUpd();
  updater.downloadUpdate().catch(() => { /* the error event says why */ });
}
ipcMain.handle('update:get', () => ({ ...upd, packaged: app.isPackaged }));
ipcMain.handle('update:mode', (_e, mode) => {
  upd.mode = mode === 'ask' ? 'ask' : 'auto';
  if (updater) updater.autoInstallOnAppQuit = upd.mode === 'auto' && upd.state === 'ready';
});
ipcMain.handle('update:check', async () => {
  if (!updater) return { ...upd, packaged: app.isPackaged };
  await checkUpdate();
  return { ...upd, packaged: true };
});
ipcMain.handle('update:download', () => { if (upd.state === 'error') upd.state = 'available'; downloadUpdate(); return { ...upd }; });
// Run from the folder (not installed) the launcher can't replace itself, but it still asks GitHub for the newest version.
ipcMain.handle('update:latest', async () => {
  let pub = {};
  try { pub = require('./package.json').build.publish || {}; } catch { pub = {}; }
  if (!pub.owner || !pub.repo) return { error: 'no-repo' };
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 10000);
  try {
    const r = await fetch(`https://api.github.com/repos/${pub.owner}/${pub.repo}/releases/latest`, { signal: ctl.signal, headers: { Accept: 'application/vnd.github+json', 'User-Agent': 'Warchief-Launcher' } });
    if (r.status === 404) return { none: true };
    if (!r.ok) return { error: 'HTTP ' + r.status };
    const j = await r.json();
    return { version: String(j.tag_name || '').replace(/^v/i, ''), url: /^https:\/\/github\.com\//.test(j.html_url || '') ? j.html_url : '' };
  } catch (e) {
    return { error: String((e && e.message) || e) };
  } finally { clearTimeout(timer); }
});
// Closes the launcher, installs the new version without any windows, and opens it again.
ipcMain.handle('update:restart', () => {
  if (!updater || upd.state !== 'ready') return false;
  upd.state = 'installing'; sendUpd();
  setImmediate(() => updater.quitAndInstall(true, true));
  return true;
});

// ---- Discord login for downloads (account.js). After logging in in the browser, the launcher comes back to the front.
account.setup({ focusWindow: showWindow });
installer.setup();

// ---- Window buttons
ipcMain.handle('win:minimize', () => win && win.minimize());
// The resize grip in the bottom-right corner (also the one on the Discord panel while it's stuck to the launcher)
let gripFrom = null;
function grip(phase) {
  if (!win || win.isDestroyed()) return;
  const at = screen.getCursorScreenPoint();
  if (phase === 'start') { const b = win.getBounds(); gripFrom = { x: at.x, y: at.y, w: b.width, h: b.height }; return; }
  if (phase === 'end') { gripFrom = null; return; }
  if (phase !== 'move' || !gripFrom) return;
  const area = screen.getDisplayMatching(win.getBounds()).workArea;
  const b = win.getBounds();
  const w = Math.max(MIN_W, Math.min(area.x + area.width - b.x, gripFrom.w + at.x - gripFrom.x));
  const h = Math.max(MIN_H, Math.min(area.y + area.height - b.y, gripFrom.h + at.y - gripFrom.y));
  win.setBounds({ x: b.x, y: b.y, width: Math.round(w), height: Math.round(h) });
}
ipcMain.handle('win:grip', (_e, phase) => grip(phase));
widget.onGrip(grip);
ipcMain.handle('win:toTray', () => { ensureTray(); if (win) win.hide(); });
ipcMain.handle('win:exit', () => app.quit());

// ---- Info for the support box
ipcMain.handle('app:info', () => ({
  version: app.getVersion(),
  packaged: app.isPackaged,
  electron: process.versions.electron,
  os: `${os.type()} ${os.release()}`,
  arch: process.arch
}));

ipcMain.handle('shell:open', (_e, url) => {
  if (typeof url === 'string' && /^https:\/\//i.test(url)) shell.openExternal(url);
});

ipcMain.handle('app:loginItem', (_e, on) => {
  if (process.platform === 'win32' || process.platform === 'darwin') app.setLoginItemSettings({ openAtLogin: !!on });
});

// ---- Addon list (catalog) published by the Admin page
function readConfig() {
  try { return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); } catch { return {}; }
}
ipcMain.handle('catalog:get', async () => {
  const cfg = readConfig();
  // On the dev PC the Admin page can show unpublished changes in the launcher (never in the installed one).
  if (cfg.usePreview && !app.isPackaged && typeof cfg.previewFile === 'string') {
    const p = path.resolve(__dirname, cfg.previewFile);
    if (p.startsWith(__dirname + path.sep)) {
      try { const catalog = JSON.parse(fs.readFileSync(p, 'utf8')); account.setAccess(catalog.access); return { catalog, source: 'preview' }; } catch { /* fall back to online */ }
    }
  }
  if (typeof cfg.catalogUrl !== 'string' || !/^https:\/\//i.test(cfg.catalogUrl)) return { error: 'no-catalog-url' };
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 10000);
  try {
    const url = cfg.catalogUrl + (cfg.catalogUrl.includes('?') ? '&' : '?') + 't=' + Date.now();
    const res = await fetch(url, { signal: ctl.signal, headers: { 'Cache-Control': 'no-cache' } });
    if (!res.ok) return { error: 'HTTP ' + res.status };
    const catalog = await res.json();
    account.setAccess(catalog && catalog.access);
    return { catalog, source: 'online' };
  } catch (e) {
    return { error: String(e && e.message || e) };
  } finally {
    clearTimeout(timer);
  }
});

// ---- Folders
ipcMain.handle('dialog:folder', async (_e, start) => {
  const opts = { title: 'Choose your World of Warcraft game folder', properties: ['openDirectory'] };
  if (typeof start === 'string' && fs.existsSync(start)) opts.defaultPath = start;
  const r = await dialog.showOpenDialog(win, opts);
  return r.canceled ? null : r.filePaths[0];
});

ipcMain.handle('fs:checkFolder', (_e, p) => checkFolder(p));
ipcMain.handle('fs:detect', (_e, games) => detectFolders(games));

function checkFolder(p) {
  const res = { path: p, exists: false, looksLikeWow: false, addons: null };
  if (typeof p !== 'string' || !p) return res;
  try { res.exists = fs.statSync(p).isDirectory(); } catch { return res; }
  if (!res.exists) return res;
  res.addons = path.join(p, 'Interface', 'AddOns');
  let names = [];
  try { names = fs.readdirSync(p); } catch { /* unreadable */ }
  res.looksLikeWow = fs.existsSync(res.addons) || names.some(n => /^wow.*\.exe$/i.test(n)) || names.includes('Interface') || names.includes('WTF');
  return res;
}

// Where Battle.net says WoW is installed (Windows registry), if it says anything.
function registryBases() {
  if (process.platform !== 'win32') return Promise.resolve([]);
  const keys = [
    'HKLM\\SOFTWARE\\WOW6432Node\\Blizzard Entertainment\\World of Warcraft',
    'HKLM\\SOFTWARE\\Blizzard Entertainment\\World of Warcraft'
  ];
  return Promise.all(keys.map(k => new Promise(resolve => {
    execFile('reg', ['query', k, '/v', 'InstallPath'], { windowsHide: true }, (err, stdout) => {
      if (err) return resolve([]);
      const m = String(stdout).match(/InstallPath\s+REG_SZ\s+(.+)/i);
      if (!m) return resolve([]);
      const ip = m[1].trim().replace(/[\\/]+$/, '');
      resolve([ip, path.dirname(ip)]);
    });
  }))).then(lists => lists.flat());
}

async function detectFolders(games) {
  const bases = new Set(await registryBases());
  if (process.platform === 'win32') {
    const rels = ['Program Files (x86)\\World of Warcraft', 'Program Files\\World of Warcraft', 'World of Warcraft',
      'Games\\World of Warcraft', 'Blizzard\\World of Warcraft', 'Blizzard Downloads\\World of Warcraft', 'Battle.net\\World of Warcraft'];
    for (const d of 'CDEFGH') for (const r of rels) bases.add(`${d}:\\${r}`);
  }
  const found = {};
  for (const g of Array.isArray(games) ? games : []) {
    if (!g || typeof g.id !== 'string' || typeof g.folder !== 'string' || !/^[\w.-]+$/.test(g.folder)) continue;
    found[g.id] = [];
    for (const b of bases) {
      const p = path.join(b, g.folder);
      const c = checkFolder(p);
      if (c.exists && c.looksLikeWow && !found[g.id].some(x => x.toLowerCase() === p.toLowerCase())) found[g.id].push(p);
    }
  }
  return found;
}
